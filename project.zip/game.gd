extends Node3D
# Wandering Caravan: game state, journey events, real-time combat and the night camp.

const WorldS = preload("res://world.gd")
const WagonS = preload("res://wagon.gd")
const UIS = preload("res://ui.gd")
const Actors = preload("res://actors.gd")
const Sfx = preload("res://sfx.gd")
const Mats = preload("res://mats.gd")

const UpdaterS = preload("res://updater.gd")
const BI = preload("res://build_info.gd")
const SAVE_PATH = "user://caravan_save.json"
const TOWNS = ["Stonewick", "Ravenmoor", "Eldergate", "Ashen Hollow", "Brindle", "Kestrel Ford", "Hollowmere", "Dunmarrow", "Greywatch", "Thornfield", "Saltmarch", "Wyvern's Rest", "Oakhaven", "Cinderfall", "Larkspur", "Haven"]
const UPG = {
	"armor": {"grp": "wagon", "name": "Reinforced Hull", "desc": "Wagon takes 8% less damage per level.", "base": 90, "max": 5},
	"wheels": {"grp": "wagon", "name": "Iron-bound Wheels", "desc": "+4% top speed per level.", "base": 80, "max": 5},
	"capacity": {"grp": "wagon", "name": "Bigger Wagon Bed", "desc": "+2 refugees per level. More passengers means more pay.", "base": 110, "max": 5},
	"stamina": {"grp": "horse", "name": "Horse Endurance", "desc": "Whip tires the horses 10% less and they recover faster.", "base": 80, "max": 5},
	"horse_speed": {"grp": "horse", "name": "Racing Stock", "desc": "+5% top speed per level.", "base": 100, "max": 5},
	"oats": {"grp": "horse", "name": "Quality Oats", "desc": "Horses use 10% less feed per level.", "base": 70, "max": 5},
	"rifle": {"grp": "weapon", "name": "Rifle Barrel", "desc": "+25% damage and a little better aim per level.", "base": 100, "max": 5},
	"reload": {"grp": "weapon", "name": "Quick-Loader", "desc": "Faster reload between shots.", "base": 90, "max": 5},
	"bandolier": {"grp": "weapon", "name": "Bandolier", "desc": "+10 maximum ammunition per level.", "base": 60, "max": 5},
}
const TOTAL: float = 3250.0
const CREW = {
	"mara": {"name": "Mara Voss", "role": "Scout", "perk": "Spots ambushes early and shows every threat on your HUD.", "flaw": "Distrusts strangers.", "col": Color(0.55, 0.85, 0.6), "hire": 55},
	"kade": {"name": "Kade Rourke", "role": "Gunslinger", "perk": "Fires on bandits by himself during fights.", "flaw": "Drinks. Water goes missing.", "col": Color(0.95, 0.55, 0.4), "hire": 65},
	"elias": {"name": "Brother Elias", "role": "Medic", "perk": "Heals the wounded while you travel.", "flaw": "Gives food to any beggar.", "col": Color(0.7, 0.75, 1.0), "hire": 50},
	"tomas": {"name": "Old Tomas", "role": "Wheelwright", "perk": "Mends the wagon as you travel.", "flaw": "Grumbles. Morale slowly drops.", "col": Color(0.9, 0.8, 0.5), "hire": 70},
	"ines": {"name": "Ines Calder", "role": "Hunter", "perk": "Deadly aim. Doubles what you get from hunting.", "flaw": "Reckless. Draws extra bandits.", "col": Color(0.9, 0.6, 0.85), "hire": 60},
}
const LINES = {
	"mara": ["Wind's shifted. Something moves in the trees.", "I walked this road once. It was kinder then.", "Keep to the ruts. The horses know the way."],
	"kade": ["Plenty of road left and not nearly enough whiskey.", "Say the word and I'll put one through anyone.", "Quiet country. I don't trust quiet country."],
	"elias": ["Stay strong, friends. Haven is real. I have seen its lights.", "Drink, child. There is enough for everyone.", "Pray if you wish. I'll pray with you."],
	"tomas": ["These wheels weren't built for this road. Not complaining. Much.", "Hear that creak? That's the axle telling me it's tired.", "Back in my day roads had edges."],
	"ines": ["Deer sign in the grass. Fresh.", "Give me a clear shot and a steady wagon.", "I'd rather be hunting than running."],
}
const TALK = {
	"mara": {"q": "Mara stares into the dark. 'I lost my brother on this road. Tell me we're doing right by these people.'", "a": [["We'll get them to Haven. Whatever it takes.", 8, 4], ["No promises. Just keep your eyes open.", 2, -1]]},
	"kade": {"q": "Kade turns an empty flask in his hands. 'You ever wonder if the good men are just the ones who never got tempted?'", "a": [["Not tonight, Kade. Tonight you're doing good.", 9, 3], ["Put it away. I need you sharp.", -3, 1]]},
	"elias": {"q": "Elias tends the fire. 'Some of them will not make it, you know. Even if we do everything right.'", "a": [["Then we make sure everyone who can, does.", 8, 3], ["Don't say that where they can hear.", 1, 2]]},
	"tomas": {"q": "Tomas taps the wagon rim. 'Forty years building wheels. Never thought the last one I'd mend would carry a whole town.'", "a": [["Then make it the best wheel you ever built.", 8, 4], ["Just keep it turning, old man.", 2, 0]]},
	"ines": {"q": "Ines sharpens her knife. 'Back there I stopped counting the ones I couldn't help. Do you count?'", "a": [["Every one. That's why we're still moving.", 8, 3], ["Counting doesn't feed anyone.", 0, 1]]},
}
const SHOP = [
	["Food crate", "+10 food", 12, "food", 10],
	["Water barrel", "+10 water", 8, "water", 10],
	["Feed sack", "+10 horse feed", 10, "feed", 10],
	["Ammo box", "+6 rounds", 14, "ammo", 6],
	["Medicine kit", "Heals up to 2 wounded", 18, "med", 2],
	["Wagon repair", "+25 wagon condition", 20, "hp", 25],
]

var world
var wagon
var ui
var cam: Camera3D
var rain_fx: CPUParticles3D
var flash_light: OmniLight3D
var pool: Array = []
var pool_i: int = 0
var wind_p: AudioStreamPlayer
var rain_p: AudioStreamPlayer
var fire_p: AudioStreamPlayer

var st: String = "load"
var stage: String = "init"
var trip: int = 1
var upg: Dictionary = {}
var town: String = "Ashford"
var start_name: String = "Ashford"
var mid_name: String = "Millbrook"
var dest: String = "Haven"
var contract: Dictionary = {"risk": 0, "mult": 1.0, "name": "First run"}
var contracts: Array = []
var delivered: int = 0
var party: int = 14
var ammo_max: int = 30
var capacity: int = 14
var reload_time: float = 0.9
var dmg_mult: float = 1.0
var feed_mult: float = 1.0
var shop_mult: float = 1.0
var rock_on: bool = false
var update_info: Dictionary = {}
var updater
var food: float = 60.0
var water: float = 60.0
var feed: float = 40.0
var ammo: int = 16
var coin: float = 90.0
var morale: float = 70.0
var people: int = 14
var wounded: int = 0
var dead_total: int = 0
var kills: int = 0
var crew: Array = []
var loyal: Dictionary = {}
var dist: float = 0.0
var hour: float = 8.0
var hour_fixed: float = -1.0
var after_camp: bool = false
var ev_i: int = 0
var events: Array = [
	{"at": 330.0, "id": "stranger"},
	{"at": 520.0, "id": "deer"},
	{"at": 630.0, "id": "river"},
	{"at": 1010.0, "id": "ambush"},
	{"at": 1390.0, "id": "town"},
	{"at": 1800.0, "id": "storm"},
	{"at": 2190.0, "id": "rocks"},
	{"at": 2470.0, "id": "camp"},
	{"at": 3180.0, "id": "haven"},
]
var enemies: Array = []
var combat: bool = false
var reload: float = 0.0
var ctx_label: String = ""
var warned: bool = false
var rock_zone: bool = false
var rock_t: float = 0.0
var storm_left: float = 0.0
var bolt_t: float = 5.0
var kade_cd: float = 2.0
var bark_t: float = 30.0
var heal_acc: float = 0.0
var dead_acc: float = 0.0
var starve_acc: float = 0.0
var kade_acc: float = 0.0
var river_charged: bool = false
var broke: bool = false
var paused_from: String = ""
var camp_slots: int = 3
var watch: String = ""
var scouted: bool = false
var ration_done: bool = false
var step_i: int = 0
var drop_t: float = 0.0
var flare_flash: float = 0.0
var deer_alive: bool = false

var cam_mode: String = "chase"
var cam_yaw_off: float = 0.0
var cam_pitch: float = 0.0
var orbit_t: float = 0.0
var orbit_c: Vector3 = Vector3.ZERO
var orbit_r: float = 16.0
var orbit_h: float = 6.0
var look_pt: Vector3 = Vector3.ZERO
var shake: float = 0.0


func _ready() -> void:
	stage = "ready begin"
	randomize()
	world = WorldS.new()
	stage = "creating world"
	add_child(world)
	stage = "world ok"
	wagon = WagonS.new()
	wagon.world = world
	add_child(wagon)
	wagon.crashed.connect(_on_crash)
	stage = "wagon ok"
	cam = Camera3D.new()
	cam.fov = 66.0
	cam.near = 0.15
	cam.far = 1800.0
	add_child(cam)
	cam.current = true
	flash_light = OmniLight3D.new()
	flash_light.omni_range = 14.0
	flash_light.light_color = Color(1.0, 0.85, 0.55)
	flash_light.light_energy = 0.0
	add_child(flash_light)
	rain_fx = Mats.particles("rain")
	rain_fx.position = Vector3(0, 14, -6)
	cam.add_child(rain_fx)
	stage = "camera ok"
	ui = UIS.new()
	ui.G = self
	add_child(ui)
	stage = "ui ok"
	updater = UpdaterS.new()
	add_child(updater)
	updater.found.connect(_on_update_found)
	updater.check()
	_apply_upgrades()
	_audio_setup()
	stage = "audio ok"
	_start()


func _start() -> void:
	var x0: float = world.road_x(0.0)
	wagon.place(Vector3(x0, world.height(x0, 0.0), 0.0), 0.0)
	wagon.hp = 100.0
	var steps: Array = ["Raising the hills", "Planting forests", "Tuning the wind", "Harnessing the horses"]
	world.update(wagon.position)
	var total: int = maxi(1, world.queue_size())
	var k: int = 0
	stage = "terrain 0/%d" % total
	while world.queue_size() > 0 and k < 900:
		world.work(12000)
		stage = "terrain %d left" % world.queue_size()
		ui.loading_p = 1.0 - float(world.queue_size()) / float(total)
		ui.loading_text = steps[mini(3, int(ui.loading_p * 4.0))]
		k += 1
		await get_tree().process_frame
	stage = "sounds"
	for kind in ["shot", "thud", "click", "hoof", "crash", "thunder", "chime"]:
		Sfx.get_stream(kind)
		await get_tree().process_frame
	stage = "intro"
	world.set_hour(8.0)
	hour = 8.0
	cam_mode = "orbit"
	orbit_c = wagon.position + Vector3(0, 2.0, -3.0)
	orbit_r = 17.0
	orbit_h = 5.0
	orbit_t = 0.9
	cam.position = orbit_c + Vector3(cos(orbit_t) * orbit_r, orbit_h, sin(orbit_t) * orbit_r)
	look_pt = orbit_c
	st = "intro"
	ui.fade = 1.0
	ui.fade_to(0.0, 1.8)
	ui.title_big = "WANDERING CARAVAN"
	ui.title_sub = "Ashford to Haven  ·  3,250 m  ·  14 lives depend on you"
	var tw = create_tween()
	tw.tween_property(ui, "title_a", 1.0, 1.4)
	tw.tween_interval(2.4)
	tw.tween_property(ui, "title_a", 0.0, 1.0)
	await tw.finished
	var waited: int = 0
	while not updater.finished and waited < 180:
		waited += 1
		await get_tree().process_frame
	_check_update_then(_main_menu)


# ---------- helpers exposed to the UI ----------
func controls_on() -> bool:
	return (st == "drive" or st == "raid") and not ui.is_open()


func show_hud() -> bool:
	return st != "load" and st != "intro"


func show_markers() -> bool:
	return rock_zone or deer_alive


func has(id: String) -> bool:
	return crew.has(id)


func markers() -> Array:
	var out: Array = []
	var mara: bool = has("mara")
	for e in enemies:
		if e["state"] == "dead":
			continue
		var d: float = e["node"].global_position.distance_to(wagon.position)
		if d > (200.0 if mara else 80.0) and e["kind"] != "boulder":
			continue
		var col: Color = Color(1.0, 0.35, 0.3)
		if e["kind"] == "deer":
			col = Color(0.5, 1.0, 0.5)
		elif e["kind"] == "boulder":
			col = Color(1.0, 0.65, 0.2)
		out.append({"pos": e["node"].global_position, "hp": e["hp"], "max": e["max"], "col": col, "d": d})
	return out


func _on_crash(sev: float) -> void:
	shake = 1.0
	ui.hurt(0.3)
	sfx("crash", -3.0)
	ui.pop("CRASH!", Vector2(ui.vsize().x * 0.5, 420), Color(1, 0.5, 0.35))


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		pause_menu()


# ---------- audio ----------
func _audio_setup() -> void:
	for i in 10:
		var p = AudioStreamPlayer.new()
		add_child(p)
		pool.append(p)
	wind_p = AudioStreamPlayer.new()
	wind_p.stream = Sfx.get_stream("wind")
	wind_p.volume_db = -22.0
	add_child(wind_p)
	wind_p.play()
	rain_p = AudioStreamPlayer.new()
	rain_p.stream = Sfx.get_stream("rain")
	rain_p.volume_db = -80.0
	add_child(rain_p)
	rain_p.play()
	fire_p = AudioStreamPlayer.new()
	fire_p.stream = Sfx.get_stream("fire")
	fire_p.volume_db = -80.0
	add_child(fire_p)
	fire_p.play()


func sfx(kind: String, vol: float = 0.0, pitch: float = 1.0) -> void:
	var p: AudioStreamPlayer = pool[pool_i]
	pool_i = (pool_i + 1) % pool.size()
	p.stream = Sfx.get_stream(kind)
	p.volume_db = vol
	p.pitch_scale = pitch
	p.play()


# ---------- main loop ----------
func _process(delta: float) -> void:
	if st == "load":
		return
	var d: float = minf(delta, 0.05)
	hour = hour_fixed if hour_fixed >= 0.0 else _phase_hour()
	world.set_hour(hour)
	var focus: Vector3 = wagon.position
	if cam_mode == "orbit":
		focus = orbit_c
	world.update(focus)
	world.work(5000)
	wagon.steer_in = ui.steer()
	wagon.throttle_in = ui.throttle()
	wagon.whip = ui.is_whip()
	wagon.brake = ui.is_brake()
	wagon.tick(d)
	wagon.lantern.light_energy = world.night_amt * 1.9
	reload = maxf(0.0, reload - d)
	flash_light.light_energy = maxf(0.0, flash_light.light_energy - d * 90.0)
	if st == "drive":
		_tick_drive(d)
	if st == "drive" or st == "raid":
		_tick_enemies(d)
		_update_crew(d)
	combat = false
	for e in enemies:
		if e["state"] != "dead" and e["kind"] != "boulder":
			combat = true
	_tick_weather(d)
	_update_ctx()
	_update_camera(d)
	world.cloud_rig.global_position = cam.global_position
	ammo = mini(ammo, ammo_max)
	_update_audio(d)
	if wagon.hp <= 0.0 and not broke and st == "drive":
		_breakdown()


func _phase_hour() -> float:
	if after_camp:
		return 5.25 + clampf((dist - 2470.0) / 780.0, 0.0, 1.0) * 1.2
	return 8.0 + clampf(dist / 2470.0, 0.0, 1.0) * 10.3


func _tick_drive(d: float) -> void:
	var nd: float = maxf(dist, -wagon.position.z)
	var dd: float = nd - dist
	dist = nd
	food = maxf(0.0, food - dd * float(people) * 0.0012)
	water = maxf(0.0, water - dd * float(people) * 0.0009)
	feed = maxf(0.0, feed - dd * 0.0095 * feed_mult)
	wagon.cap = 1.0 if feed > 0.0 else 0.55
	if storm_left > 0.0:
		wagon.cap *= 0.85
	var ok: bool = food > 5.0 and water > 5.0
	morale = clampf(morale + dd * (0.004 if ok else -0.012), 0.0, 100.0)
	if has("tomas"):
		wagon.hp = minf(100.0, wagon.hp + dd * 0.012)
		morale = clampf(morale - dd * 0.0018, 0.0, 100.0)
	if has("kade"):
		kade_acc += dd
		if kade_acc > 320.0:
			kade_acc = 0.0
			water = maxf(0.0, water - 3.0)
			ui.bark("Kade", "...what? The flask was leaking. Honest.", CREW["kade"]["col"])
	if has("elias") and wounded > 0:
		heal_acc += dd
		if heal_acc > 140.0:
			heal_acc = 0.0
			wounded -= 1
			ui.pop("Elias tended a wounded refugee", Vector2(ui.vsize().x * 0.5, 330), Color(0.7, 0.85, 1.0))
	elif wounded > 0:
		dead_acc += dd
		if dead_acc > 220.0:
			dead_acc = 0.0
			if randf() < 0.4:
				wounded -= 1
				_lose_people(1, "A wounded refugee didn't survive the road.")
	if (food <= 0.0 or water <= 0.0) and people > 0:
		starve_acc += dd
		if starve_acc > (100.0 if food <= 0.0 else 60.0):
			starve_acc = 0.0
			morale = clampf(morale - 7.0, 0.0, 100.0)
			_lose_people(1, "Without %s, someone didn't wake up." % ("food" if food <= 0.0 else "water"))
	# river cargo damage
	if wagon.water_dmg > 0.4 and not river_charged and dist > 780.0:
		river_charged = true
		var lost: float = minf(food, wagon.water_dmg * 4.0)
		food -= lost
		ui.bark("Tomas", "Cargo's soaked! Lost %d food to the river." % int(lost), CREW["tomas"]["col"])
	# periodic crew banter
	bark_t -= d
	if bark_t <= 0.0 and crew.size() > 0 and not combat:
		bark_t = randf_range(40.0, 75.0)
		var id: String = crew[randi() % crew.size()]
		var lines: Array = LINES[id]
		ui.bark(CREW[id]["name"].split(" ")[0], lines[randi() % lines.size()], CREW[id]["col"])
	# rockslide zone
	rock_zone = rock_on and dist > 2195.0 and dist < 2345.0
	if rock_zone:
		rock_t -= d
		if rock_t <= 0.0:
			rock_t = randf_range(1.1, 1.9)
			_spawn_boulder()
	# Mara's early warning
	if not warned and has("mara") and dist > 950.0 and dist < 1005.0:
		warned = true
		ui.bark("Mara", "Riders on the ridge, ahead. Get your rifle ready.", CREW["mara"]["col"])
		ui.banner("Mara spots riders ahead", "Ambush in a moment", 3.0)
	# events
	if ev_i < events.size() and dist >= events[ev_i]["at"] and not combat and not ui.is_open():
		var id2: String = events[ev_i]["id"]
		ev_i += 1
		call("ev_" + id2)


func _lose_people(n: int, why: String) -> void:
	people = maxi(0, people - n)
	dead_total += n
	ui.banner("A life lost", why, 4.0)
	morale = clampf(morale - 5.0, 0.0, 100.0)
	sfx("thud", -4.0, 0.7)
	if people <= 0:
		_fail()


func _update_crew(d: float) -> void:
	if has("kade") and combat:
		kade_cd -= d
		if kade_cd <= 0.0:
			kade_cd = 1.5 if watch != "kade" else 1.0
			var tgt = _nearest_hostile(70.0)
			if tgt != null and randf() < (0.68 if watch != "kade" else 0.85):
				sfx("shot", -9.0, 0.85)
				_damage_enemy(tgt, 1.0, Vector2.ZERO)


func _update_ctx() -> void:
	ctx_label = ""
	if st == "drive" and combat and drop_t <= 0.0 and not deer_alive:
		for e in enemies:
			if e["kind"] == "bandit" and e["state"] != "dead":
				ctx_label = "DROP\nCRATES"
				break
	if drop_t > 0.0:
		drop_t -= get_process_delta_time()


func on_ctx() -> void:
	if ctx_label == "":
		return
	food = maxf(0.0, food - 8.0)
	drop_t = 6.0
	sfx("crash", -4.0)
	ui.banner("Crates overboard!", "The riders scramble for the supplies  (-8 food)", 2.5)
	for e in enemies:
		if e["kind"] == "bandit":
			e["delay"] = 4.0


func _tick_weather(d: float) -> void:
	var s: float = world.storm
	rain_fx.emitting = s > 0.25
	rain_p.volume_db = -80.0 if s < 0.05 else lerpf(-40.0, -9.0, s)
	if storm_left > 0.0:
		storm_left -= d
		wagon.gust = sin(Time.get_ticks_msec() * 0.0011) * 0.30
		bolt_t -= d
		if bolt_t <= 0.0:
			bolt_t = randf_range(5.0, 10.0)
			world.flash = 1.0
			_thunder()
			if randf() < 0.22 and st == "drive":
				wagon.stamina = maxf(0.0, wagon.stamina - 25.0)
				wagon.hp = maxf(1.0, wagon.hp - 5.0 * wagon.armor)
				wagon.speed *= 0.4
				ui.hurt(0.6)
				shake = 1.0
				ui.banner("LIGHTNING STRIKE", "The horses scream and rear!", 2.5)
		if storm_left <= 0.0:
			world.set_storm(0.0)
			wagon.gust = 0.0
			ui.banner("The storm breaks", "", 3.0)
	else:
		wagon.gust = 0.0


func _thunder() -> void:
	await get_tree().create_timer(randf_range(0.3, 1.2)).timeout
	sfx("thunder", -3.0, randf_range(0.8, 1.1))


func _update_audio(d: float) -> void:
	var sp: float = wagon.speed
	wind_p.volume_db = lerpf(-24.0, -10.0, clampf(sp / 14.0 + world.storm * 0.6, 0.0, 1.0))
	if sp > 1.0:
		var si: int = int(wagon.phase / PI)
		if si != step_i:
			step_i = si
			sfx("hoof", -15.0 + clampf(sp * 0.4, 0.0, 5.0), randf_range(0.85, 1.15))
	var fd: float = wagon.position.distance_to(world.camp_pos())
	fire_p.volume_db = -80.0 if fd > 60.0 else lerpf(-8.0, -35.0, fd / 60.0)


# ---------- camera ----------
func _update_camera(d: float) -> void:
	if cam_mode == "chase":
		if ui.cam_id != -1:
			cam_yaw_off -= ui.cam_delta.x * 0.005
			cam_pitch = clampf(cam_pitch + ui.cam_delta.y * 0.003, -0.1, 0.7)
		elif not combat:
			cam_yaw_off = lerpf(cam_yaw_off, 0.0, 1.0 - exp(-d * 0.5))
			cam_pitch = lerpf(cam_pitch, 0.0, 1.0 - exp(-d * 0.3))
		ui.cam_delta = Vector2.ZERO
		var yc: float = wagon.yaw + cam_yaw_off
		var back: Vector3 = Vector3(sin(yc), 0, cos(yc))
		var far: float = 11.5 + wagon.speed * 0.12 + (2.5 if combat else 0.0)
		var tgt: Vector3 = wagon.position + Vector3(0, 2.6, 0) + wagon.forward() * 3.5
		var pos: Vector3 = wagon.position + back * far + Vector3(0, 4.4 + cam_pitch * 7.0 + (1.2 if combat else 0.0), 0)
		pos.y = maxf(pos.y, world.height(pos.x, pos.z) + 1.7)
		cam.position = cam.position.lerp(pos, 1.0 - exp(-7.0 * d))
		look_pt = look_pt.lerp(tgt, 1.0 - exp(-9.0 * d))
		cam.fov = lerpf(cam.fov, 64.0 + wagon.speed * 0.55 + (4.0 if wagon.whipping else 0.0), 1.0 - exp(-3.0 * d))
	else:
		if st == "raid":
			if ui.cam_id != -1:
				orbit_t -= ui.cam_delta.x * 0.006
				orbit_h = clampf(orbit_h + ui.cam_delta.y * 0.02, 3.0, 14.0)
		else:
			orbit_t += d * 0.11
		ui.cam_delta = Vector2.ZERO
		var op: Vector3 = orbit_c + Vector3(cos(orbit_t) * orbit_r, orbit_h, sin(orbit_t) * orbit_r)
		op.y = maxf(op.y, world.height(op.x, op.z) + 1.8)
		cam.position = cam.position.lerp(op, 1.0 - exp(-(7.0 if st == "raid" else 2.0) * d))
		look_pt = look_pt.lerp(orbit_c, 1.0 - exp(-4.0 * d))
		cam.fov = lerpf(cam.fov, 60.0, 1.0 - exp(-3.0 * d))
	shake = maxf(0.0, shake - d * 2.5)
	var so: Vector3 = Vector3(randf() - 0.5, randf() - 0.5, 0.0) * shake * 0.25
	if wagon.speed > 12.0:
		so += Vector3(randf() - 0.5, randf() - 0.5, 0.0) * 0.02
	cam.look_at_from_position(cam.position + so, look_pt + so, Vector3.UP)


# ---------- dialog helpers ----------
func _halt() -> void:
	st = "dialog"
	wagon.enabled = false
	ui.reset_touch()
	while wagon.speed > 0.4:
		await get_tree().process_frame


func ask(title: String, text: String, items: Array, cols: int = 1) -> void:
	st = "dialog"
	wagon.enabled = false
	ui.show_panel(title, text, items, cols)


func card(title: String, text: String, then: Callable, btn: String = "Continue") -> void:
	st = "dialog"
	wagon.enabled = false
	ui.show_panel(title, text, [{"t": btn, "f": then}])


func resume() -> void:
	st = "drive"
	wagon.enabled = true
	cam_mode = "chase"


func clampr() -> void:
	food = clampf(food, 0.0, 150.0)
	water = clampf(water, 0.0, 150.0)
	feed = clampf(feed, 0.0, 150.0)
	morale = clampf(morale, 0.0, 100.0)
	ammo = clampi(ammo, 0, ammo_max)
	wounded = mini(wounded, people)


# ---------- intro, shop, crew ----------
func _pick_first_companion() -> void:
	var items: Array = []
	for id in ["mara", "kade", "elias"]:
		var c: Dictionary = CREW[id]
		items.append({"t": "%s  ·  %s" % [c["name"], c["role"]], "s": "+ %s   – %s" % [c["perk"], c["flaw"]], "f": _first_chosen.bind(id)})
	st = "dialog"
	ui.show_panel("Who rides beside you?", "Fourteen refugees from Ashford. One wagon. Three thousand meters of open country, and a city called Haven at the end of it. You can't afford many mistakes. Choose your first companion.", items)


func _first_chosen(id: String) -> void:
	crew.append(id)
	loyal[id] = 50
	ui.bark(CREW[id]["name"].split(" ")[0], "I'm with you. Let's get them home.", CREW[id]["col"])
	card("Ashford Market", "Last chance to spend your 90 coin before the road. Drive with the left stick, hold WHIP to gallop (it tires the horses), and keep your rifle ready. Stay on the trail: the horses follow it by themselves, and you steer when you must.", _open_ashford_market, "Visit the market")


func _open_ashford_market() -> void:
	shop_menu(_leave_ashford)


func _leave_ashford() -> void:
	_depart()


func shop_menu(back: Callable) -> void:
	var items: Array = []
	for s in SHOP:
		var price: int = int(float(s[2]) * shop_mult)
		items.append({"t": "%s  —  %d coin" % [s[0], price], "s": s[1], "f": _buy.bind(s, back), "keep": true, "d": coin < float(price)})
	items.append({"t": "Done shopping", "f": back})
	ui.show_panel("Market  ·  %d coin" % int(coin), "Every coin you keep is a coin you can't eat. Every coin you spend is one you can't use later.", items, 2)


func _buy(s: Array, back: Callable) -> void:
	coin -= float(int(float(s[2]) * shop_mult))
	match s[3]:
		"food": food += float(s[4])
		"water": water += float(s[4])
		"feed": feed += float(s[4])
		"ammo": ammo += int(s[4])
		"med": wounded = maxi(0, wounded - int(s[4]))
		"hp": wagon.hp = minf(100.0, wagon.hp + float(s[4]))
	clampr()
	sfx("chime", -6.0)
	shop_menu(back)

func recruit_menu(back: Callable) -> void:
	var items: Array = []
	for id in CREW.keys():
		if crew.has(id):
			continue
		var c: Dictionary = CREW[id]
		items.append({"t": "%s  ·  %s  —  %d coin" % [c["name"], c["role"], c["hire"]], "s": "+ %s   – %s" % [c["perk"], c["flaw"]], "f": _hire.bind(id, back), "d": coin < float(c["hire"]) or crew.size() >= 3})
	items.append({"t": "Back", "f": back})
	ui.show_panel("Looking for hands  ·  %d coin" % int(coin), "Your wagon can carry three companions. Choose carefully: each one comes with a gift and a flaw." + ("\n(Your crew is full.)" if crew.size() >= 3 else ""), items)


func _hire(id: String, back: Callable) -> void:
	coin -= float(CREW[id]["hire"])
	crew.append(id)
	loyal[id] = 45
	sfx("chime", -4.0)
	ui.bark(CREW[id]["name"].split(" ")[0], "Right. Where do we start?", CREW[id]["col"])
	recruit_menu(back)


func pause_menu() -> void:
	if st == "load" or st == "intro" or get_tree().paused:
		return
	paused_from = st
	get_tree().paused = true
	var items: Array = [
		{"t": "Resume", "f": _unpause},
		{"t": "Graphics: %s" % ["Low", "Balanced", "High"][world.quality], "s": "Tap to cycle. Lower it if the game stutters.", "f": _cycle_quality, "keep": true}]
	if not update_info.is_empty():
		items.append({"t": "Update available: %s" % str(update_info["tag"]), "s": "Open the GitHub page. You can keep playing without it.", "f": _open_url.bind(str(update_info["url"])), "keep": true})
	items.append({"t": "Restart the game", "s": "Your saved progress is kept.", "f": _restart})
	ui.show_panel("Paused  ·  Trip %d  ·  %s" % [trip, BI.NAME], "Coin %d  ·  Refugees delivered: %d" % [int(coin), delivered], items)

func _unpause() -> void:
	get_tree().paused = false


func _cycle_quality() -> void:
	world.set_quality((world.quality + 1) % 3)
	ui.close_panel()
	get_tree().paused = false
	pause_menu()


func _restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


# ---------- enemies ----------
var fight_kind: String = ""


func _any_hostile() -> bool:
	for e in enemies:
		if e["state"] != "dead" and (e["kind"] == "bandit" or e["kind"] == "raider"):
			return true
	return false


func _nearest_hostile(rng: float):
	var best = null
	var bd: float = rng
	for e in enemies:
		if e["state"] == "dead" or e["kind"] == "boulder" or e["kind"] == "deer":
			continue
		var dd: float = e["node"].global_position.distance_to(wagon.position)
		if dd < bd:
			bd = dd
			best = e
	return best


func _make_light(parent: Node3D, pos: Vector3, rng: float, col: Color, energy: float) -> OmniLight3D:
	var l = OmniLight3D.new()
	l.omni_range = rng
	l.light_color = col
	l.light_energy = energy
	l.position = pos
	parent.add_child(l)
	return l


func _spawn_bandits(n: int, ahead: float) -> void:
	var fwd: Vector3 = wagon.forward()
	var rt: Vector3 = wagon.right()
	for i in n:
		var side: float = 1.0 if i % 2 == 0 else -1.0
		var pos: Vector3 = wagon.position + fwd * (ahead + float(i) * 6.0) + rt * side * randf_range(18.0, 34.0)
		var r: Dictionary = Actors.rider(Color(0.16 + randf() * 0.2, 0.1 + randf() * 0.06, 0.07), Color(0.18 + randf() * 0.2, 0.15, 0.12), true)
		r["node"].position = pos
		add_child(r["node"])
		var l = null
		enemies.append({"kind": "bandit", "node": r["node"], "h": r, "hp": _ehp(), "max": _ehp(), "state": "chase", "slot": Vector3(side * randf_range(7.0, 11.0), 0, randf_range(-6.0, 8.0)), "cd": randf_range(1.5, 3.0), "phase": 0.0, "speed": 10.0, "delay": 0.0, "t": 0.0, "light": l})


func _spawn_raiders(n: int, radius: float) -> void:
	for i in n:
		var a: float = float(i) / float(n) * TAU + randf() * 0.5
		var pos: Vector3 = wagon.position + Vector3(cos(a) * radius, 0, sin(a) * radius)
		var h: Dictionary = Actors.human(Color(0.25 + randf() * 0.15, 0.17, 0.12), true, true, false)
		h["node"].position = pos
		add_child(h["node"])
		var hand: Node3D = h["arms"][1]["low"]
		var tp = MeshInstance3D.new()
		var tb = BoxMesh.new()
		tb.size = Vector3(0.06, 0.6, 0.06)
		tp.mesh = tb
		tp.material_override = Mats.std(Color(0.2, 0.12, 0.07), 0.9)
		tp.position = Vector3(0, -0.45, -0.1)
		hand.add_child(tp)
		var fp: CPUParticles3D = Mats.particles("fire")
		fp.position = Vector3(0, -0.8, -0.1)
		fp.amount = 6
		fp.emitting = true
		hand.add_child(fp)
		var l = null
		if i < 3:
			l = _make_light(hand, Vector3(0, -0.9, -0.1), 13.0, Color(1.0, 0.6, 0.28), 1.7)
		enemies.append({"kind": "raider", "node": h["node"], "h": h, "hp": _ehp(), "max": _ehp(), "state": "chase", "cd": randf_range(1.0, 2.5), "phase": randf() * 6.0, "speed": 0.0, "delay": 0.0, "t": 0.0, "light": l})


func _spawn_deer() -> void:
	var fwd: Vector3 = wagon.forward()
	var rt: Vector3 = wagon.right()
	var side: float = 1.0 if randf() < 0.5 else -1.0
	var pos: Vector3 = wagon.position + fwd * 48.0 + rt * side * 38.0
	var h: Dictionary = Actors.horse(Color(0.55, 0.36, 0.2), 0.62, true)
	h["node"].position = pos
	add_child(h["node"])
	var v: Vector3 = (rt * -side * 1.0 + fwd * 0.25).normalized() * 6.5
	enemies.append({"kind": "deer", "node": h["node"], "h": h, "hp": 1.0, "max": 1.0, "state": "chase", "vel": v, "phase": 0.0, "t": 0.0, "speed": 6.5, "delay": 0.0, "light": null})
	deer_alive = true


func _spawn_boulder() -> void:
	var side: float = 1.0 if randf() < 0.5 else -1.0
	var lead: float = maxf(wagon.speed, 4.0) * randf_range(2.8, 4.4)
	var zp: float = wagon.position.z - lead
	var xp: float = world.road_x(zp) + side * 38.0
	var mi = MeshInstance3D.new()
	mi.mesh = world.lib["rocks"][randi() % 3]
	mi.scale = Vector3.ONE * randf_range(1.5, 2.2)
	mi.position = Vector3(xp, world.height(xp, zp) + 1.0, zp)
	add_child(mi)
	enemies.append({"kind": "boulder", "node": mi, "hp": 1.0, "max": 1.0, "state": "chase", "vel": Vector3(-side * 11.0, 0, 0), "t": 0.0, "side": side, "delay": 0.0, "light": null})


func _tick_enemies(d: float) -> void:
	var kept: Array = []
	for e in enemies:
		var keep: bool = true
		match e["kind"]:
			"bandit":
				keep = _tick_bandit(e, d)
			"raider":
				keep = _tick_raider(e, d)
			"deer":
				keep = _tick_deer(e, d)
			"boulder":
				keep = _tick_boulder(e, d)
		if keep:
			kept.append(e)
		else:
			if e["kind"] == "deer":
				deer_alive = false
				if e["state"] != "dead":
					ui.banner("The deer got away", "", 2.5)
			e["node"].queue_free()
	enemies = kept
	if fight_kind != "" and not _any_hostile():
		var k: String = fight_kind
		fight_kind = ""
		_fight_over(k)


func _tick_bandit(e: Dictionary, d: float) -> bool:
	var n: Node3D = e["node"]
	if e["state"] == "dead":
		e["t"] += d
		n.rotation.z = lerpf(n.rotation.z, 1.4, 1.0 - exp(-5.0 * d))
		return e["t"] < 5.0
	e["delay"] = maxf(0.0, e["delay"] - d)
	var wp: Vector3 = wagon.position
	var tgt: Vector3 = wp + Basis(Vector3.UP, wagon.yaw) * e["slot"]
	var to: Vector3 = tgt - n.position
	to.y = 0.0
	var dd: float = to.length()
	var want: float = clampf(dd * 1.5, 0.0, 16.0)
	if e["delay"] > 0.0:
		want *= 0.3
	e["speed"] = move_toward(e["speed"], want, 14.0 * d)
	var dir: Vector3 = to / maxf(dd, 0.001)
	n.position += dir * e["speed"] * d
	n.position.y = world.height(n.position.x, n.position.z)
	var face: Vector3 = dir if e["speed"] > 2.5 else (wp - n.position)
	face.y = 0.0
	if face.length() > 0.01:
		face = face.normalized()
		n.rotation.y = lerp_angle(n.rotation.y, atan2(-face.x, -face.z), 1.0 - exp(-8.0 * d))
	e["phase"] += d * (2.0 + e["speed"] * 0.8)
	Actors.gait(e["h"], e["phase"], clampf(e["speed"] / 9.0, 0.1, 1.0) * 0.8)
	var dw: float = n.position.distance_to(wp)
	e["cd"] -= d
	var l: OmniLight3D = e["light"]
	if l != null:
		l.light_energy = maxf(0.0, l.light_energy - d * 80.0)
	if dw < 26.0 and e["cd"] <= 0.0 and e["delay"] <= 0.0:
		e["cd"] = randf_range(2.2, 3.8)
		sfx("shot", -11.0, 0.8)
		if l != null:
			l.light_energy = 8.0
		if randf() < (0.75 if wagon.speed < 5.0 else 0.45):
			_wagon_hit()
	if dw > 150.0 and wagon.speed > 11.0:
		return false
	return true


func _tick_raider(e: Dictionary, d: float) -> bool:
	var n: Node3D = e["node"]
	if e["state"] == "dead":
		e["t"] += d
		n.rotation.x = lerpf(n.rotation.x, -1.45, 1.0 - exp(-6.0 * d))
		var l0: OmniLight3D = e["light"]
		if l0 != null:
			l0.light_energy = maxf(0.0, l0.light_energy - d * 2.0)
		return e["t"] < 6.0
	var wp: Vector3 = wagon.position
	var to: Vector3 = wp - n.position
	to.y = 0.0
	var dd: float = to.length()
	var spd: float = 4.6 if dd > 7.5 else 0.0
	n.position += to / maxf(dd, 0.001) * spd * d
	n.position.y = world.height(n.position.x, n.position.z)
	n.rotation.y = lerp_angle(n.rotation.y, atan2(-to.x, -to.z), 1.0 - exp(-6.0 * d))
	e["phase"] += d * (7.0 if spd > 0.0 else 0.0)
	Actors.walk(e["h"], e["phase"], 0.7 if spd > 0.0 else 0.0)
	if dd <= 8.5:
		e["cd"] -= d
		if e["cd"] <= 0.0:
			e["cd"] = randf_range(2.0, 3.2)
			_melee_hit()
	return true


func _tick_deer(e: Dictionary, d: float) -> bool:
	var n: Node3D = e["node"]
	e["t"] += d
	if e["state"] == "dead":
		n.rotation.z = lerpf(n.rotation.z, 1.4, 1.0 - exp(-6.0 * d))
		return e["t"] < 4.0
	n.position += e["vel"] * d
	n.position.y = world.height(n.position.x, n.position.z)
	var v: Vector3 = e["vel"]
	n.rotation.y = lerp_angle(n.rotation.y, atan2(-v.x, -v.z), 1.0 - exp(-6.0 * d))
	e["phase"] += d * 9.0
	Actors.gait(e["h"], e["phase"], 0.9)
	return e["t"] < 24.0


func _tick_boulder(e: Dictionary, d: float) -> bool:
	var n: Node3D = e["node"]
	e["t"] += d
	n.position += e["vel"] * d
	n.position.y = world.height(n.position.x, n.position.z) + 1.0
	n.rotation.z -= e["vel"].x * d * 0.4
	var dd: Vector2 = Vector2(n.position.x - wagon.position.x, n.position.z - wagon.position.z)
	if dd.length() < 3.0 and st == "drive":
		wagon.hp = maxf(0.0, wagon.hp - wagon.armor * (14.0))
		wagon.speed *= 0.45
		shake = 1.0
		ui.hurt(0.5)
		sfx("crash", -2.0)
		ui.banner("BOULDER HIT", "", 1.5)
		return false
	var far: float = (n.position.x - world.road_x(n.position.z)) * e["side"]
	if far < -42.0 or e["t"] > 9.0:
		return false
	return true


func _wagon_hit() -> void:
	var r: float = randf()
	shake = maxf(shake, 0.6)
	ui.hurt(0.35)
	sfx("thud", -3.0, 0.8)
	if r < 0.5:
		wagon.hp = maxf(0.0, wagon.hp - wagon.armor * (randf_range(3.0, 6.0)))
	elif r < 0.85 and people - wounded > 0:
		wounded += 1
		ui.banner("A refugee is hit!", "", 2.0)
	else:
		wagon.stamina = maxf(0.0, wagon.stamina - 15.0)


func _melee_hit() -> void:
	var r: float = randf()
	shake = maxf(shake, 0.7)
	ui.hurt(0.4)
	sfx("thud", -2.0, 0.7)
	if r < 0.45 and people - wounded > 0:
		wounded += 1
		ui.banner("A raider reaches the wagon!", "A refugee is hurt", 2.0)
	elif r < 0.8:
		wagon.hp = maxf(0.0, wagon.hp - wagon.armor * (4.0))
	else:
		food = maxf(0.0, food - 3.0)
		ui.pop("Supplies stolen", Vector2(ui.vsize().x * 0.5, 400), Color(1, 0.6, 0.4))


func _hit_fx(pos: Vector3) -> void:
	var p: CPUParticles3D = Mats.particles("hit")
	add_child(p)
	p.global_position = pos
	p.emitting = true
	get_tree().create_timer(1.2).timeout.connect(p.queue_free)


func on_tap(p: Vector2) -> void:
	if st != "drive" and st != "raid":
		return
	if reload > 0.0:
		return
	if ammo <= 0:
		ui.pop("NO AMMO", p, Color(1, 0.4, 0.3))
		sfx("click", -4.0)
		reload = 0.4
		return
	ammo -= 1
	reload = reload_time
	sfx("shot", -2.0)
	flash_light.global_position = wagon.muzzle()
	flash_light.light_energy = 7.0
	shake = maxf(shake, 0.25)
	var best = null
	var bd: float = 175.0
	for e in enemies:
		if e["state"] == "dead" or e["kind"] == "boulder":
			continue
		var p3: Vector3 = e["node"].global_position + Vector3(0, 1.8, 0)
		if cam.is_position_behind(p3):
			continue
		if e["node"].global_position.distance_to(wagon.position) > 100.0:
			continue
		var dd: float = cam.unproject_position(p3).distance_to(p)
		if dd < bd:
			bd = dd
			best = e
	if best == null:
		ui.pop("MISS", p, Color(0.8, 0.8, 0.8))
		return
	var dist3: float = best["node"].global_position.distance_to(wagon.position)
	var chance: float = 0.95 - dist3 * 0.0055 - wagon.speed * 0.012 + (0.06 if has("ines") else 0.0) + 0.02 * float(lvl("rifle"))
	if randf() < chance:
		_damage_enemy(best, dmg_mult, p)
	else:
		ui.pop("MISS", p, Color(0.8, 0.8, 0.8))


func _damage_enemy(e: Dictionary, dmg: float, p: Vector2) -> void:
	if e["state"] == "dead":
		return
	e["hp"] -= dmg
	_hit_fx(e["node"].global_position + Vector3(0, 1.6, 0))
	sfx("thud", -5.0, randf_range(0.9, 1.2))
	if e["hp"] <= 0.0:
		e["state"] = "dead"
		e["t"] = 0.0
		kills += 1
		if e["kind"] == "deer":
			var gain: int = 18 * (2 if has("ines") else 1)
			food += float(gain)
			ui.banner("Clean shot", "+%d food" % gain, 2.5)
		elif p != Vector2.ZERO:
			ui.pop("DOWN", p, Color(1.0, 0.8, 0.4))
	elif p != Vector2.ZERO:
		ui.pop("HIT", p, Color(1.0, 0.6, 0.3))


# ---------- journey events ----------
func ev_stranger() -> void:
	await _halt()
	var body: String = "A man in a torn coat sits against a broken cart by the road, one arm raised. 'Please. Water, anything. Bandits took my horse.'"
	if has("mara"):
		body += "\n\nMara murmurs: 'His boots are too clean for a man who's been walking. I don't like this.'"
	ask("A Stranger on the Road", body, [
		{"t": "Help him", "s": "Costs 6 food and 6 water. Your heart says yes.", "f": _str_help},
		{"t": "Toss him a water skin from a distance", "s": "Costs 3 water. Keep the rifle ready.", "f": _str_water},
		{"t": "Drive past", "s": "Safe. But the people watch you do it.", "f": _str_ignore}])


func _str_help() -> void:
	food -= 6.0
	water -= 6.0
	clampr()
	if randf() < (0.1 if has("mara") else 0.45):
		card("It was a trap", "The moment you stop, he whistles. Riders pour out of the treeline. 'Now,' he grins, 'the supplies.'", _trap_fight, "Defend the wagon!")
	else:
		ammo += 8
		coin += 20
		morale += 4.0
		clampr()
		card("A good deed", "He's a hunter whose horse was stolen. He presses eight rounds and twenty coin into your hands. 'The road remembers kindness,' he says.", resume)


func _str_water() -> void:
	water -= 3.0
	clampr()
	if randf() < 0.2:
		card("He whistles anyway", "The man grins as riders burst from the trees. The water skin didn't buy you anything.", _trap_fight, "Defend the wagon!")
	else:
		ammo += 3
		morale += 1.0
		card("Thanks, traveller", "He nods and limps away. Three rounds sit in the dust where he was, left for you.", resume)


func _str_ignore() -> void:
	morale = clampf(morale - 6.0, 0.0, 100.0)
	if has("elias"):
		loyal["elias"] = loyal.get("elias", 50) - 6
		ui.bark("Elias", "We could have helped him. We could have.", CREW["elias"]["col"])
	card("You drive on", "His voice fades behind the dust. Nobody in the wagon looks at you.", resume)


func _trap_fight() -> void:
	resume()
	ui.banner("AMBUSH!", "Shoot them, or whip the horses and run", 3.0)
	sfx("crash", -8.0)
	_spawn_bandits(_scale_n(3), 40.0)
	fight_kind = "trap"


func ev_deer() -> void:
	await _halt()
	var body: String = "A stag stands on the ridge, watching the road. Fresh meat would feed everyone for days."
	if has("ines"):
		body += "\n\nInes already has her rifle in her hands."
	ask("Game on the Ridge", body, [
		{"t": "Hunt it", "s": "Tap the deer to shoot. Costs ammunition. Food is life.", "f": _hunt},
		{"t": "Keep moving", "s": "No time to waste.", "f": resume}])


func _hunt() -> void:
	resume()
	_spawn_deer()
	ui.banner("The stag runs!", "Tap it to shoot", 3.0)


func ev_river() -> void:
	await _halt()
	ask("Ashmere Ford", "The road dips into a wide, shallow river. The current is strong and the bed is uneven. Cross too fast and your cargo and wheels will pay for it. The ford is only a few meters wide; the horses will stay on it if you let them.", [
		{"t": "Fill the water barrels", "s": "+30 water. The river is clean here.", "f": _river_fill},
		{"t": "Probe the ford with poles", "s": "Raises the speed it's safe to cross at.", "f": _river_probe},
		{"t": "Cross now", "s": "Quick. Keep your speed under control in the water.", "f": resume}])


func _river_fill() -> void:
	water = minf(150.0, water + 30.0)
	morale += 2.0
	sfx("chime", -6.0)
	card("Barrels topped up", "Cold, clean water. People drink until they laugh. The ford is still dangerous: keep your speed down once the wheels are wet.", resume)


func _river_probe() -> void:
	wagon.ford_limit = 8.5 if (has("mara") or has("tomas")) else 7.4
	card("The ford is sound", "You mark a safe line with poles. Crossing slower than a gallop will keep the cargo dry. A steady trot is fine.", resume)


func ev_ambush() -> void:
	ui.banner("AMBUSH!", "Shoot them, outrun them, or throw the crates", 3.5)
	sfx("crash", -8.0)
	_spawn_bandits(_scale_n(4) + (1 if has("ines") else 0), 85.0)
	fight_kind = "ambush"


func _fight_over(kind: String) -> void:
	if kind == "raid":
		_dawn()
	else:
		_loot()


func _loot() -> void:
	await get_tree().create_timer(1.3).timeout
	await _halt()
	ask("The Road Falls Quiet", "Smoke drifts off the grass. Your hands are still shaking. The bandits' packs are lying open on the ground.", [
		{"t": "Strip the dead of weapons", "s": "+6 rounds, +25 coin. Elias won't approve.", "f": _loot_take},
		{"t": "Tend to the wounded", "s": "Heal up to 2 wounded. Morale +5.", "f": _loot_tend},
		{"t": "Ride on", "f": resume}])


func _loot_take() -> void:
	ammo += 6
	coin += 25
	if has("elias"):
		loyal["elias"] = loyal.get("elias", 50) - 5
	card("Spoils", "Six rounds and a purse of coin. The refugees look away.", resume)


func _loot_tend() -> void:
	wounded = maxi(0, wounded - 2)
	morale = clampf(morale + 5.0, 0.0, 100.0)
	card("Tending the wounded", "Bandages, whispered thanks, a little water. The wagon feels a little less afraid.", resume)


func ev_town() -> void:
	await _halt()
	_town_menu()


func _town_menu() -> void:
	ask(mid_name, "A farming town squatting on the road. Lanterns, smoke, wary faces. They'll trade, but they won't offer charity. Word is the quarry ridge is unstable and there's a storm coming off the mountains.", [
		{"t": "Market", "s": "Buy supplies, ammunition, repairs.", "f": _town_market},
		{"t": "Recruit", "s": "Your wagon can carry three companions.", "f": _town_recruit},
		{"t": "Stay at the inn", "s": "12 coin. Morale +12, heals 1 wounded.", "f": _town_inn, "d": coin < 12.0},
		{"t": "Leave town", "f": _leave_town}], 2)


func _town_market() -> void:
	shop_menu(_town_menu)


func _town_recruit() -> void:
	recruit_menu(_town_menu)


func _town_inn() -> void:
	coin -= 12.0
	morale = clampf(morale + 12.0, 0.0, 100.0)
	wounded = maxi(0, wounded - 1)
	sfx("chime", -6.0)
	card("A warm room", "Hot stew, dry blankets, real beds for a few hours. People smile again.", _town_menu, "Back to the square")


func _leave_town() -> void:
	ui.banner("Onward to %s" % dest, "", 3.0)
	resume()


func ev_storm() -> void:
	await _halt()
	ask("Storm Front", "Black clouds roll off the mountains. Wind flattens the grass. A hollow beneath a cliff lies just off the road, but the storm may not wait.", [
		{"t": "Push through", "s": "Horses slow, gusts shove the wagon, lightning can strike. Keep to the road.", "f": _storm_push},
		{"t": "Shelter in the hollow", "s": "Safe. Costs 5 food. Morale +3.", "f": _storm_shelter}])


func _storm_push() -> void:
	storm_left = 55.0
	bolt_t = 3.0
	world.set_storm(1.0)
	ui.banner("STORM", "Keep to the road. Brake if the wagon slides", 3.5)
	resume()


func _storm_shelter() -> void:
	food = maxf(0.0, food - 5.0)
	morale = clampf(morale + 3.0, 0.0, 100.0)
	card("Waiting it out", "Thunder shakes the cliff. The refugees huddle together. By the time the sky clears, nobody remembers being afraid.", resume)


func ev_rocks() -> void:
	rock_on = true
	rock_t = 1.0
	ui.banner("ROCKFALL!", "Steer clear of the boulders", 4.0)
	if has("tomas"):
		ui.bark("Tomas", "The slope's moving! Watch the rocks!", CREW["tomas"]["col"])
	elif has("mara"):
		ui.bark("Mara", "Loose scree above. Dodge what falls.", CREW["mara"]["col"])


# ---------- night camp ----------
func ev_camp() -> void:
	await _halt()
	ui.fade_to(1.0, 1.0)
	await get_tree().create_timer(1.1).timeout
	hour_fixed = 20.6
	world.set_storm(0.0)
	storm_left = 0.0
	var cp: Vector3 = world.camp_pos()
	var px: float = cp.x - 11.0
	var pz: float = cp.z + 6.0
	wagon.place(Vector3(px, world.height(px, pz), pz), atan2(world.road_dx(pz), 1.0))
	cam_mode = "orbit"
	orbit_c = cp + Vector3(0, 1.5, 0)
	orbit_r = 13.0
	orbit_h = 4.5
	orbit_t = 0.6
	camp_slots = 3
	watch = ""
	scouted = false
	ration_done = false
	ui.fade_to(0.0, 1.3)
	ui.banner("Night falls", "Camp at the old quarry", 3.5)
	await get_tree().create_timer(1.8).timeout
	camp_menu()


func camp_menu() -> void:
	st = "camp"
	var items: Array = []
	items.append({"t": "Share out rations" + ("  (done)" if ration_done else ""), "s": "Decide how much everyone eats tonight.", "f": _camp_rations, "d": ration_done})
	items.append({"t": "Set the night watch", "s": "On watch: " + (CREW[watch]["name"] if watch != "" else "nobody"), "f": _camp_watch})
	items.append({"t": "Repair the wagon", "s": "+25 condition. Uses 1 action.", "f": _camp_repair, "d": camp_slots <= 0})
	items.append({"t": "Tend the wounded", "s": "Wounded: %d. Uses 1 action." % wounded, "f": _camp_tend, "d": camp_slots <= 0 or wounded <= 0})
	items.append({"t": "Sit by the fire and talk", "s": "Learn what your crew is thinking. Uses 1 action.", "f": _camp_talk, "d": camp_slots <= 0 or crew.is_empty()})
	items.append({"t": "Scout the perimeter", "s": "Spot raiders before they close in. Uses 1 action.", "f": _camp_scout, "d": camp_slots <= 0 or scouted})
	items.append({"t": "Lie down. End the night.", "s": "Something will come before dawn.", "f": _camp_end})
	ui.show_panel("Camp  ·  %d actions left" % camp_slots, "Food %d  ·  Water %d  ·  Ammo %d  ·  Wagon %d%%  ·  Morale %d%%  ·  Wounded %d" % [int(food), int(water), ammo, int(wagon.hp), int(morale), wounded], items, 2)


func _camp_rations() -> void:
	ui.show_panel("Rations", "Fourteen hungry mouths and a long road. What do you give them?", [
		{"t": "Full portions", "s": "-14 food. Morale +8.", "f": _ration.bind(14.0, 8.0)},
		{"t": "Half portions", "s": "-7 food. Morale -2.", "f": _ration.bind(7.0, -2.0)},
		{"t": "Nothing tonight", "s": "No food used. Morale -10.", "f": _ration.bind(0.0, -10.0)}])


func _ration(cost: float, m: float) -> void:
	food = maxf(0.0, food - cost)
	morale = clampf(morale + m, 0.0, 100.0)
	ration_done = true
	camp_menu()


func _camp_watch() -> void:
	var items: Array = []
	for id in crew:
		items.append({"t": CREW[id]["name"], "s": CREW[id]["role"], "f": _set_watch.bind(id)})
	items.append({"t": "Nobody. Everyone sleeps.", "s": "Raiders will take you by surprise.", "f": _set_watch.bind("")})
	ui.show_panel("Who takes the watch?", "A good watch spots trouble early. Kade shoots faster. Mara sees them coming from far away.", items)


func _set_watch(id: String) -> void:
	watch = id
	camp_menu()


func _camp_repair() -> void:
	camp_slots -= 1
	wagon.hp = minf(100.0, wagon.hp + 25.0 + (10.0 if has("tomas") else 0.0))
	sfx("chime", -6.0)
	camp_menu()


func _camp_tend() -> void:
	camp_slots -= 1
	wounded = 0 if has("elias") else maxi(0, wounded - 2)
	morale = clampf(morale + 2.0, 0.0, 100.0)
	sfx("chime", -6.0)
	camp_menu()


func _camp_scout() -> void:
	camp_slots -= 1
	scouted = true
	card("A quiet circle", "You walk the edge of the camp. Torches flicker far off in the dark. They're coming from every side.", camp_menu, "Back to the fire")


func _camp_talk() -> void:
	var items: Array = []
	for id in crew:
		items.append({"t": CREW[id]["name"], "s": CREW[id]["role"], "f": _talk_to.bind(id)})
	items.append({"t": "Never mind", "f": camp_menu})
	ui.show_panel("Who do you sit with?", "", items)


func _talk_to(id: String) -> void:
	var t: Dictionary = TALK[id]
	var items: Array = []
	for a in t["a"]:
		items.append({"t": a[0], "f": _talk_done.bind(id, a[1], a[2])})
	ui.show_panel(CREW[id]["name"], t["q"], items)


func _talk_done(id: String, l: int, m: int) -> void:
	camp_slots -= 1
	loyal[id] = loyal.get(id, 50) + l
	morale = clampf(morale + float(m), 0.0, 100.0)
	card("By the fire", "The conversation drifts into silence, and the silence is better than before.", camp_menu, "Back to the fire")


func _camp_end() -> void:
	ev_raid()


func ev_raid() -> void:
	ui.close_panel()
	ui.fade_to(1.0, 0.8)
	await get_tree().create_timer(0.9).timeout
	hour_fixed = 2.4
	st = "raid"
	wagon.enabled = false
	cam_mode = "orbit"
	orbit_c = wagon.position + Vector3(0, 1.8, 0)
	orbit_r = 15.0
	orbit_h = 7.5
	var radius: float = 95.0 if (scouted or watch == "mara") else 42.0
	if watch == "":
		wounded += 1
		ui.banner("RAIDERS IN THE CAMP!", "You were asleep. A refugee is hurt", 4.0)
	else:
		ui.banner("RAID!", CREW[watch]["name"] + " raises the alarm. Tap the raiders to shoot", 4.0)
	_spawn_raiders(_scale_n(6), radius)
	fight_kind = "raid"
	ui.fade_to(0.0, 0.8)
	sfx("crash", -8.0)


func _dawn() -> void:
	await get_tree().create_timer(1.6).timeout
	ui.fade_to(1.0, 1.2)
	await get_tree().create_timer(1.3).timeout
	hour_fixed = -1.0
	after_camp = true
	st = "dialog"
	cam_mode = "chase"
	cam.position = wagon.position + Vector3(0, 6, 14)
	look_pt = wagon.position
	morale = clampf(morale + 6.0, 0.0, 100.0)
	ammo += 3
	ui.fade_to(0.0, 1.5)
	var extra: String = ""
	if wounded > 0:
		extra = "  %d wounded need care." % wounded
	card("Dawn", "The last raider is down. Smoke and frost hang over the quarry. The sun is rising over the hills, and far ahead, pale towers catch the first light. %s.%s" % [dest, extra], resume, "Onward")


# ---------- failures and ending ----------
func _breakdown() -> void:
	broke = true
	await _halt()
	ask("The Axle Snaps", "With a crack like a rifle shot the rear axle gives way. The wagon slumps into the road and nobody dares breathe.", [
		{"t": "Abandon half the cargo", "s": "Lose half your food, water and feed. Wagon back to 45%.", "f": _bd_abandon},
		{"t": "Emergency repairs by lantern", "s": "Morale -10, ammo -4 for scrap. Wagon back to 35%.", "f": _bd_repair}])


func _bd_abandon() -> void:
	food *= 0.5
	water *= 0.5
	feed *= 0.5
	wagon.hp = 45.0
	broke = false
	resume()


func _bd_repair() -> void:
	morale = clampf(morale - 10.0, 0.0, 100.0)
	ammo = maxi(0, ammo - 4)
	wagon.hp = 35.0
	broke = false
	resume()


func ev_haven() -> void:
	await _halt()
	_arrive()


func _scale_n(n: int) -> int:
	return n + mini(5, int(float(trip - 1) / 2.0)) + int(contract["risk"])


func _ehp() -> float:
	return 2.0 + 0.25 * float(mini(trip - 1, 8))


func lvl(id: String) -> int:
	return int(upg.get(id, 0))


func _upg_cost(id: String) -> int:
	return int(float(UPG[id]["base"]) * pow(float(lvl(id) + 1), 1.5))


func _apply_upgrades() -> void:
	wagon.armor = 1.0 - 0.08 * float(lvl("armor"))
	wagon.speed_mult = (1.0 + 0.04 * float(lvl("wheels"))) * (1.0 + 0.05 * float(lvl("horse_speed")))
	wagon.drain_mult = 1.0 - 0.1 * float(lvl("stamina"))
	wagon.regen_mult = 1.0 + 0.15 * float(lvl("stamina"))
	feed_mult = 1.0 - 0.1 * float(lvl("oats"))
	dmg_mult = 1.0 + 0.25 * float(lvl("rifle"))
	reload_time = maxf(0.4, 0.9 - 0.08 * float(lvl("reload")))
	ammo_max = 30 + 10 * lvl("bandolier")
	capacity = 14 + 2 * lvl("capacity")


# ---------- trips: arrival, contracts, hub ----------
func _arrive() -> void:
	st = "dialog"
	wagon.enabled = false
	cam_mode = "orbit"
	orbit_c = wagon.position + Vector3(0, 3.0, 0)
	orbit_r = 17.0
	orbit_h = 6.0
	var pay: int = 0
	if people > 0:
		var base: int = 60 + 12 * people + 25 * trip
		var bonus: int = int(morale * 0.5) + int(wagon.hp * 0.3)
		pay = int(float(base + bonus) * float(contract["mult"]))
	coin += float(pay)
	delivered += people
	var text: String = "The gates of %s swing open. %d of %d refugees walk into the light.\n" % [dest, people, party]
	for id in crew:
		var nm: String = CREW[id]["name"].split(" ")[0]
		if loyal.get(id, 50) >= 60:
			text += "\n%s is proud of what you did." % nm
		else:
			text += "\n%s says little, but stays." % nm
	text += "\n\nPayment: %d coin  (contract x%.1f)\nRefugees delivered so far: %d" % [pay, float(contract["mult"]), delivered]
	town = dest
	trip += 1
	_apply_upgrades()
	save_game()
	card("Arrived at %s" % dest, text, _next_contract, "Take a new contract")


func _fail() -> void:
	if st == "failed":
		return
	st = "failed"
	wagon.enabled = false
	ui.close_panel()
	for e in enemies:
		e["node"].queue_free()
	enemies = []
	fight_kind = ""
	var lost: int = int(floor(coin * 0.25))
	coin -= float(lost)
	town = start_name
	dest = start_name
	wagon.hp = maxf(wagon.hp, 40.0)
	cam_mode = "orbit"
	orbit_c = wagon.position + Vector3(0, 2.0, 0)
	orbit_r = 14.0
	orbit_h = 5.0
	save_game()
	ui.show_panel("The Caravan Is Lost", "Nobody is left. You crawl back to %s with whatever you can carry. You lose %d coin." % [start_name, lost], [{"t": "Return to town", "f": _next_contract}])


func _next_contract() -> void:
	contracts = []
	var pool: Array = TOWNS.duplicate()
	pool.erase(town)
	pool.shuffle()
	var risks: Array = [0, 1, 2]
	var mults: Array = [1.0, 1.4, 1.9]
	var labels: Array = ["Safe haul", "Contested road", "Warpath"]
	var descs: Array = ["Quiet roads. Fair pay.", "More bandits and tolls. Better pay.", "Raiders everywhere. Huge pay."]
	var items: Array = []
	for i in 3:
		contracts.append({"dest": pool[i], "risk": risks[i], "mult": mults[i], "name": labels[i]})
		items.append({"t": "%s  ·  to %s" % [labels[i], pool[i]], "s": "%s   Pay x%.1f" % [descs[i], mults[i]], "f": _take_contract.bind(i)})
	ask("Notice Board  ·  %s" % town, "Three caravans are looking for an escort. Pick your next job. Riskier roads pay better, and every trip gets a little harder.", items)


func _take_contract(i: int) -> void:
	contract = contracts[i]
	start_name = town
	dest = str(contract["dest"])
	var pool: Array = TOWNS.duplicate()
	pool.erase(dest)
	pool.erase(start_name)
	mid_name = pool[randi() % pool.size()]
	_begin_world()


func _begin_world() -> void:
	st = "dialog"
	ui.fade_to(1.0, 0.8)
	await get_tree().create_timer(0.9).timeout
	world.reseed(randi() % 1000, [start_name.to_upper(), mid_name.to_upper(), "CAMP", dest.to_upper()])
	hour_fixed = -1.0
	dist = 0.0
	after_camp = false
	var x0: float = world.road_x(0.0)
	wagon.place(Vector3(x0, world.height(x0, 0.0), 0.0), atan2(world.road_dx(0.0), 1.0))
	cam_mode = "orbit"
	orbit_c = wagon.position + Vector3(0, 2.0, -3.0)
	orbit_r = 17.0
	orbit_h = 5.0
	orbit_t = 0.9
	cam.position = orbit_c + Vector3(cos(orbit_t) * orbit_r, orbit_h, sin(orbit_t) * orbit_r)
	look_pt = orbit_c
	world.update(wagon.position)
	var k: int = 0
	while world.queue_size() > 0 and k < 900:
		world.work(12000)
		k += 1
		await get_tree().process_frame
	ui.fade_to(0.0, 1.0)
	hub_menu()


func hub_menu() -> void:
	_apply_upgrades()
	save_game()
	var body: String = "Next stop: %s  (%s, pay x%.1f)\nSeats %d  ·  Wagon %d%%  ·  Ammo %d/%d  ·  Food %d  Water %d  Feed %d  ·  Coin %d" % [dest, str(contract["name"]), float(contract["mult"]), capacity, int(wagon.hp), ammo, ammo_max, int(food), int(water), int(feed), int(coin)]
	ask("%s  ·  Trip %d" % [start_name, trip], body, [
		{"t": "Market", "s": "Food, water, feed, ammo, repairs.", "f": _hub_market},
		{"t": "Workshop", "s": "Upgrade the wagon.", "f": _upgrade_menu.bind("wagon")},
		{"t": "Stables", "s": "Upgrade your horses.", "f": _upgrade_menu.bind("horse")},
		{"t": "Armory", "s": "Upgrade your weapons.", "f": _upgrade_menu.bind("weapon")},
		{"t": "Crew", "s": "Recruit or dismiss companions.", "f": _crew_hub},
		{"t": "DEPART for %s" % dest, "s": "Load up %d refugees and hit the road." % capacity, "f": _depart}], 2)


func _hub_market() -> void:
	shop_menu(hub_menu)


func _upgrade_menu(group: String) -> void:
	var items: Array = []
	for id in UPG.keys():
		var u: Dictionary = UPG[id]
		if u["grp"] != group:
			continue
		var l: int = lvl(id)
		var maxed: bool = l >= int(u["max"])
		var cost: int = _upg_cost(id)
		var label: String = "%s   Lv %d/%d" % [u["name"], l, int(u["max"])]
		if not maxed:
			label += "   —   %d coin" % cost
		items.append({"t": label, "s": u["desc"], "f": _buy_upg.bind(id, group), "keep": true, "d": maxed or coin < float(cost)})
	items.append({"t": "Back", "f": hub_menu})
	var titles: Dictionary = {"wagon": "Workshop", "horse": "Stables", "weapon": "Armory"}
	ui.show_panel("%s  ·  %d coin" % [titles[group], int(coin)], "Permanent upgrades. They stay with you for every trip.", items)


func _buy_upg(id: String, group: String) -> void:
	coin -= float(_upg_cost(id))
	upg[id] = lvl(id) + 1
	_apply_upgrades()
	sfx("chime", -4.0)
	save_game()
	_upgrade_menu(group)


func _crew_hub() -> void:
	var items: Array = []
	for id in crew:
		items.append({"t": "Dismiss %s" % CREW[id]["name"], "s": "%s  ·  loyalty %d" % [CREW[id]["role"], int(loyal.get(id, 50))], "f": _dismiss.bind(id)})
	items.append({"t": "Recruit someone new", "f": _recruit_hub})
	items.append({"t": "Back", "f": hub_menu})
	ui.show_panel("Your Crew  ·  %d/3" % crew.size(), "Each companion has a gift and a flaw. Loyal friends fight harder for you.", items)


func _dismiss(id: String) -> void:
	crew.erase(id)
	_crew_hub()


func _recruit_hub() -> void:
	recruit_menu(_crew_hub)


func _depart() -> void:
	_apply_upgrades()
	party = capacity
	people = capacity
	wounded = 0
	morale = 70.0
	hour_fixed = -1.0
	after_camp = false
	warned = false
	rock_on = false
	rock_zone = false
	storm_left = 0.0
	world.set_storm(0.0)
	wagon.gust = 0.0
	wagon.water_dmg = 0.0
	wagon.ford_limit = 6.0
	river_charged = false
	broke = false
	fight_kind = ""
	for e in enemies:
		e["node"].queue_free()
	enemies = []
	dist = 0.0
	_make_events()
	cam_mode = "chase"
	cam.position = wagon.position + Vector3(0, 6, 14)
	look_pt = wagon.position
	save_game()
	ui.banner("Follow the trail", "%s to %s  ·  3,250 m" % [start_name, dest], 4.0)
	resume()


func _make_events() -> void:
	events = []
	if trip <= 1:
		events = [
			{"at": 330.0, "id": "stranger"},
			{"at": 520.0, "id": "deer"},
			{"at": 630.0, "id": "river"},
			{"at": 1010.0, "id": "ambush"},
			{"at": 1390.0, "id": "town"},
			{"at": 1800.0, "id": "storm"},
			{"at": 2190.0, "id": "rocks"},
			{"at": 2470.0, "id": "camp"},
			{"at": 3180.0, "id": "haven"}]
		ev_i = 0
		return
	var r1: float = randf()
	if r1 < 0.45:
		events.append({"at": 330.0, "id": "stranger"})
	elif r1 < 0.8:
		events.append({"at": 330.0, "id": "merchant"})
	if randf() < 0.65:
		events.append({"at": 520.0, "id": "deer"})
	events.append({"at": 630.0, "id": "river"})
	events.append({"at": 1010.0, "id": "ambush"})
	events.append({"at": 1390.0, "id": "town"})
	var r2: float = randf()
	if r2 < 0.4:
		events.append({"at": 1800.0, "id": "storm"})
	elif r2 < 0.55 + 0.15 * float(contract["risk"]):
		events.append({"at": 1800.0, "id": "toll"})
	if randf() < 0.7:
		events.append({"at": 2190.0, "id": "rocks"})
	events.append({"at": 2470.0, "id": "camp"})
	events.append({"at": 3180.0, "id": "haven"})
	ev_i = 0


func ev_merchant() -> void:
	await _halt()
	ask("Roadside Merchant", "A trader with a heavily laden mule waves you down. 'Fair prices for honest travellers. Better than the towns, I promise.'", [
		{"t": "Browse his goods", "s": "30% off everything.", "f": _merchant_shop},
		{"t": "Move on", "f": resume}])


func _merchant_shop() -> void:
	shop_mult = 0.7
	shop_menu(_merchant_done)


func _merchant_done() -> void:
	shop_mult = 1.0
	resume()


func ev_toll() -> void:
	await _halt()
	var fee: int = 25 + 8 * trip
	ask("Bandit Toll", "Armed men have strung a rope across the trail. 'Toll is %d coin,' their leader calls. 'Or we take it from your dead hands.'" % fee, [
		{"t": "Pay the toll  (%d coin)" % fee, "s": "Safe. Costs coin.", "f": _toll_pay.bind(fee), "d": coin < float(fee)},
		{"t": "Refuse and fight", "s": "They attack at once.", "f": _trap_fight},
		{"t": "Bluff: 'An army rides behind us'", "s": "50%: they back off. Otherwise a fight.", "f": _toll_bluff}])


func _toll_pay(fee: int) -> void:
	coin -= float(fee)
	card("Toll paid", "The rope drops. Nobody speaks until the bandits are out of sight.", resume)


func _toll_bluff() -> void:
	if randf() < 0.5:
		card("They blink", "The leader squints at the empty road behind you, curses, and waves you through.", resume)
	else:
		card("They don't buy it", "The leader laughs and raises his rifle.", _trap_fight, "Defend the wagon!")


# ---------- save / load ----------
func save_game() -> void:
	var d: Dictionary = {"trip": trip, "coin": coin, "upg": upg, "crew": crew, "loyal": loyal, "food": food, "water": water, "feed": feed, "ammo": ammo, "delivered": delivered, "town": town, "hp": wagon.hp}
	var f = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))
		f.close()


func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var d = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(d) != TYPE_DICTIONARY:
		return false
	trip = int(d.get("trip", 1))
	coin = float(d.get("coin", 90.0))
	upg = {}
	var su = d.get("upg", {})
	if typeof(su) == TYPE_DICTIONARY:
		for k in su.keys():
			upg[str(k)] = int(su[k])
	crew = []
	for c in d.get("crew", []):
		if CREW.has(str(c)):
			crew.append(str(c))
	loyal = {}
	var sl = d.get("loyal", {})
	if typeof(sl) == TYPE_DICTIONARY:
		for k in sl.keys():
			loyal[str(k)] = int(sl[k])
	food = float(d.get("food", 60.0))
	water = float(d.get("water", 60.0))
	feed = float(d.get("feed", 40.0))
	ammo = int(d.get("ammo", 16))
	delivered = int(d.get("delivered", 0))
	town = str(d.get("town", "Ashford"))
	dest = town
	start_name = town
	wagon.hp = float(d.get("hp", 100.0))
	return true


func _main_menu() -> void:
	st = "dialog"
	if FileAccess.file_exists(SAVE_PATH):
		ask("Wandering Caravan", "Welcome back, caravaneer. Your wagon is waiting.", [
			{"t": "Continue", "s": "Resume your saved progress.", "f": _continue_game},
			{"t": "New game", "s": "Erases your saved progress.", "f": _new_game}])
	else:
		_pick_first_companion()


func _continue_game() -> void:
	if load_game():
		_apply_upgrades()
		_next_contract()
	else:
		_pick_first_companion()


func _new_game() -> void:
	DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	_pick_first_companion()


# ---------- updates ----------
func _on_update_found(info: Dictionary) -> void:
	update_info = info
	if st != "load" and st != "intro":
		ui.banner("Update available", "%s  ·  open the Pause menu to get it" % str(info["tag"]), 5.0)


func _check_update_then(next: Callable) -> void:
	if update_info.is_empty():
		next.call()
	else:
		_show_update(next)


func _show_update(next: Callable) -> void:
	st = "dialog"
	var notes: String = str(update_info.get("notes", "")).left(280)
	var items: Array = [{"t": "Open the update page on GitHub", "s": str(update_info["url"]), "f": _open_url.bind(str(update_info["url"])), "keep": true}]
	if str(update_info.get("apk", "")) != "":
		items.append({"t": "Download the new APK", "s": "Opens your browser. Install it over this version.", "f": _open_url.bind(str(update_info["apk"])), "keep": true})
	items.append({"t": "Play without updating", "s": "Your saved progress stays on this version.", "f": next})
	ui.show_panel("Update available  ·  %s" % str(update_info["tag"]), "You are playing %s. A newer version is on GitHub.\n\n%s" % [BI.NAME, notes], items)


func _open_url(url: String) -> void:
	OS.shell_open(url)
