extends Node
# Checks GitHub for a newer release. Never blocks the game: if offline or anything fails, nothing happens.

const BI = preload("res://build_info.gd")

signal found(info)

var info: Dictionary = {}
var finished: bool = false


func check() -> void:
	if BI.REPO == "" or BI.BUILD <= 0:
		finished = true
		return
	var req = HTTPRequest.new()
	req.timeout = 8.0
	add_child(req)
	req.request_completed.connect(_done.bind(req))
	var url: String = "https://api.github.com/repos/%s/releases/latest" % BI.REPO
	var err: int = req.request(url, ["User-Agent: WanderingCaravan", "Accept: application/vnd.github+json"])
	if err != OK:
		req.queue_free()
		finished = true


func _num(t: String) -> int:
	var digits: String = ""
	for ch in t:
		if ch >= "0" and ch <= "9":
			digits += ch
	if digits == "":
		return 0
	return int(digits)


func _done(result: int, code: int, headers: PackedStringArray, body: PackedByteArray, req: HTTPRequest) -> void:
	req.queue_free()
	finished = true
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		return
	var d = JSON.parse_string(body.get_string_from_utf8())
	if typeof(d) != TYPE_DICTIONARY:
		return
	var tag: String = str(d.get("tag_name", ""))
	var num: int = _num(tag)
	if num <= BI.BUILD:
		return
	var apk: String = ""
	var assets = d.get("assets", [])
	if typeof(assets) == TYPE_ARRAY:
		for a in assets:
			if typeof(a) == TYPE_DICTIONARY and str(a.get("name", "")).ends_with(".apk"):
				apk = str(a.get("browser_download_url", ""))
	info = {"tag": tag, "num": num, "url": str(d.get("html_url", "")), "apk": apk, "notes": str(d.get("body", ""))}
	found.emit(info)
