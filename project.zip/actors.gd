extends RefCounted
# Procedural living things: horses, deer and people, built from organic lathe/ellipsoid shapes.

const M = preload("res://meshes.gd")
const Mats = preload("res://mats.gd")


static func _mi(mesh: Mesh) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	mi.mesh = mesh
	return mi


static func _part(parent: Node3D, builder: Callable, mat: Material, pos: Vector3 = Vector3.ZERO, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	builder.call(st)
	var mi = _mi(M.finish(st, mat))
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


# Returns {node, legs:[{up, low, off}], head, tail}. Faces -Z.
static func horse(coat: Color, sc: float = 1.0, deer: bool = false) -> Dictionary:
	var root = Node3D.new()
	var body = Node3D.new()
	root.add_child(body)
	body.scale = Vector3(sc, sc, sc)
	var fur: ShaderMaterial = Mats.variant("fur", {"coat": coat})
	var dark: StandardMaterial3D = Mats.std(coat.darkened(0.55), 0.8)
	_part(body, func(st): M.ellipsoid(st, Vector3(0, 1.45, 0), Vector3(0.46, 0.56, 1.1), 12, 8, 0.04, 1.5, 3), fur)
	_part(body, func(st): M.ellipsoid(st, Vector3(0, 1.52, -0.8), Vector3(0.48, 0.60, 0.5), 10, 7, 0.03, 1.5, 4), fur)
	_part(body, func(st): M.ellipsoid(st, Vector3(0, 1.55, 0.78), Vector3(0.47, 0.58, 0.56), 10, 7, 0.03, 1.5, 5), fur)
	# neck and head
	var neck = Node3D.new()
	neck.position = Vector3(0, 1.72, -1.0)
	neck.rotation.x = deg_to_rad(143.0)
	body.add_child(neck)
	_part(neck, func(st): M.limb(st, 0.27, 0.15, 0.95, 9), fur)
	var head = Node3D.new()
	head.position = Vector3(0, 2.52, -1.62)
	head.rotation.x = deg_to_rad(-38.0)
	body.add_child(head)
	_part(head, func(st): M.ellipsoid(st, Vector3(0, 0, 0), Vector3(0.15, 0.2, 0.34), 9, 6, 0.0, 1.0, 6), fur)
	_part(head, func(st): M.ellipsoid(st, Vector3(0, -0.2, -0.3), Vector3(0.11, 0.12, 0.17), 8, 5, 0.0, 1.0, 7), dark)
	for s in [-1.0, 1.0]:
		var ear_xf = Transform3D(Basis(Vector3(0, 0, 1), s * deg_to_rad(-12.0)) * Basis(Vector3(1, 0, 0), deg_to_rad(180.0)), Vector3(s * 0.09, 0.3, 0.1))
		_part(head, func(st): M.limb(st, 0.045, 0.02, 0.17, 5, ear_xf), fur)
	if deer:
		for s in [-1.0, 1.0]:
			var ant_a = Transform3D(Basis(Vector3(0, 0, 1), s * deg_to_rad(160.0)), Vector3(s * 0.08, 0.2, 0.05))
			var ant_b = Transform3D(Basis(Vector3(0, 0, 1), s * deg_to_rad(130.0)), Vector3(s * 0.22, 0.55, 0.05))
			_part(head, func(st): _antler(st, ant_a, ant_b), dark)
	else:
		# mane
		_part(neck, func(st): M.ellipsoid(st, Vector3(0, -0.45, 0.2), Vector3(0.05, 0.5, 0.1), 6, 6, 0.1, 2.0, 8), dark)
	# tail
	var tail = Node3D.new()
	tail.position = Vector3(0, 1.85, 1.28)
	tail.rotation.x = deg_to_rad(-20.0)
	body.add_child(tail)
	_part(tail, func(st): M.limb(st, 0.09, 0.05, 0.85 if not deer else 0.3, 6), dark)
	# legs
	var legs: Array = []
	var spots: Array = [Vector3(-0.27, 1.1, -0.78), Vector3(0.27, 1.1, -0.78), Vector3(-0.27, 1.1, 0.78), Vector3(0.27, 1.1, 0.78)]
	var offs: Array = [0.0, PI, PI, 0.0]
	for i in 4:
		var up = Node3D.new()
		up.position = spots[i]
		body.add_child(up)
		_part(up, func(st): M.limb(st, 0.14, 0.09, 0.55, 7), fur)
		var low = Node3D.new()
		low.position = Vector3(0, -0.55, 0)
		up.add_child(low)
		_part(low, func(st): M.limb(st, 0.075, 0.055, 0.5, 6), fur)
		_part(low, func(st): M.limb(st, 0.07, 0.085, 0.1, 6, Transform3D(Basis.IDENTITY, Vector3(0, -0.5, 0))), dark)
		legs.append({"up": up, "low": low, "off": offs[i]})
	return {"node": root, "body": body, "legs": legs, "head": head, "tail": tail}


static func _antler(st: SurfaceTool, a: Transform3D, b: Transform3D) -> void:
	M.limb(st, 0.025, 0.012, 0.5, 5, a)
	M.limb(st, 0.02, 0.01, 0.3, 5, b)


static func gait(h: Dictionary, phase: float, amp: float) -> void:
	for l in h.legs:
		var s: float = sin(phase + l.off)
		l.up.rotation.x = s * amp
		l.low.rotation.x = -(0.45 + 0.55 * sin(phase + l.off - 1.1)) * amp * 1.3
	h.body.position.y = absf(sin(phase)) * 0.05 * amp
	h.head.rotation.x = deg_to_rad(-38.0) + sin(phase * 2.0) * 0.06 * amp
	h.tail.rotation.z = sin(phase * 0.5) * 0.25 * amp


# Returns {node, armL, armR, legL, legR}. Faces -Z, origin at feet (seated: origin at hips).
static func human(shirt: Color, hat: bool = true, mask: bool = false, seated: bool = false, skin: Color = Color(0.78, 0.58, 0.44)) -> Dictionary:
	var root = Node3D.new()
	var cloth: StandardMaterial3D = Mats.std(shirt, 0.9)
	var pants: StandardMaterial3D = Mats.std(shirt.darkened(0.55), 0.9)
	var skm: StandardMaterial3D = Mats.std(skin, 0.7)
	var y0: float = 0.0 if seated else 0.95
	_part(root, func(st): M.ellipsoid(st, Vector3(0, y0 + 0.62, 0), Vector3(0.25, 0.36, 0.17), 10, 7, 0.02, 2.0, 11), cloth)
	_part(root, func(st): M.ellipsoid(st, Vector3(0, y0 + 1.1, 0), Vector3(0.12, 0.15, 0.13), 9, 6, 0.0, 1.0, 12), skm)
	_part(root, func(st): M.ellipsoid(st, Vector3(0, y0 + 1.06, -0.12), Vector3(0.03, 0.04, 0.045), 5, 4), skm)
	if mask:
		_part(root, func(st): M.ellipsoid(st, Vector3(0, y0 + 1.03, -0.02), Vector3(0.135, 0.09, 0.14), 8, 5), Mats.std(Color(0.45, 0.08, 0.06), 0.9))
	if hat:
		_part(root, func(st): M.lathe(st, [Vector2(0.0, 0.17), Vector2(0.12, 0.16), Vector2(0.155, 0.10), Vector2(0.16, 0.03), Vector2(0.29, 0.02), Vector2(0.32, 0.0), Vector2(0.0, -0.005)], 14, Transform3D(Basis.IDENTITY, Vector3(0, y0 + 1.19, 0))), Mats.std(Color(0.16, 0.11, 0.08), 0.85))
	var arms: Array = []
	for s in [-1.0, 1.0]:
		var sh = Node3D.new()
		sh.position = Vector3(s * 0.28, y0 + 0.88, 0)
		root.add_child(sh)
		_part(sh, func(st): M.limb(st, 0.075, 0.06, 0.32, 7), cloth)
		var el = Node3D.new()
		el.position = Vector3(0, -0.32, 0)
		sh.add_child(el)
		_part(el, func(st): M.limb(st, 0.06, 0.045, 0.3, 7), cloth)
		_part(el, func(st): M.ellipsoid(st, Vector3(0, -0.34, 0), Vector3(0.05, 0.06, 0.05), 6, 4), skm)
		arms.append({"up": sh, "low": el})
	var legs: Array = []
	for s in [-1.0, 1.0]:
		var hp = Node3D.new()
		hp.position = Vector3(s * 0.12, y0 + 0.28, 0)
		root.add_child(hp)
		_part(hp, func(st): M.limb(st, 0.11, 0.08, 0.46, 7), pants)
		var kn = Node3D.new()
		kn.position = Vector3(0, -0.46, 0)
		hp.add_child(kn)
		_part(kn, func(st): M.limb(st, 0.08, 0.06, 0.44, 7), pants)
		_part(kn, func(st): M.ellipsoid(st, Vector3(0, -0.5, -0.05), Vector3(0.065, 0.05, 0.12), 6, 4), Mats.std(Color(0.1, 0.07, 0.05), 0.8))
		legs.append({"up": hp, "low": kn})
	if seated:
		for l in legs:
			l.up.rotation.x = deg_to_rad(80.0)
			l.low.rotation.x = deg_to_rad(-70.0)
		for a in arms:
			a.up.rotation.x = deg_to_rad(40.0)
			a.low.rotation.x = deg_to_rad(40.0)
	return {"node": root, "arms": arms, "legs": legs}


static func walk(h: Dictionary, phase: float, amp: float) -> void:
	h.legs[0].up.rotation.x = sin(phase) * amp
	h.legs[1].up.rotation.x = -sin(phase) * amp
	h.legs[0].low.rotation.x = -maxf(0.0, -sin(phase)) * amp * 1.2
	h.legs[1].low.rotation.x = -maxf(0.0, sin(phase)) * amp * 1.2
	h.arms[0].up.rotation.x = -sin(phase) * amp * 0.7
	h.arms[1].up.rotation.x = sin(phase) * amp * 0.7


# Horse with a rider sitting on it. Returns the horse dict plus "rider".
static func rider(coat: Color, shirt: Color, mask: bool) -> Dictionary:
	var h: Dictionary = horse(coat, 1.0)
	var hm: Dictionary = human(shirt, true, mask, true)
	hm.node.position = Vector3(0, 1.95, 0.12)
	h.body.add_child(hm.node)
	for l in hm.legs:
		l.up.rotation.x = deg_to_rad(20.0)
		l.low.rotation.x = deg_to_rad(-25.0)
	for a in hm.arms:
		a.up.rotation.x = deg_to_rad(55.0)
		a.low.rotation.x = deg_to_rad(50.0)
	h["rider"] = hm
	return h
