extends RefCounted
# Low-poly living things (one merged mesh per body part group), built with vertex colours.

const M = preload("res://meshes.gd")
const Mats = preload("res://mats.gd")


static func _mi(mesh: Mesh, parent: Node3D, pos: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


static func _xf(rx: float, pos: Vector3) -> Transform3D:
	return Transform3D(Basis(Vector3.RIGHT, deg_to_rad(rx)), pos)


# Returns {node, body, legs:[{up, low, off}], head, tail}. Faces -Z.
static func horse(coat: Color, sc: float = 1.0, deer: bool = false) -> Dictionary:
	var root = Node3D.new()
	var body = Node3D.new()
	body.scale = Vector3(sc, sc, sc)
	root.add_child(body)
	var dark: Color = coat.darkened(0.55)
	var st = M.new_st()
	M.ellipsoid(st, Vector3(0, 1.45, 0), Vector3(0.46, 0.56, 1.1), 8, 5, 0.0, 1.0, 3, coat, Basis.IDENTITY, 0.25)
	M.ellipsoid(st, Vector3(0, 1.52, -0.8), Vector3(0.48, 0.6, 0.5), 8, 5, 0.0, 1.0, 4, coat, Basis.IDENTITY, 0.2)
	M.ellipsoid(st, Vector3(0, 1.55, 0.78), Vector3(0.47, 0.58, 0.56), 8, 5, 0.0, 1.0, 5, coat, Basis.IDENTITY, 0.2)
	M.limb(st, 0.27, 0.15, 0.95, 7, _xf(143.0, Vector3(0, 1.72, -1.0)), coat)
	var hb: Basis = Basis(Vector3.RIGHT, deg_to_rad(-38.0))
	M.ellipsoid(st, Vector3(0, 2.52, -1.62), Vector3(0.15, 0.2, 0.34), 7, 5, 0.0, 1.0, 6, coat, hb)
	M.ellipsoid(st, Vector3(0, 2.29, -1.86), Vector3(0.11, 0.12, 0.17), 6, 4, 0.0, 1.0, 7, dark, hb)
	for s in [-1.0, 1.0]:
		M.limb(st, 0.045, 0.02, 0.17, 5, _xf(180.0, Vector3(s * 0.09, 2.62, -1.5)), coat)
	if deer:
		for s in [-1.0, 1.0]:
			var ax: Transform3D = Transform3D(Basis(Vector3(0, 0, 1), s * deg_to_rad(160.0)), Vector3(s * 0.08, 2.7, -1.5))
			M.limb(st, 0.025, 0.012, 0.5, 4, ax, dark)
	else:
		M.ellipsoid(st, Vector3(0, 2.22, -1.2), Vector3(0.05, 0.5, 0.1), 5, 4, 0.0, 1.0, 8, dark, Basis(Vector3.RIGHT, deg_to_rad(-37.0)))
	M.limb(st, 0.09, 0.05, 0.85 if not deer else 0.3, 5, _xf(-20.0, Vector3(0, 1.85, 1.28)), dark)
	_mi(M.finish(st, Mats.vcol()), body)
	var head = Node3D.new()
	body.add_child(head)
	var tail = Node3D.new()
	body.add_child(tail)
	var legs: Array = []
	var spots: Array = [Vector3(-0.27, 1.1, -0.78), Vector3(0.27, 1.1, -0.78), Vector3(-0.27, 1.1, 0.78), Vector3(0.27, 1.1, 0.78)]
	var offs: Array = [0.0, PI, PI, 0.0]
	for i in 4:
		var up = Node3D.new()
		up.position = spots[i]
		body.add_child(up)
		var ls = M.new_st()
		M.limb(ls, 0.13, 0.07, 1.05, 6, Transform3D.IDENTITY, coat)
		M.ellipsoid(ls, Vector3(0, -1.12, -0.02), Vector3(0.07, 0.05, 0.1), 5, 3, 0.0, 1.0, 9, dark)
		_mi(M.finish(ls, Mats.vcol()), up)
		var low = Node3D.new()
		up.add_child(low)
		legs.append({"up": up, "low": low, "off": offs[i]})
	return {"node": root, "body": body, "legs": legs, "head": head, "tail": tail}


static func gait(h: Dictionary, phase: float, amp: float) -> void:
	for l in h["legs"]:
		var s: float = sin(phase + l["off"])
		l["up"].rotation.x = s * amp
	h["body"].position.y = absf(sin(phase)) * 0.05 * amp
	h["tail"].rotation.z = sin(phase * 0.5) * 0.25 * amp


# Returns {node, arms:[{up, low}], legs:[{up, low}]}. Faces -Z. Origin at feet (or at hips when seated/riding).
static func human(shirt: Color, hat: bool = true, mask: bool = false, seated: bool = false, ride: bool = false, skin: Color = Color(0.78, 0.58, 0.44)) -> Dictionary:
	var root = Node3D.new()
	var pants: Color = shirt.darkened(0.55)
	var boot: Color = Color(0.1, 0.07, 0.05)
	var sit: bool = seated or ride
	var y0: float = 0.0 if sit else 0.95
	var st = M.new_st()
	M.ellipsoid(st, Vector3(0, y0 + 0.62, 0), Vector3(0.25, 0.36, 0.17), 8, 5, 0.0, 1.0, 11, shirt, Basis.IDENTITY, 0.2)
	M.ellipsoid(st, Vector3(0, y0 + 1.1, 0), Vector3(0.12, 0.15, 0.13), 7, 5, 0.0, 1.0, 12, skin)
	if mask:
		M.ellipsoid(st, Vector3(0, y0 + 1.03, -0.02), Vector3(0.135, 0.09, 0.14), 7, 4, 0.0, 1.0, 13, Color(0.45, 0.08, 0.06))
	if hat:
		var hp: Array = [Vector2(0.0, 0.17), Vector2(0.13, 0.15), Vector2(0.16, 0.03), Vector2(0.31, 0.02), Vector2(0.0, 0.0)]
		M.lathe(st, hp, 8, Transform3D(Basis.IDENTITY, Vector3(0, y0 + 1.19, 0)), 0.0, 1.0, 1, Color(0.16, 0.11, 0.08))
	var arm_ang: float = 0.0
	if seated and not ride:
		arm_ang = -45.0
	elif ride:
		arm_ang = -55.0
	var arms: Array = []
	for s in [-1.0, 1.0]:
		var sp: Vector3 = Vector3(s * 0.28, y0 + 0.88, 0)
		M.limb(st, 0.075, 0.05, 0.62, 6, Transform3D(Basis(Vector3.RIGHT, deg_to_rad(arm_ang)), sp), shirt)
		var up = Node3D.new()
		up.position = sp
		root.add_child(up)
		var low = Node3D.new()
		low.position = Vector3(0, -0.4, -0.35)
		up.add_child(low)
		arms.append({"up": up, "low": low})
	var legs: Array = []
	if sit:
		for s in [-1.0, 1.0]:
			var hip: Vector3 = Vector3(s * (0.2 if ride else 0.12), y0 + 0.28, 0)
			var th_ang: float = 25.0 if ride else 80.0
			var thigh: Transform3D = Transform3D(Basis(Vector3.RIGHT, deg_to_rad(th_ang)), hip)
			M.limb(st, 0.11, 0.08, 0.5, 6, thigh, pants)
			var kd: Vector3 = Vector3(0, -cos(deg_to_rad(th_ang)), -sin(deg_to_rad(th_ang))) * 0.5
			var knee: Vector3 = hip + kd
			M.limb(st, 0.08, 0.06, 0.5, 6, Transform3D(Basis.IDENTITY, knee), pants)
			M.ellipsoid(st, knee + Vector3(0, -0.56, -0.05), Vector3(0.065, 0.05, 0.12), 5, 3, 0.0, 1.0, 14, boot)
			var d1 = Node3D.new()
			root.add_child(d1)
			legs.append({"up": d1, "low": d1})
	else:
		for s in [-1.0, 1.0]:
			var hp2 = Node3D.new()
			hp2.position = Vector3(s * 0.12, y0 + 0.28, 0)
			root.add_child(hp2)
			var ls = M.new_st()
			M.limb(ls, 0.11, 0.07, 0.9, 6, Transform3D.IDENTITY, pants)
			M.ellipsoid(ls, Vector3(0, -0.98, -0.05), Vector3(0.065, 0.05, 0.12), 5, 3, 0.0, 1.0, 14, boot)
			_mi(M.finish(ls, Mats.vcol()), hp2)
			var kn = Node3D.new()
			hp2.add_child(kn)
			legs.append({"up": hp2, "low": kn})
	_mi(M.finish(st, Mats.vcol()), root)
	return {"node": root, "arms": arms, "legs": legs}


static func walk(h: Dictionary, phase: float, amp: float) -> void:
	h["legs"][0]["up"].rotation.x = sin(phase) * amp
	h["legs"][1]["up"].rotation.x = -sin(phase) * amp


# Horse with a rider. Returns the horse dict plus "rider".
static func rider(coat: Color, shirt: Color, mask: bool) -> Dictionary:
	var h: Dictionary = horse(coat, 1.0)
	var hm: Dictionary = human(shirt, true, mask, true, true)
	hm["node"].position = Vector3(0, 1.95, 0.12)
	h["body"].add_child(hm["node"])
	h["rider"] = hm
	return h
