extends Node
# Boot screen with built-in diagnostics, so a failure shows up as text instead of a blank screen.

const SCRIPTS = ["mats", "meshes", "sfx", "actors", "wagon", "world", "ui", "game"]

var layer: CanvasLayer
var label: Label
var game = null
var lines: Array = []
var elapsed: float = 0.0


func _ready() -> void:
	layer = CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	var bg = ColorRect.new()
	bg.color = Color(0.04, 0.045, 0.06)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(bg)
	label = Label.new()
	label.set_anchors_preset(Control.PRESET_FULL_RECT)
	label.offset_left = 48.0
	label.offset_top = 36.0
	label.offset_right = -48.0
	label.offset_bottom = -36.0
	label.add_theme_font_size_override("font_size", 28)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	layer.add_child(label)
	set_process(false)
	_log("WANDERING CARAVAN  -  starting")
	var info: Dictionary = Engine.get_version_info()
	_log("Godot %s   |   %s   |   GPU: %s" % [str(info.get("string", "?")), OS.get_name(), RenderingServer.get_video_adapter_name()])
	_log("Renderer setting: %s" % str(ProjectSettings.get_setting("rendering/renderer/rendering_method")))
	await get_tree().process_frame
	await get_tree().process_frame
	_boot()


func _log(s: String) -> void:
	lines.append(s)
	label.text = "\n".join(lines)


func _boot() -> void:
	var bad: Array = []
	for n in SCRIPTS:
		var s = load("res://%s.gd" % n)
		if s == null or not s.can_instantiate():
			bad.append(n)
			_log("FAILED to compile:  %s.gd" % n)
		else:
			_log("ok   %s.gd" % n)
		await get_tree().process_frame
	if bad.size() > 0:
		_log("")
		_log("Please send me a screenshot of this screen.")
		return
	_log("Scripts OK. Creating the game...")
	await get_tree().process_frame
	var gs = load("res://game.gd")
	game = gs.new()
	add_child(game)
	set_process(true)


func _process(delta: float) -> void:
	elapsed += delta
	if game == null:
		return
	var st = game.get("st")
	if str(st) != "load":
		layer.queue_free()
		set_process(false)
		return
	var stage: String = str(game.get("stage"))
	var wst: String = ""
	var w = game.get("world")
	if w != null:
		wst = str(w.get("stage"))
	var txt: String = "\n".join(lines)
	txt += "\n\nLoading...  %.0f s   |   %d fps" % [elapsed, int(Engine.get_frames_per_second())]
	txt += "\nGame stage: %s" % stage
	txt += "\nWorld stage: %s" % wst
	label.text = txt
