extends Node3D
# The living world: streamed procedural terrain, sky, weather, forests, river, towns and the gates of Haven.

const M = preload("res://meshes.gd")
const Mats = preload("res://mats.gd")

const CH: float = 128.0
const CELLS: int = 32
const RIVER_Z: float = -720.0
const SZ: Array = [0.0, -1400.0, -2480.0, -3250.0]
const NAMES: Array = ["ASHFORD", "MILLBROOK", "CAMP", "HAVEN"]

var n_hill: FastNoiseLite
var n_det: FastNoiseLite
var n_rid: FastNoiseLite
var n_for: FastNoiseLite
var f0: float = 0.0
var river_lvl: float = 0.0

var chunks: Dictionary = {}
var obstacles: Dictionary = {}
var extra_obs: Dictionary = {}
var settle_nodes: Dictionary = {}
var rad: int = 3
var grass_on: bool = true
var quality: int = 1
var lib: Dictionary = {}
var foliage_mats: Array = []
var win_mats: Array = []
var lamps: Array = []
var flickers: Array = []

var env: Environment
var sun: DirectionalLight3D
var sky_mat: ShaderMaterial
var terrain_mat: ShaderMaterial
var water: MeshInstance3D

var stage: String = "init"
var hour: float = 9.0
var storm: float = 0.0
var storm_target: float = 0.0
var flash: float = 0.0
var night_amt: float = 0.0
var sun_energy: float = 1.0
var cloud_t: float = 0.0
var applied_hour: float = -99.0
var applied_storm: float = -99.0
var tick: int = 0
var chunk_cd: int = 0


func _ready() -> void:
	stage = "noise"
	f0 = road_f(0.0)
	river_lvl = road_h(RIVER_Z)
	n_hill = FastNoiseLite.new()
	n_hill.seed = 11
	n_hill.frequency = 0.0017
	n_hill.fractal_octaves = 3
	n_det = FastNoiseLite.new()
	n_det.seed = 12
	n_det.frequency = 0.02
	n_det.fractal_octaves = 2
	n_rid = FastNoiseLite.new()
	n_rid.seed = 13
	n_rid.frequency = 0.0011
	n_rid.fractal_octaves = 2
	n_for = FastNoiseLite.new()
	n_for.seed = 14
	n_for.frequency = 0.004
	terrain_mat = Mats.get_mat("terrain")
	stage = "meshes"
	_build_lib()
	stage = "environment"
	_setup_env()
	stage = "water"
	_build_water()
	stage = "quality"
	set_quality(1)
	stage = "time"
	_apply_time()
	stage = "ready"


# ---------- terrain functions ----------
func road_f(z: float) -> float:
	return 34.0 * sin(z * 0.0045) + 20.0 * sin(z * 0.0118 + 1.3) + 6.0 * sin(z * 0.027 + 0.4)


func road_x(z: float) -> float:
	return road_f(z) - f0


func road_dx(z: float) -> float:
	return (road_f(z + 1.0) - road_f(z - 1.0)) * 0.5


func road_h(z: float) -> float:
	return 10.0 * sin(z * 0.0021 + 0.7) + 4.0 * sin(z * 0.0063)


func settle_f(z: float) -> float:
	var f: float = 1.0
	for sz in SZ:
		f = minf(f, 0.12 + 0.88 * smoothstep(50.0, 150.0, absf(z - sz)))
	return f


func height(x: float, z: float) -> float:
	var dr: float = absf(x - road_x(z))
	var t: float = smoothstep(6.0, 95.0, dr)
	var sf: float = settle_f(z)
	var hills: float = (n_hill.get_noise_2d(x, z) * 26.0 + n_det.get_noise_2d(x, z) * 3.2) * sf
	var mt: float = smoothstep(150.0, 540.0, dr)
	var rg: float = maxf(0.0, n_rid.get_noise_2d(x * 0.8, z * 0.8) + 0.22)
	hills += rg * rg * 280.0 * mt
	var h: float = road_h(z) + hills * t
	var dz: float = absf(z - RIVER_Z)
	if dz < 40.0:
		var w: float = (1.0 - smoothstep(12.0, 30.0, dz)) * (1.0 - smoothstep(70.0, 125.0, dr))
		var rw: float = 1.0 - smoothstep(4.5, 11.0, dr)
		var bed: float = lerpf(river_lvl - 3.2, river_lvl - 0.5, rw)
		h = lerpf(h, bed, w)
		var gr: float = river_lvl - 3.6 + 5.2 * smoothstep(80.0, 125.0, dr)
		var g: float = lerpf(gr, river_lvl + 0.35, smoothstep(14.0, 22.0, dz))
		h = lerpf(h, maxf(h, g), 1.0 - smoothstep(30.0, 40.0, dz))
	return h


func depth_at(x: float, z: float) -> float:
	if absf(z - RIVER_Z) > 22.0:
		return 0.0
	if absf(x - road_x(RIVER_Z)) > 130.0:
		return 0.0
	return maxf(0.0, (river_lvl - 0.1) - height(x, z))


func camp_pos() -> Vector3:
	var z: float = SZ[2]
	var x: float = road_x(z) + 16.0
	return Vector3(x, height(x, z), z)


func gate_pos() -> Vector3:
	var z: float = SZ[3]
	var x: float = road_x(z)
	return Vector3(x, height(x, z), z)


# ---------- mesh library ----------
func _pine(tiers: int, seg: int) -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	M.lathe(st, [Vector2(0.0, 9.0), Vector2(0.13, 8.7), Vector2(0.2, 6.0), Vector2(0.36, 2.0), Vector2(0.55, 0.0), Vector2(0.75, -0.6)], 7, Transform3D.IDENTITY, 0.12, 0.9, 3, Vector2(1.0, 3.0))
	var mesh: ArrayMesh = M.finish(st, Mats.variant("bark", {"c1": Color(0.20, 0.14, 0.09), "c2": Color(0.34, 0.24, 0.16)}))
	var st2 = SurfaceTool.new()
	st2.begin(Mesh.PRIMITIVE_TRIANGLES)
	for k in tiers:
		var t: float = float(k) / float(tiers - 1)
		var yt: float = 10.3 - t * 6.3
		var r: float = 0.6 + t * 2.3
		var h: float = 2.2 + t * 0.7
		var prof: Array = [Vector2(0.0, yt), Vector2(r * 0.5, yt - h * 0.5), Vector2(r, yt - h), Vector2(r * 0.55, yt - h - 0.35), Vector2(0.05, yt - h - 0.4)]
		M.lathe(st2, prof, seg, Transform3D.IDENTITY, 0.28, 1.2, 11 + k, Vector2(1.0, 1.0))
	var fm: ShaderMaterial = Mats.variant("foliage", {"c_dark": Color(0.02, 0.09, 0.05), "c_light": Color(0.10, 0.25, 0.10), "hs": 10.3, "sway": 0.3})
	foliage_mats.append(fm)
	M.finish(st2, fm, mesh)
	return mesh


func _broad(birch: bool) -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var tr: float = 0.16 if birch else 0.3
	M.lathe(st, [Vector2(0.0, 5.0), Vector2(tr * 0.6, 4.8), Vector2(tr, 3.0), Vector2(tr * 1.25, 0.8), Vector2(tr * 1.7, -0.5)], 8, Transform3D.IDENTITY, 0.1, 0.8, 5, Vector2(1.0, 2.0))
	var bm: ShaderMaterial
	if birch:
		bm = Mats.variant("bark", {"c1": Color(0.82, 0.80, 0.74), "c2": Color(0.62, 0.60, 0.55), "spot": 1.0})
	else:
		bm = Mats.variant("bark", {"c1": Color(0.17, 0.12, 0.08), "c2": Color(0.30, 0.22, 0.14)})
	var mesh: ArrayMesh = M.finish(st, bm)
	var st2 = SurfaceTool.new()
	st2.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng = RandomNumberGenerator.new()
	rng.seed = 77 if birch else 78
	for i in 7:
		var c: Vector3 = Vector3(rng.randf_range(-1.5, 1.5), 4.4 + rng.randf() * 2.4, rng.randf_range(-1.5, 1.5))
		var s: float = 1.2 if birch else 1.6
		var r: Vector3 = Vector3(s, s * 0.82, s) * rng.randf_range(0.8, 1.25)
		M.ellipsoid(st2, c, r, 9, 6, 0.32, 1.4, 30 + i)
	var cl: Color = Color(0.20, 0.34, 0.07) if birch else Color(0.09, 0.22, 0.05)
	var fm: ShaderMaterial = Mats.variant("foliage", {"c_dark": cl.darkened(0.5), "c_light": cl.lightened(0.2), "hs": 8.0, "sway": 0.45})
	foliage_mats.append(fm)
	M.finish(st2, fm, mesh)
	return mesh


func _rock(sd: int) -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	M.ellipsoid(st, Vector3(0, 0.3, 0), Vector3(1.0, 0.7, 0.85), 9, 6, 0.4, 1.1, sd)
	return M.finish(st, Mats.get_mat("rock"))


func _bush() -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	M.ellipsoid(st, Vector3(0, 0.4, 0), Vector3(0.8, 0.55, 0.8), 8, 5, 0.3, 2.0, 41)
	M.ellipsoid(st, Vector3(0.6, 0.3, 0.3), Vector3(0.55, 0.4, 0.55), 8, 5, 0.3, 2.0, 42)
	M.ellipsoid(st, Vector3(-0.5, 0.3, -0.3), Vector3(0.6, 0.45, 0.6), 8, 5, 0.3, 2.0, 43)
	var fm: ShaderMaterial = Mats.variant("foliage", {"c_dark": Color(0.04, 0.12, 0.04), "c_light": Color(0.15, 0.28, 0.08), "hs": 1.0, "sway": 0.1})
	foliage_mats.append(fm)
	return M.finish(st, fm)


func _build_lib() -> void:
	lib["pine_hi"] = _pine(5, 9)
	lib["pine_lo"] = _pine(3, 6)
	lib["oak"] = _broad(false)
	lib["birch"] = _broad(true)
	lib["rocks"] = [_rock(1), _rock(2), _rock(3)]
	lib["bush"] = _bush()
	lib["tuft"] = M.tuft(Mats.get_mat("grass"))


# ---------- environment ----------
func _setup_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	sky_mat = Mats.variant("sky", {})
	var sky = Sky.new()
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_128
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_sky_contribution = 0.7
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 6.0
	env.glow_enabled = true
	env.glow_intensity = 0.75
	env.glow_bloom = 0.04
	env.glow_hdr_threshold = 1.0
	env.fog_enabled = true
	env.fog_sky_affect = 0.0
	env.fog_density = 0.0009
	env.fog_sun_scatter = 0.25
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 1.12
	var we = WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_blend_splits = true
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.2
	sun.light_angular_distance = 0.4
	add_child(sun)


func _build_water() -> void:
	var pm = PlaneMesh.new()
	pm.size = Vector2(260.0, 44.0)
	water = MeshInstance3D.new()
	water.mesh = pm
	water.material_override = Mats.get_mat("water")
	water.position = Vector3(road_x(RIVER_Z), river_lvl - 0.1, RIVER_Z)
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(water)


func set_quality(q: int) -> void:
	quality = q
	var vp: Viewport = get_viewport()
	if q == 0:
		rad = 2
		grass_on = false
		sun.shadow_enabled = false
		if vp:
			vp.msaa_3d = Viewport.MSAA_DISABLED
	elif q == 1:
		rad = 3
		grass_on = true
		sun.shadow_enabled = true
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		sun.directional_shadow_max_distance = 110.0
		if vp:
			vp.msaa_3d = Viewport.MSAA_2X
	else:
		rad = 3
		grass_on = true
		sun.shadow_enabled = true
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
		sun.directional_shadow_max_distance = 170.0
		if vp:
			vp.msaa_3d = Viewport.MSAA_4X


func set_hour(h: float) -> void:
	hour = h


func set_storm(v: float) -> void:
	storm_target = v


func _apply_time() -> void:
	applied_hour = hour
	applied_storm = storm
	var ang: float = (hour - 6.0) / 12.0 * PI
	var el: float = sin(ang)
	var sun_v: Vector3 = Vector3(cos(ang), el, -0.3).normalized()
	var day: float = smoothstep(0.02, 0.5, el)
	var gold: float = smoothstep(-0.18, 0.02, el)
	night_amt = 1.0 - gold
	var top: Color = Color(0.01, 0.02, 0.06).lerp(Color(0.20, 0.33, 0.62), gold).lerp(Color(0.15, 0.36, 0.78), day)
	var hor: Color = Color(0.05, 0.07, 0.14).lerp(Color(1.0, 0.52, 0.25), gold).lerp(Color(0.60, 0.74, 0.90), day)
	var lightk: float = clampf(el * 3.0 + 0.25, 0.04, 1.0)
	var grey: Color = Color(0.26, 0.28, 0.32) * (0.2 + 0.8 * lightk)
	top = top.lerp(grey, storm * 0.85)
	hor = hor.lerp(grey * 1.1, storm * 0.9)
	var use_moon: bool = el < -0.06
	var ldir: Vector3 = -sun_v if use_moon else sun_v
	var sun_c: Color = Color(1.0, 0.55, 0.28).lerp(Color(1.0, 0.95, 0.85), smoothstep(0.0, 0.45, el))
	var e_sun: float = 1.7 * smoothstep(-0.06, 0.22, el) * (1.0 - 0.65 * storm)
	var e_moon: float = 0.34 * smoothstep(-0.06, -0.35, el) * (1.0 - 0.4 * storm)
	sun_energy = e_moon if use_moon else e_sun
	sun.light_color = Color(0.55, 0.66, 1.0) if use_moon else sun_c
	sun.transform.basis = Basis.looking_at(-ldir, Vector3.UP)
	sky_mat.set_shader_parameter("top_col", top)
	sky_mat.set_shader_parameter("hor_col", hor)
	sky_mat.set_shader_parameter("gnd_col", hor.darkened(0.6))
	sky_mat.set_shader_parameter("sun_dir", ldir)
	sky_mat.set_shader_parameter("sun_col", (Color(0.7, 0.8, 1.0) * 0.5) if use_moon else sun_c)
	sky_mat.set_shader_parameter("sun_vis", 1.0 - storm * 0.9)
	sky_mat.set_shader_parameter("cloud_cover", 0.40 + 0.5 * storm)
	sky_mat.set_shader_parameter("cloud_lit", Color(1.0, 0.95, 0.9) * lightk)
	sky_mat.set_shader_parameter("cloud_shade", Color(0.55, 0.60, 0.72) * lightk * 0.6)
	sky_mat.set_shader_parameter("star_vis", night_amt * (1.0 - storm))
	env.ambient_light_color = Color(0.22, 0.30, 0.50).lerp(Color(0.40, 0.48, 0.62), day)
	env.ambient_light_energy = lerpf(0.95, 0.6, day) * (1.0 - 0.25 * storm)
	env.fog_light_color = hor.darkened(0.12)
	env.fog_density = 0.00085 + 0.0012 * (1.0 - day) * gold + storm * 0.0035
	env.tonemap_exposure = lerpf(1.0, 1.5, night_amt)
	terrain_mat.set_shader_parameter("wet", storm)
	for m in foliage_mats:
		m.set_shader_parameter("wind", 1.0 + storm * 2.5)
	for wm in win_mats:
		wm.emission_energy_multiplier = night_amt * 2.6
	for l in lamps:
		if is_instance_valid(l):
			l.light_energy = night_amt * 1.7


# ---------- streaming ----------
func pending(pos: Vector3) -> int:
	var cc: Vector2i = Vector2i(floori(pos.x / CH), floori(pos.z / CH))
	var n: int = 0
	for dz in range(-rad, rad + 1):
		for dx in range(-rad, rad + 1):
			if not chunks.has(Vector2i(cc.x + dx, cc.y + dz)):
				n += 1
	return n


func stream(pos: Vector3, budget: int) -> int:
	var cc: Vector2i = Vector2i(floori(pos.x / CH), floori(pos.z / CH))
	var need: Array = []
	for dz in range(-rad, rad + 1):
		for dx in range(-rad, rad + 1):
			var c: Vector2i = Vector2i(cc.x + dx, cc.y + dz)
			if not chunks.has(c):
				need.append(c)
	need.sort_custom(func(a, b): return (a - cc).length_squared() < (b - cc).length_squared())
	var built: int = 0
	while built < budget and built < need.size():
		_make_chunk(need[built])
		built += 1
	var drop: Array = []
	for c in chunks.keys():
		var d: int = maxi(absi(c.x - cc.x), absi(c.y - cc.y))
		if d > rad + 1:
			drop.append(c)
		else:
			_detail(c, d <= 1)
	for c in drop:
		chunks[c]["root"].queue_free()
		chunks.erase(c)
		obstacles.erase(c)
	_settlements(pos)
	return need.size() - built


func _detail(c: Vector2i, near: bool) -> void:
	var d: Dictionary = chunks[c]
	if d["hi"] != near:
		d["hi"] = near
		if d["pine"] != null:
			d["pine"].multimesh.mesh = lib["pine_hi"] if near else lib["pine_lo"]
	if near and grass_on and d["grass"] == null:
		_add_grass(c, d)
	elif (not near or not grass_on) and d["grass"] != null:
		d["grass"].queue_free()
		d["grass"] = null


func _blocked(x: float, z: float, dr: float) -> bool:
	if absf(z - RIVER_Z) < 46.0 and dr < 135.0:
		return true
	for sz in SZ:
		if absf(z - sz) < 70.0 and dr < 62.0:
			return true
	return false


func _mm(root: Node3D, mesh: Mesh, xforms: Array, shadow: bool) -> MultiMeshInstance3D:
	if xforms.is_empty():
		return null
	var mm = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var mmi = MultiMeshInstance3D.new()
	mmi.multimesh = mm
	if not shadow:
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mmi)
	return mmi


func _make_chunk(c: Vector2i) -> void:
	var root = Node3D.new()
	add_child(root)
	var x0: float = c.x * CH
	var z0: float = c.y * CH
	var cs: float = CH / float(CELLS)
	var n: int = CELLS + 1
	var m: int = n + 2
	var hs = PackedFloat32Array()
	hs.resize(m * m)
	for j in m:
		for i in m:
			hs[j * m + i] = height(x0 + float(i - 1) * cs, z0 + float(j - 1) * cs)
	var verts = PackedVector3Array()
	var norms = PackedVector3Array()
	verts.resize(n * n)
	norms.resize(n * n)
	for j in n:
		for i in n:
			var k: int = (j + 1) * m + (i + 1)
			verts[j * n + i] = Vector3(x0 + float(i) * cs, hs[k], z0 + float(j) * cs)
			norms[j * n + i] = Vector3(hs[k - 1] - hs[k + 1], 2.0 * cs, hs[k - m] - hs[k + m]).normalized()
	var idx = PackedInt32Array()
	idx.resize(CELLS * CELLS * 6)
	var q: int = 0
	for j in CELLS:
		for i in CELLS:
			var a: int = j * n + i
			var b: int = a + 1
			var cc2: int = a + n
			var d: int = cc2 + 1
			idx[q] = a
			idx[q + 1] = b
			idx[q + 2] = cc2
			idx[q + 3] = b
			idx[q + 4] = d
			idx[q + 5] = cc2
			q += 6
	var arr: Array = []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = norms
	arr[Mesh.ARRAY_INDEX] = idx
	var mesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	mesh.surface_set_material(0, terrain_mat)
	var mi = MeshInstance3D.new()
	mi.mesh = mesh
	root.add_child(mi)
	# vegetation
	var rng = RandomNumberGenerator.new()
	rng.seed = (c.x * 73856093) ^ (c.y * 19349663) ^ 12345
	var pines: Array = []
	var oaks: Array = []
	var birches: Array = []
	var rocks: Array = [[], [], []]
	var bushes: Array = []
	var obs = PackedVector3Array()
	for k in 220:
		var x: float = x0 + rng.randf() * CH
		var z: float = z0 + rng.randf() * CH
		var dr: float = absf(x - road_x(z))
		if dr < 11.0 or _blocked(x, z, dr):
			continue
		var h: float = height(x, z)
		var sl: float = absf(height(x + 2.0, z) - h) + absf(height(x, z + 2.0) - h)
		if sl > 2.8 or h > 140.0:
			continue
		var f: float = n_for.get_noise_2d(x, z)
		if rng.randf() > smoothstep(-0.30, 0.20, f):
			continue
		var s: float = rng.randf_range(0.75, 1.5)
		var bs: Basis = Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s * rng.randf_range(0.9, 1.2), s))
		var xf: Transform3D = Transform3D(bs, Vector3(x, h - 0.2, z))
		var broad_w: float = clampf(1.0 - (h - road_h(z)) / 70.0, 0.1, 0.7)
		if rng.randf() < broad_w:
			if rng.randf() < 0.35:
				birches.append(xf)
			else:
				oaks.append(xf)
		else:
			pines.append(xf)
		obs.append(Vector3(x, z, 0.55 * s))
	for k in 24:
		var x: float = x0 + rng.randf() * CH
		var z: float = z0 + rng.randf() * CH
		var dr: float = absf(x - road_x(z))
		if dr < 6.0:
			continue
		if absf(z - RIVER_Z) < 30.0 and dr < 135.0:
			continue
		var h: float = height(x, z)
		var s: float = rng.randf_range(0.5, 2.3)
		var bs: Basis = Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s * rng.randf_range(0.7, 1.1), s))
		rocks[rng.randi() % 3].append(Transform3D(bs, Vector3(x, h - 0.15, z)))
		obs.append(Vector3(x, z, 0.85 * s))
	for k in 40:
		var x: float = x0 + rng.randf() * CH
		var z: float = z0 + rng.randf() * CH
		var dr: float = absf(x - road_x(z))
		if dr < 7.0 or _blocked(x, z, dr):
			continue
		var h: float = height(x, z)
		var s: float = rng.randf_range(0.7, 1.5)
		bushes.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s, s)), Vector3(x, h - 0.1, z)))
	var pine_mmi = _mm(root, lib["pine_lo"], pines, true)
	_mm(root, lib["oak"], oaks, true)
	_mm(root, lib["birch"], birches, true)
	for r in 3:
		_mm(root, lib["rocks"][r], rocks[r], true)
	_mm(root, lib["bush"], bushes, false)
	obstacles[c] = obs
	# road signs every 250 m
	for sk in range(0, 14):
		var zs: float = -250.0 * float(sk)
		if zs >= z0 and zs < z0 + CH:
			_sign(root, zs, 3250.0 - 250.0 * float(sk))
	chunks[c] = {"root": root, "pine": pine_mmi, "grass": null, "hi": false}


func _add_grass(c: Vector2i, d: Dictionary) -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = (c.x * 4093) ^ (c.y * 8191) ^ 99
	var x0: float = c.x * CH
	var z0: float = c.y * CH
	var xs: Array = []
	for k in 1300:
		var x: float = x0 + rng.randf() * CH
		var z: float = z0 + rng.randf() * CH
		var dr: float = absf(x - road_x(z))
		if dr < 3.6:
			continue
		if absf(z - RIVER_Z) < 26.0 and dr < 135.0:
			continue
		var h: float = height(x, z)
		var s: float = rng.randf_range(0.8, 1.6)
		xs.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s, s)), Vector3(x, h - 0.03, z)))
	d["grass"] = _mm(d["root"], lib["tuft"], xs, false)


func _sign(root: Node3D, zs: float, remaining: float) -> void:
	var x: float = road_x(zs) + 6.5
	var h: float = height(x, zs)
	var n = Node3D.new()
	n.position = Vector3(x, h, zs)
	var wood: ShaderMaterial = Mats.variant("planks", {"scale": 5.0})
	var post = MeshInstance3D.new()
	var pb = BoxMesh.new()
	pb.size = Vector3(0.18, 2.6, 0.18)
	post.mesh = pb
	post.material_override = wood
	post.position = Vector3(0, 1.3, 0)
	n.add_child(post)
	var board = MeshInstance3D.new()
	var bb = BoxMesh.new()
	bb.size = Vector3(1.7, 0.75, 0.08)
	board.mesh = bb
	board.material_override = wood
	board.position = Vector3(0, 2.3, 0.1)
	n.add_child(board)
	var lb = Label3D.new()
	lb.text = "HAVEN\n%d m" % int(remaining)
	lb.font_size = 56
	lb.pixel_size = 0.0075
	lb.outline_size = 8
	lb.modulate = Color(0.98, 0.92, 0.78)
	lb.outline_modulate = Color(0.1, 0.06, 0.03)
	lb.position = Vector3(0, 2.3, 0.15)
	n.add_child(lb)
	root.add_child(n)


# ---------- obstacles ----------
func collide(p: Vector3, r: float) -> Vector3:
	if absf(p.x - road_x(p.z)) < 8.0:
		return Vector3.ZERO
	var cc: Vector2i = Vector2i(floori(p.x / CH), floori(p.z / CH))
	var push: Vector3 = Vector3.ZERO
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			var c: Vector2i = Vector2i(cc.x + dx, cc.y + dz)
			if obstacles.has(c):
				var arr: PackedVector3Array = obstacles[c]
				for o in arr:
					var ddx: float = p.x - o.x
					var ddz: float = p.z - o.y
					var rr: float = r + o.z
					var d2: float = ddx * ddx + ddz * ddz
					if d2 < rr * rr:
						var dd: float = maxf(sqrt(d2), 0.001)
						push += Vector3(ddx / dd, 0, ddz / dd) * (rr - dd)
	for k in extra_obs.keys():
		for o in extra_obs[k]:
			var ddx2: float = p.x - o.x
			var ddz2: float = p.z - o.y
			var rr2: float = r + o.z
			var dq: float = ddx2 * ddx2 + ddz2 * ddz2
			if dq < rr2 * rr2:
				var dd2: float = maxf(sqrt(dq), 0.001)
				push += Vector3(ddx2 / dd2, 0, ddz2 / dd2) * (rr2 - dd2)
	return push


# ---------- settlements ----------
func _settlements(pos: Vector3) -> void:
	for i in SZ.size():
		var dz: float = absf(pos.z - SZ[i])
		if dz < 330.0 and not settle_nodes.has(i):
			settle_nodes[i] = _build_settlement(i)
		elif dz > 520.0 and settle_nodes.has(i):
			settle_nodes[i].queue_free()
			settle_nodes.erase(i)
			extra_obs.erase(i)


func _house(rng: RandomNumberGenerator) -> Node3D:
	var w: float = rng.randf_range(5.5, 8.0)
	var d: float = rng.randf_range(4.6, 6.5)
	var hg: float = rng.randf_range(2.8, 3.6)
	var rh: float = rng.randf_range(1.7, 2.4)
	var n = Node3D.new()
	var wall = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(w, hg, d)
	wall.mesh = bm
	wall.material_override = Mats.variant("planks", {"c1": Color(0.45, 0.33, 0.20).lerp(Color(0.5, 0.45, 0.38), rng.randf() * 0.7), "scale": 3.5})
	wall.position = Vector3(0, 0.3 + hg * 0.5, 0)
	n.add_child(wall)
	var fd = MeshInstance3D.new()
	var fb = BoxMesh.new()
	fb.size = Vector3(w + 0.4, 2.6, d + 0.4)
	fd.mesh = fb
	fd.material_override = Mats.get_mat("stone")
	fd.position = Vector3(0, -1.0, 0)
	n.add_child(fd)
	var rf = MeshInstance3D.new()
	rf.mesh = M.roof(w, d, rh, 0.5, Mats.get_mat("shingle"), wall.material_override)
	rf.position = Vector3(0, 0.3 + hg, 0)
	n.add_child(rf)
	var door = MeshInstance3D.new()
	var db = BoxMesh.new()
	db.size = Vector3(1.0, 2.0, 0.12)
	door.mesh = db
	door.material_override = Mats.std(Color(0.16, 0.10, 0.06), 0.9)
	door.position = Vector3(-w * 0.15, 1.3, d * 0.5 + 0.03)
	n.add_child(door)
	var wm: StandardMaterial3D = Mats.glow(Color(1.0, 0.72, 0.38), 0.0)
	win_mats.append(wm)
	for sx in [0.22, 0.38]:
		var win = MeshInstance3D.new()
		var wb = BoxMesh.new()
		wb.size = Vector3(0.8, 0.8, 0.1)
		win.mesh = wb
		win.material_override = wm
		win.position = Vector3(w * sx + 0.35, 0.3 + hg * 0.55, d * 0.5 + 0.03)
		n.add_child(win)
	var ch = MeshInstance3D.new()
	var cb = BoxMesh.new()
	cb.size = Vector3(0.8, 2.4, 0.8)
	ch.mesh = cb
	ch.material_override = Mats.get_mat("stone")
	ch.position = Vector3(w * 0.3, 0.3 + hg + rh * 0.8, -d * 0.22)
	n.add_child(ch)
	var sm: CPUParticles3D = Mats.particles("smoke")
	sm.position = Vector3(w * 0.3, 0.3 + hg + rh * 0.8 + 1.3, -d * 0.22)
	sm.emitting = true
	n.add_child(sm)
	n.set_meta("r", maxf(w, d) * 0.55)
	return n


func _lamp(parent: Node3D, pos: Vector3) -> void:
	var post = MeshInstance3D.new()
	var pb = BoxMesh.new()
	pb.size = Vector3(0.14, 3.0, 0.14)
	post.mesh = pb
	post.material_override = Mats.std(Color(0.12, 0.09, 0.07), 0.8)
	post.position = pos + Vector3(0, 1.5, 0)
	parent.add_child(post)
	var l = OmniLight3D.new()
	l.position = pos + Vector3(0, 3.1, 0)
	l.omni_range = 16.0
	l.light_color = Color(1.0, 0.74, 0.42)
	l.light_energy = 0.0
	parent.add_child(l)
	lamps.append(l)
	var gm = MeshInstance3D.new()
	var sp = SphereMesh.new()
	sp.radius = 0.14
	sp.height = 0.3
	gm.mesh = sp
	var wm: StandardMaterial3D = Mats.glow(Color(1.0, 0.8, 0.5), 0.0)
	win_mats.append(wm)
	gm.material_override = wm
	gm.position = l.position
	parent.add_child(gm)


func _fire(parent: Node3D, pos: Vector3) -> void:
	var f = Node3D.new()
	f.position = pos
	parent.add_child(f)
	var rng = RandomNumberGenerator.new()
	rng.seed = 5
	for i in 9:
		var a: float = float(i) / 9.0 * TAU
		var st = SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		M.ellipsoid(st, Vector3(0, 0, 0), Vector3(0.28, 0.2, 0.24), 7, 5, 0.3, 2.0, 50 + i)
		var rm = MeshInstance3D.new()
		rm.mesh = M.finish(st, Mats.get_mat("rock"))
		rm.position = Vector3(cos(a) * 0.85, 0.1, sin(a) * 0.85)
		f.add_child(rm)
	for i in 3:
		var st2 = SurfaceTool.new()
		st2.begin(Mesh.PRIMITIVE_TRIANGLES)
		M.limb(st2, 0.09, 0.07, 1.0, 6, Transform3D(Basis(Vector3(0, 0, 1), deg_to_rad(90.0)), Vector3(0.5, 0, 0)))
		var lg = MeshInstance3D.new()
		lg.mesh = M.finish(st2, Mats.std(Color(0.18, 0.11, 0.07), 0.95))
		lg.position = Vector3(0, 0.2 + i * 0.06, 0)
		lg.rotation.y = float(i) / 3.0 * PI
		f.add_child(lg)
	var fp: CPUParticles3D = Mats.particles("fire")
	fp.position = Vector3(0, 0.35, 0)
	fp.emitting = true
	f.add_child(fp)
	var sp: CPUParticles3D = Mats.particles("smoke")
	sp.position = Vector3(0, 1.2, 0)
	sp.emitting = true
	f.add_child(sp)
	var l = OmniLight3D.new()
	l.position = Vector3(0, 1.0, 0)
	l.omni_range = 22.0
	l.light_color = Color(1.0, 0.6, 0.28)
	l.light_energy = 2.4
	f.add_child(l)
	flickers.append([l, 2.4, rng.randf() * 10.0])


func add_campfire(pos: Vector3) -> void:
	_fire(self, pos)


func _build_settlement(i: int) -> Node3D:
	var root = Node3D.new()
	add_child(root)
	var zc: float = SZ[i]
	var rng = RandomNumberGenerator.new()
	rng.seed = 900 + i
	var obs: Array = []
	if i == 0 or i == 1:
		for k in 10:
			var side2: float = 1.0 if k % 2 == 0 else -1.0
			var z2: float = zc + float(k / 2 - 2) * 17.0 + rng.randf_range(-3.0, 3.0)
			var x2: float = road_x(z2) + side2 * rng.randf_range(15.0, 26.0)
			var hn2: Node3D = _house(rng)
			hn2.position = Vector3(x2, height(x2, z2), z2)
			hn2.rotation.y = -side2 * PI * 0.5 + rng.randf_range(-0.12, 0.12)
			root.add_child(hn2)
			obs.append(Vector3(x2, z2, hn2.get_meta("r")))
		for k in 4:
			var zl: float = zc + float(k - 2) * 24.0 + 8.0
			var xl: float = road_x(zl) + (6.0 if k % 2 == 0 else -6.0)
			_lamp(root, Vector3(xl, height(xl, zl), zl))
		var sx: float = road_x(zc + 40.0) + 7.5
		var sg = Node3D.new()
		sg.position = Vector3(sx, height(sx, zc + 40.0), zc + 40.0)
		root.add_child(sg)
		var sb = MeshInstance3D.new()
		var sbm = BoxMesh.new()
		sbm.size = Vector3(3.4, 1.2, 0.12)
		sb.mesh = sbm
		sb.material_override = Mats.variant("planks", {"scale": 5.0})
		sb.position = Vector3(0, 3.0, 0)
		sg.add_child(sb)
		var lb = Label3D.new()
		lb.text = NAMES[i]
		lb.font_size = 96
		lb.pixel_size = 0.0075
		lb.outline_size = 10
		lb.modulate = Color(0.98, 0.9, 0.7)
		lb.position = Vector3(0, 3.0, 0.1)
		sg.add_child(lb)
		for px in [-1.6, 1.6]:
			var pm = MeshInstance3D.new()
			var pbm = BoxMesh.new()
			pbm.size = Vector3(0.2, 3.6, 0.2)
			pm.mesh = pbm
			pm.material_override = Mats.variant("planks", {"scale": 5.0})
			pm.position = Vector3(px, 1.8, 0)
			sg.add_child(pm)
	elif i == 2:
		var cp: Vector3 = camp_pos()
		_fire(root, cp)
		for k in 6:
			var a: float = float(k) / 6.0 * TAU
			var st = SurfaceTool.new()
			st.begin(Mesh.PRIMITIVE_TRIANGLES)
			M.limb(st, 0.22, 0.2, 1.6, 7, Transform3D(Basis(Vector3(0, 0, 1), deg_to_rad(90.0)), Vector3(0.8, 0, 0)))
			var lg = MeshInstance3D.new()
			lg.mesh = M.finish(st, Mats.std(Color(0.2, 0.13, 0.08), 0.95))
			lg.position = cp + Vector3(cos(a) * 3.0, 0.25, sin(a) * 3.0)
			lg.rotation.y = -a + PI * 0.5
			root.add_child(lg)
		for tk in 2:
			var tx: float = cp.x + (7.0 if tk == 0 else -2.0)
			var tz: float = cp.z + (-4.0 if tk == 0 else -9.0)
			var tn = MeshInstance3D.new()
			tn.mesh = M.roof(3.6, 4.4, 2.3, 0.0, Mats.get_mat("cloth"), Mats.get_mat("cloth"))
			tn.position = Vector3(tx, height(tx, tz) + 0.05, tz)
			tn.rotation.y = 0.5 * float(tk)
			root.add_child(tn)
			obs.append(Vector3(tx, tz, 2.4))
	else:
		_build_gate(root, rng, obs)
	extra_obs[i] = obs
	return root


func _stone_box(parent: Node3D, size: Vector3, pos: Vector3, rot_y: float = 0.0, mat: Material = null) -> MeshInstance3D:
	var bm = BoxMesh.new()
	bm.size = size
	var mi = MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat if mat != null else Mats.get_mat("stone")
	mi.position = pos
	mi.rotation.y = rot_y
	parent.add_child(mi)
	return mi


func _build_gate(root: Node3D, rng: RandomNumberGenerator, obs: Array) -> void:
	var gp: Vector3 = gate_pos()
	var g = Node3D.new()
	g.position = gp
	root.add_child(g)
	var base: float = 0.0
	for sx in [-1.0, 1.0]:
		_stone_box(g, Vector3(60.0, 12.0, 3.6), Vector3(sx * 38.0, 4.0, 0.0))
		obs.append(Vector3(gp.x + sx * 38.0, gp.z, 4.0))
		obs.append(Vector3(gp.x + sx * 55.0, gp.z, 4.0))
		obs.append(Vector3(gp.x + sx * 25.0, gp.z, 4.0))
		# merlons
		var mxs: Array = []
		for k in 22:
			mxs.append(Transform3D(Basis.IDENTITY, Vector3(sx * 38.0 - 29.0 + float(k) * 2.75, 10.65, 0.0)))
		var mbm = BoxMesh.new()
		mbm.size = Vector3(1.6, 1.3, 1.2)
		mbm.material = Mats.get_mat("stone")
		_mm(g, mbm, mxs, true)
		# tower
		var st = SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		M.lathe(st, [Vector2(4.4, 18.0), Vector2(4.7, 17.0), Vector2(4.4, 16.4), Vector2(4.4, 0.0), Vector2(5.0, -3.0)], 14, Transform3D(Basis.IDENTITY, Vector3(sx * 10.0, 0, 0)), 0.02, 0.5, 9)
		var tw = MeshInstance3D.new()
		tw.mesh = M.finish(st, Mats.get_mat("stone"))
		g.add_child(tw)
		var st2 = SurfaceTool.new()
		st2.begin(Mesh.PRIMITIVE_TRIANGLES)
		M.lathe(st2, [Vector2(0.0, 26.0), Vector2(2.6, 21.5), Vector2(5.6, 18.2), Vector2(0.0, 18.0)], 14, Transform3D(Basis.IDENTITY, Vector3(sx * 10.0, 0, 0)))
		var rf = MeshInstance3D.new()
		rf.mesh = M.finish(st2, Mats.variant("shingle", {"c1": Color(0.18, 0.2, 0.3), "c2": Color(0.1, 0.12, 0.2)}))
		g.add_child(rf)
		# banner
		var bn = MeshInstance3D.new()
		var bbm = BoxMesh.new()
		bbm.size = Vector3(2.2, 6.0, 0.08)
		bn.mesh = bbm
		bn.material_override = Mats.variant("cloth", {"c1": Color(0.62, 0.1, 0.09), "c2": Color(0.38, 0.05, 0.05)})
		bn.position = Vector3(sx * 10.0, 11.0, 4.6)
		g.add_child(bn)
		# gate leaf, swung open
		_stone_box(g, Vector3(5.2, 8.2, 0.4), Vector3(sx * 6.4, 4.1, -2.8), sx * 1.2, Mats.variant("planks", {"c1": Color(0.24, 0.16, 0.09), "scale": 3.0}))
		# torches
		var tp: Vector3 = Vector3(sx * 6.2, 0.0, 3.4)
		var post = MeshInstance3D.new()
		var pbm = BoxMesh.new()
		pbm.size = Vector3(0.2, 3.4, 0.2)
		post.mesh = pbm
		post.material_override = Mats.std(Color(0.15, 0.1, 0.07), 0.9)
		post.position = tp + Vector3(0, 1.7, 0)
		g.add_child(post)
		var fp: CPUParticles3D = Mats.particles("fire")
		fp.position = tp + Vector3(0, 3.5, 0)
		fp.emitting = true
		g.add_child(fp)
		var tl = OmniLight3D.new()
		tl.position = tp + Vector3(0, 3.6, 0)
		tl.omni_range = 24.0
		tl.light_color = Color(1.0, 0.62, 0.3)
		tl.light_energy = 2.0
		g.add_child(tl)
		flickers.append([tl, 2.0, rng.randf() * 10.0])
	_stone_box(g, Vector3(24.0, 5.0, 4.6), Vector3(0, 10.5, 0))
	var lb = Label3D.new()
	lb.text = "HAVEN"
	lb.font_size = 280
	lb.pixel_size = 0.012
	lb.outline_size = 24
	lb.modulate = Color(0.98, 0.9, 0.68)
	lb.outline_modulate = Color(0.1, 0.06, 0.03)
	lb.position = Vector3(0, 10.5, 2.4)
	g.add_child(lb)
	# the city behind the gate
	for k in 16:
		var side: float = 1.0 if k % 2 == 0 else -1.0
		var z: float = gp.z - 26.0 - float(k / 2) * 17.0
		var x: float = road_x(z) + side * rng.randf_range(14.0, 24.0)
		var hn: Node3D = _house(rng)
		hn.position = Vector3(x, height(x, z), z)
		hn.rotation.y = -side * PI * 0.5
		hn.scale = Vector3(1.0, 1.0 + rng.randf() * 0.8, 1.0)
		root.add_child(hn)
	var kst = SurfaceTool.new()
	kst.begin(Mesh.PRIMITIVE_TRIANGLES)
	M.lathe(kst, [Vector2(0.0, 52.0), Vector2(5.0, 46.0), Vector2(8.5, 44.0), Vector2(7.0, 42.0), Vector2(7.0, 0.0), Vector2(8.0, -3.0)], 14, Transform3D.IDENTITY)
	var keep = MeshInstance3D.new()
	keep.mesh = M.finish(kst, Mats.get_mat("stone"))
	var kx: float = road_x(gp.z - 150.0)
	keep.position = Vector3(kx, height(kx, gp.z - 150.0), gp.z - 150.0)
	root.add_child(keep)
	for k in 5:
		var zl: float = gp.z - 22.0 - float(k) * 22.0
		var xl: float = road_x(zl) + (6.5 if k % 2 == 0 else -6.5)
		_lamp(root, Vector3(xl, height(xl, zl), zl))


# ---------- per-frame ----------
func _process(delta: float) -> void:
	tick += 1
	cloud_t += delta * 0.004 * (1.0 + storm * 3.0)
	sky_mat.set_shader_parameter("cloud_t", cloud_t)
	storm = move_toward(storm, storm_target, delta * 0.25)
	if absf(hour - applied_hour) > 0.004 or absf(storm - applied_storm) > 0.01:
		_apply_time()
	flash = maxf(0.0, flash - delta * 2.2)
	env.background_energy_multiplier = 1.0 + flash * 2.5
	sun.light_energy = sun_energy + flash * 2.0
	var tm: float = Time.get_ticks_msec() * 0.001
	for f in flickers:
		if is_instance_valid(f[0]):
			f[0].light_energy = f[1] * (0.3 + 0.7 * night_amt) * (0.82 + 0.18 * sin(tm * 17.0 + f[2]) + 0.1 * sin(tm * 41.0 + f[2] * 2.0))
