extends Node3D
# Lightweight streamed world for old phones: vertex-coloured terrain, few draw calls,
# and chunk generation that is time-sliced across frames (never freezes the device).

const M = preload("res://meshes.gd")
const Mats = preload("res://mats.gd")

const CH: float = 96.0
const CELLS: int = 24
const RIVER_Z: float = -720.0
const SZ: Array = [0.0, -1400.0, -2480.0, -3250.0]
const NAMES: Array = ["ASHFORD", "MILLBROOK", "CAMP", "HAVEN"]

var stage: String = "init"
var n_hill: FastNoiseLite
var n_rid: FastNoiseLite
var n_for: FastNoiseLite
var n_det: FastNoiseLite
var f0: float = 0.0
var river_lvl: float = 0.0

var chunks: Dictionary = {}
var queue: Array = []
var obstacles: Dictionary = {}
var extra_obs: Dictionary = {}
var settle_nodes: Dictionary = {}
var rad: int = 2
var quality: int = 1
var lib: Dictionary = {}
var idx: PackedInt32Array = PackedInt32Array()
var win_mat: StandardMaterial3D
var flickers: Array = []
var last_cc: Vector2i = Vector2i(99999, 99999)

var jc: Vector2i = Vector2i.ZERO
var jstage: int = -1
var jrow: int = 0
var jroot: Node3D = null
var j_hs: PackedFloat32Array = PackedFloat32Array()
var j_verts: PackedVector3Array = PackedVector3Array()
var j_norms: PackedVector3Array = PackedVector3Array()
var j_cols: PackedColorArray = PackedColorArray()

var names: Array = ["ASHFORD", "MILLBROOK", "CAMP", "HAVEN"]
var rph: float = 0.0
var env: Environment
var sun: DirectionalLight3D
var fill: DirectionalLight3D
var cloud_rig: Node3D
var cloud_mat: ShaderMaterial
var sky_mat: ProceduralSkyMaterial
var water: MeshInstance3D

var hour: float = 9.0
var storm: float = 0.0
var storm_target: float = 0.0
var flash: float = 0.0
var night_amt: float = 0.0
var sun_energy: float = 1.0
var applied_hour: float = -99.0
var applied_storm: float = -99.0


func _ready() -> void:
	stage = "noise"
	f0 = road_f(0.0)
	river_lvl = road_h(RIVER_Z)
	n_hill = FastNoiseLite.new()
	n_hill.seed = 11
	n_hill.frequency = 0.0017
	n_hill.fractal_octaves = 2
	n_rid = FastNoiseLite.new()
	n_rid.seed = 13
	n_rid.frequency = 0.0011
	n_rid.fractal_octaves = 1
	n_for = FastNoiseLite.new()
	n_for.seed = 14
	n_for.frequency = 0.004
	n_det = FastNoiseLite.new()
	n_det.seed = 15
	n_det.frequency = 0.09
	win_mat = Mats.glow(Color(1.0, 0.72, 0.38), 0.0)
	stage = "index"
	_build_index()
	stage = "meshes"
	_build_lib()
	stage = "environment"
	_setup_env()
	stage = "water"
	_build_water()
	stage = "quality"
	set_quality(0 if OS.has_feature("32") else 1)
	stage = "time"
	_apply_time()
	stage = "ready"


# ---------- terrain functions ----------
func road_f(z: float) -> float:
	return 34.0 * sin(z * 0.0045 + rph * 0.5) + 20.0 * sin(z * 0.0118 + 1.3 + rph) + 6.0 * sin(z * 0.027 + 0.4 + rph * 2.0)


func road_x(z: float) -> float:
	return road_f(z) - f0


func road_dx(z: float) -> float:
	return (road_f(z + 1.0) - road_f(z - 1.0)) * 0.5


func road_h(z: float) -> float:
	return 10.0 * sin(z * 0.0021 + 0.7) + 4.0 * sin(z * 0.0063)


func settle_f(z: float) -> float:
	var f: float = 1.0
	for sz in SZ:
		f = minf(f, 0.12 + 0.88 * smoothstep(50.0, 150.0, absf(z - sz)))
	return f


func height(x: float, z: float) -> float:
	var dr: float = absf(x - road_x(z))
	var t: float = smoothstep(6.0, 95.0, dr)
	var hills: float = n_hill.get_noise_2d(x, z) * 24.0 * settle_f(z)
	var mt: float = smoothstep(150.0, 540.0, dr)
	var rg: float = maxf(0.0, n_rid.get_noise_2d(x * 0.8, z * 0.8) + 0.22)
	hills += rg * rg * 260.0 * mt
	var h: float = road_h(z) + hills * t
	var dz: float = absf(z - RIVER_Z)
	if dz < 40.0:
		var w: float = (1.0 - smoothstep(12.0, 30.0, dz)) * (1.0 - smoothstep(70.0, 125.0, dr))
		var rw: float = 1.0 - smoothstep(4.5, 11.0, dr)
		var bed: float = lerpf(river_lvl - 3.2, river_lvl - 0.5, rw)
		h = lerpf(h, bed, w)
		var gr: float = river_lvl - 3.6 + 5.2 * smoothstep(80.0, 125.0, dr)
		var g: float = lerpf(gr, river_lvl + 0.35, smoothstep(14.0, 22.0, dz))
		h = lerpf(h, maxf(h, g), 1.0 - smoothstep(30.0, 40.0, dz))
	return h


func depth_at(x: float, z: float) -> float:
	if absf(z - RIVER_Z) > 22.0:
		return 0.0
	if absf(x - road_x(RIVER_Z)) > 130.0:
		return 0.0
	return maxf(0.0, (river_lvl - 0.1) - height(x, z))


func camp_pos() -> Vector3:
	var z: float = SZ[2]
	var x: float = road_x(z) + 16.0
	return Vector3(x, height(x, z), z)


func gate_pos() -> Vector3:
	var z: float = SZ[3]
	var x: float = road_x(z)
	return Vector3(x, height(x, z), z)


func _tcol(x: float, z: float, h: float, ny: float, dr: float) -> Color:
	var nz: float = n_det.get_noise_2d(x, z)
	var big: float = n_for.get_noise_2d(x, z)
	var g: Color = Color(0.14, 0.25, 0.06).lerp(Color(0.28, 0.35, 0.10), clampf(0.5 + nz * 0.9, 0.0, 1.0))
	g = g.lerp(Color(0.38, 0.33, 0.15), clampf(big * 1.2, 0.0, 1.0) * 0.6)
	var slope: float = 1.0 - ny
	var rock: Color = Color(0.34, 0.32, 0.29).lerp(Color(0.5, 0.46, 0.4), clampf(0.5 + nz, 0.0, 1.0))
	var c: Color = g.lerp(rock, smoothstep(0.16, 0.34, slope))
	if h > 150.0:
		c = c.lerp(Color(0.9, 0.92, 0.96), smoothstep(150.0, 190.0, h) * (1.0 - smoothstep(0.3, 0.6, slope)))
	var dirt: Color = Color(0.42, 0.31, 0.19).lerp(Color(0.5, 0.39, 0.25), clampf(0.5 + nz, 0.0, 1.0))
	c = c.lerp(dirt * 0.9, (1.0 - smoothstep(4.0, 9.0, dr)) * 0.35)
	c = c.lerp(dirt, 1.0 - smoothstep(2.4, 5.2, dr))
	if absf(z - RIVER_Z) < 30.0 and h < river_lvl + 0.4:
		c = c.lerp(Color(0.30, 0.27, 0.2), 0.6)
	return c


# ---------- shared meshes ----------
func _build_index() -> void:
	var n: int = CELLS + 1
	idx.resize(CELLS * CELLS * 6)
	var q: int = 0
	for j in CELLS:
		for i in CELLS:
			var a: int = j * n + i
			var b: int = a + 1
			var c: int = a + n
			var d: int = c + 1
			idx[q] = a
			idx[q + 1] = b
			idx[q + 2] = c
			idx[q + 3] = b
			idx[q + 4] = d
			idx[q + 5] = c
			q += 6


func _t(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis.IDENTITY, Vector3(x, y, z))


func _pine() -> ArrayMesh:
	var st = M.new_st()
	M.lathe(st, [Vector2(0.0, 7.0), Vector2(0.18, 6.0), Vector2(0.4, 0.0), Vector2(0.55, -0.5)], 5, Transform3D.IDENTITY, 0.0, 1.0, 1, Color(0.22, 0.15, 0.09))
	for k in 3:
		var t: float = float(k) / 2.0
		var yt: float = 10.3 - t * 5.6
		var r: float = 0.9 + t * 2.0
		var h: float = 3.2 + t * 0.6
		M.lathe(st, [Vector2(0.0, yt), Vector2(r, yt - h), Vector2(0.2, yt - h - 0.3)], 6, Transform3D.IDENTITY, 0.0, 1.0, 1, Color(0.07, 0.20, 0.09), 0.35)
	return M.finish(st, Mats.vcol())


func _broad(birch: bool) -> ArrayMesh:
	var st = M.new_st()
	var tr: float = 0.16 if birch else 0.3
	M.lathe(st, [Vector2(0.0, 5.0), Vector2(tr, 4.6), Vector2(tr * 1.5, 0.0)], 5, Transform3D.IDENTITY, 0.0, 1.0, 1, Color(0.8, 0.78, 0.7) if birch else Color(0.2, 0.14, 0.09))
	var leaf: Color = Color(0.22, 0.36, 0.09) if birch else Color(0.10, 0.24, 0.06)
	M.ellipsoid(st, Vector3(0, 5.2, 0), Vector3(1.9, 1.5, 1.9), 6, 4, 0.0, 1.0, 1, leaf, Basis.IDENTITY, 0.4)
	M.ellipsoid(st, Vector3(1.0, 4.5, 0.4), Vector3(1.3, 1.1, 1.3), 6, 4, 0.0, 1.0, 1, leaf.lightened(0.05), Basis.IDENTITY, 0.4)
	M.ellipsoid(st, Vector3(-0.9, 4.7, -0.5), Vector3(1.4, 1.2, 1.4), 6, 4, 0.0, 1.0, 1, leaf.darkened(0.05), Basis.IDENTITY, 0.4)
	return M.finish(st, Mats.vcol())


func _rock(sd: int) -> ArrayMesh:
	var st = M.new_st()
	M.ellipsoid(st, Vector3(0, 0.3, 0), Vector3(1.0, 0.7, 0.85), 6, 4, 0.35, 1.1, sd, Color(0.42, 0.40, 0.37), Basis.IDENTITY, 0.3)
	return M.finish(st, Mats.vcol())


func _build_lib() -> void:
	lib["pine"] = _pine()
	lib["oak"] = _broad(false)
	lib["birch"] = _broad(true)
	lib["rocks"] = [_rock(1), _rock(2), _rock(3)]
	lib["blob"] = M.blob()


# ---------- environment ----------
func _setup_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	sky_mat = ProceduralSkyMaterial.new()
	var sky = Sky.new()
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	env.fog_enabled = true
	env.fog_sun_scatter = 0.25
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	var we = WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = false
	add_child(sun)
	fill = DirectionalLight3D.new()
	fill.shadow_enabled = false
	fill.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	fill.light_energy = 0.2
	add_child(fill)
	cloud_rig = Node3D.new()
	add_child(cloud_rig)
	cloud_mat = Mats.cloud_mat()
	var crng = RandomNumberGenerator.new()
	crng.seed = 77
	for i in 7:
		var qm = QuadMesh.new()
		qm.size = Vector2(crng.randf_range(180.0, 300.0), crng.randf_range(60.0, 110.0))
		var cmi = MeshInstance3D.new()
		cmi.mesh = qm
		cmi.material_override = cloud_mat
		cmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var ca: float = crng.randf() * TAU
		cmi.position = Vector3(cos(ca) * 420.0, crng.randf_range(110.0, 220.0), sin(ca) * 420.0)
		cloud_rig.add_child(cmi)


func _build_water() -> void:
	var pm = PlaneMesh.new()
	pm.size = Vector2(260.0, 44.0)
	water = MeshInstance3D.new()
	water.mesh = pm
	water.material_override = Mats.water()
	water.position = Vector3(road_x(RIVER_Z), river_lvl - 0.1, RIVER_Z)
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(water)


func set_quality(q: int) -> void:
	quality = q
	var vp: Viewport = get_viewport()
	var sc: float = 0.6
	if q == 0:
		rad = 1
		sun.shadow_enabled = false
		sc = 0.6
	elif q == 1:
		rad = 2
		sun.shadow_enabled = false
		sc = 0.75
	else:
		rad = 3
		sun.shadow_enabled = true
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		sun.directional_shadow_max_distance = 70.0
		sc = 1.0
	cloud_rig.visible = q > 0
	if vp:
		vp.scaling_3d_scale = sc
		vp.msaa_3d = Viewport.MSAA_DISABLED
	last_cc = Vector2i(99999, 99999)
	applied_hour = -99.0


func set_hour(h: float) -> void:
	hour = h


func set_storm(v: float) -> void:
	storm_target = v


func _apply_time() -> void:
	applied_hour = hour
	applied_storm = storm
	var ang: float = (hour - 6.0) / 12.0 * PI
	var el: float = sin(ang)
	var sun_v: Vector3 = Vector3(cos(ang), el, -0.3).normalized()
	var day: float = smoothstep(0.02, 0.5, el)
	var gold: float = smoothstep(-0.18, 0.02, el)
	night_amt = 1.0 - gold
	var top: Color = Color(0.01, 0.02, 0.06).lerp(Color(0.20, 0.33, 0.62), gold).lerp(Color(0.15, 0.36, 0.78), day)
	var hor: Color = Color(0.05, 0.07, 0.14).lerp(Color(1.0, 0.52, 0.25), gold).lerp(Color(0.60, 0.74, 0.90), day)
	var lightk: float = clampf(el * 3.0 + 0.25, 0.04, 1.0)
	var grey: Color = Color(0.26, 0.28, 0.32) * (0.2 + 0.8 * lightk)
	top = top.lerp(grey, storm * 0.85)
	hor = hor.lerp(grey * 1.1, storm * 0.9)
	var use_moon: bool = el < -0.06
	var ldir: Vector3 = -sun_v if use_moon else sun_v
	var sun_c: Color = Color(1.0, 0.55, 0.28).lerp(Color(1.0, 0.95, 0.85), smoothstep(0.0, 0.45, el))
	var e_sun: float = 1.5 * smoothstep(-0.06, 0.22, el) * (1.0 - 0.65 * storm)
	var e_moon: float = 0.4 * smoothstep(-0.06, -0.35, el) * (1.0 - 0.4 * storm)
	sun_energy = e_moon if use_moon else e_sun
	sun.light_color = Color(0.55, 0.66, 1.0) if use_moon else sun_c
	sun.transform.basis = Basis.looking_at(-ldir, Vector3.UP)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = hor.darkened(0.5)
	var amb: Color = top.lerp(hor, 0.35).lerp(Color(1, 1, 1), 0.3)
	amb = amb.lerp(Color(0.20, 0.27, 0.45), night_amt * 0.9)
	env.ambient_light_color = amb
	env.ambient_light_energy = lerpf(0.9, 0.62, day) * (1.0 - 0.2 * storm)
	fill.transform.basis = Basis.looking_at(Vector3(ldir.x, -0.55, ldir.z).normalized(), Vector3.UP)
	fill.light_color = top.lerp(Color(1, 1, 1), 0.4)
	fill.light_energy = lerpf(0.08, 0.3, day) * (1.0 - 0.5 * storm)
	var ck: float = clampf(el * 3.0 + 0.25, 0.05, 1.0)
	var ccol: Color = Color(1.0, 0.88 + 0.1 * day, 0.78 + 0.2 * day).lerp(Color(0.5, 0.52, 0.56), storm)
	cloud_mat.set_shader_parameter("tint", Color(ccol.r * ck, ccol.g * ck, ccol.b * ck, 0.78))
	env.tonemap_exposure = lerpf(1.05, 1.6, night_amt)
	env.fog_light_color = hor.darkened(0.1)
	env.fog_density = 2.2 / (float(rad) * CH + 40.0) + storm * 0.003
	win_mat.emission_energy_multiplier = night_amt * 2.6


# ---------- streaming (time-sliced) ----------
func queue_size() -> int:
	return queue.size() + (1 if jstage >= 0 else 0)


func update(pos: Vector3) -> void:
	var cc: Vector2i = Vector2i(floori(pos.x / CH), floori(pos.z / CH))
	if cc != last_cc:
		last_cc = cc
		var need: Array = []
		for dz in range(-rad, rad + 1):
			for dx in range(-rad, rad + 1):
				var c: Vector2i = Vector2i(cc.x + dx, cc.y + dz)
				if not chunks.has(c) and not (jstage >= 0 and c == jc):
					need.append(c)
		need.sort_custom(func(a, b): return (a - cc).length_squared() < (b - cc).length_squared())
		queue = need
		var drop: Array = []
		for c in chunks.keys():
			if maxi(absi(c.x - cc.x), absi(c.y - cc.y)) > rad + 1:
				drop.append(c)
		for c in drop:
			chunks[c].queue_free()
			chunks.erase(c)
			obstacles.erase(c)
	_settlements(pos)


func work(budget_us: int) -> void:
	var t0: int = Time.get_ticks_usec()
	while Time.get_ticks_usec() - t0 < budget_us:
		if jstage < 0:
			if queue.is_empty():
				return
			jc = queue.pop_front()
			if chunks.has(jc) or maxi(absi(jc.x - last_cc.x), absi(jc.y - last_cc.y)) > rad:
				continue
			jstage = 0
			jrow = 0
			var m: int = CELLS + 3
			var n: int = CELLS + 1
			j_hs.resize(m * m)
			j_verts.resize(n * n)
			j_norms.resize(n * n)
			j_cols.resize(n * n)
		_step()


func _step() -> void:
	var cs: float = CH / float(CELLS)
	var m: int = CELLS + 3
	var n: int = CELLS + 1
	var x0: float = float(jc.x) * CH
	var z0: float = float(jc.y) * CH
	if jstage == 0:
		var zz: float = z0 + float(jrow - 1) * cs
		for i in m:
			j_hs[jrow * m + i] = height(x0 + float(i - 1) * cs, zz)
		jrow += 1
		if jrow >= m:
			jstage = 1
			jrow = 0
	elif jstage == 1:
		var z: float = z0 + float(jrow) * cs
		var cx: float = road_x(z)
		for i in n:
			var k: int = (jrow + 1) * m + (i + 1)
			var x: float = x0 + float(i) * cs
			var h: float = j_hs[k]
			var nv: Vector3 = Vector3(j_hs[k - 1] - j_hs[k + 1], 2.0 * cs, j_hs[k - m] - j_hs[k + m]).normalized()
			j_verts[jrow * n + i] = Vector3(x, h, z)
			j_norms[jrow * n + i] = nv
			j_cols[jrow * n + i] = _tcol(x, z, h, nv.y, absf(x - cx))
		jrow += 1
		if jrow >= n:
			jstage = 2
	elif jstage == 2:
		var arr: Array = []
		arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = j_verts
		arr[Mesh.ARRAY_NORMAL] = j_norms
		arr[Mesh.ARRAY_COLOR] = j_cols
		arr[Mesh.ARRAY_INDEX] = idx
		var mesh = ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		mesh.surface_set_material(0, Mats.vcol())
		jroot = Node3D.new()
		var mi = MeshInstance3D.new()
		mi.mesh = mesh
		jroot.add_child(mi)
		jstage = 3
	elif jstage == 3:
		_vegetation()
		jstage = -1


func _blocked(x: float, z: float, dr: float) -> bool:
	if absf(z - RIVER_Z) < 46.0 and dr < 135.0:
		return true
	for sz in SZ:
		if absf(z - sz) < 70.0 and dr < 62.0:
			return true
	return false


func _mm(root: Node3D, mesh: Mesh, xforms: Array, tint: bool = false) -> void:
	if xforms.is_empty():
		return
	var mm = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = tint
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
		if tint:
			var v: float = randf_range(0.78, 1.18)
			mm.set_instance_color(i, Color(v, v * randf_range(0.95, 1.05), v * randf_range(0.9, 1.0), 1.0))
	var mmi = MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mmi)


func _vegetation() -> void:
	var x0: float = float(jc.x) * CH
	var z0: float = float(jc.y) * CH
	var rng = RandomNumberGenerator.new()
	rng.seed = (jc.x * 73856093) ^ (jc.y * 19349663) ^ 12345
	var pines: Array = []
	var oaks: Array = []
	var birches: Array = []
	var rocks: Array = [[], [], []]
	var blobs: Array = []
	var obs = PackedVector3Array()
	for k in 30:
		var x: float = x0 + rng.randf() * CH
		var z: float = z0 + rng.randf() * CH
		var dr: float = absf(x - road_x(z))
		if dr < 11.0 or _blocked(x, z, dr):
			continue
		var h: float = height(x, z)
		var sl: float = absf(height(x + 2.0, z) - h) + absf(height(x, z + 2.0) - h)
		if sl > 2.8 or h > 140.0:
			continue
		if rng.randf() > smoothstep(-0.30, 0.20, n_for.get_noise_2d(x, z)):
			continue
		var s: float = rng.randf_range(0.75, 1.5)
		var bs: Basis = Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s * rng.randf_range(0.9, 1.2), s))
		var xf: Transform3D = Transform3D(bs, Vector3(x, h - 0.2, z))
		blobs.append(Transform3D(Basis.from_scale(Vector3(s * 2.6, 1.0, s * 2.6)), Vector3(x, h + 0.12, z)))
		var broad_w: float = clampf(1.0 - (h - road_h(z)) / 70.0, 0.1, 0.7)
		if rng.randf() < broad_w:
			if rng.randf() < 0.35:
				birches.append(xf)
			else:
				oaks.append(xf)
		else:
			pines.append(xf)
		obs.append(Vector3(x, z, 0.55 * s))
	for k in 5:
		var x: float = x0 + rng.randf() * CH
		var z: float = z0 + rng.randf() * CH
		var dr: float = absf(x - road_x(z))
		if dr < 6.0:
			continue
		if absf(z - RIVER_Z) < 30.0 and dr < 135.0:
			continue
		var h: float = height(x, z)
		var s: float = rng.randf_range(0.6, 2.3)
		var bs: Basis = Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s * rng.randf_range(0.7, 1.1), s))
		rocks[rng.randi() % 3].append(Transform3D(bs, Vector3(x, h - 0.15, z)))
		obs.append(Vector3(x, z, 0.85 * s))
	_mm(jroot, lib["blob"], blobs)
	_mm(jroot, lib["pine"], pines, true)
	_mm(jroot, lib["oak"], oaks, true)
	_mm(jroot, lib["birch"], birches, true)
	for r in 3:
		_mm(jroot, lib["rocks"][r], rocks[r], true)
	for sk in range(0, 14):
		var zs: float = -250.0 * float(sk)
		if zs >= z0 and zs < z0 + CH:
			_sign(jroot, zs, 3250.0 - 250.0 * float(sk))
	add_child(jroot)
	chunks[jc] = jroot
	obstacles[jc] = obs
	jroot = null


func _sign(root: Node3D, zs: float, remaining: float) -> void:
	var x: float = road_x(zs) + 6.5
	var n = Node3D.new()
	n.position = Vector3(x, height(x, zs), zs)
	var st = M.new_st()
	M.box(st, Vector3(0.18, 2.6, 0.18), _t(0, 1.3, 0), Color(0.3, 0.2, 0.12))
	M.box(st, Vector3(1.7, 0.75, 0.08), _t(0, 2.3, 0.1), Color(0.42, 0.3, 0.18))
	var mi = MeshInstance3D.new()
	mi.mesh = M.finish(st, Mats.vcol())
	n.add_child(mi)
	var lb = Label3D.new()
	lb.text = "%s\n%d m" % [names[3], int(remaining)]
	lb.font_size = 48
	lb.pixel_size = 0.0085
	lb.outline_size = 6
	lb.modulate = Color(0.98, 0.92, 0.78)
	lb.outline_modulate = Color(0.1, 0.06, 0.03)
	lb.position = Vector3(0, 2.3, 0.15)
	n.add_child(lb)
	root.add_child(n)


# ---------- obstacles ----------
func collide(p: Vector3, r: float) -> Vector3:
	if absf(p.x - road_x(p.z)) < 8.0:
		return Vector3.ZERO
	var cc: Vector2i = Vector2i(floori(p.x / CH), floori(p.z / CH))
	var push: Vector3 = Vector3.ZERO
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			var c: Vector2i = Vector2i(cc.x + dx, cc.y + dz)
			if obstacles.has(c):
				var arr: PackedVector3Array = obstacles[c]
				for o in arr:
					var ddx: float = p.x - o.x
					var ddz: float = p.z - o.y
					var rr: float = r + o.z
					var d2: float = ddx * ddx + ddz * ddz
					if d2 < rr * rr:
						var dd: float = maxf(sqrt(d2), 0.001)
						push += Vector3(ddx / dd, 0, ddz / dd) * (rr - dd)
	for k in extra_obs.keys():
		for o in extra_obs[k]:
			var ex: float = p.x - o.x
			var ez: float = p.z - o.y
			var er: float = r + o.z
			var dq: float = ex * ex + ez * ez
			if dq < er * er:
				var de: float = maxf(sqrt(dq), 0.001)
				push += Vector3(ex / de, 0, ez / de) * (er - de)
	return push


# ---------- new journey: reshape the whole world ----------
func reseed(sd: int, nm: Array) -> void:
	names = nm
	rph = float(sd % 97) * 0.13
	f0 = road_f(0.0)
	n_hill.seed = 11 + sd * 7
	n_rid.seed = 13 + sd * 5
	n_for.seed = 14 + sd * 3
	n_det.seed = 15 + sd
	for c in chunks.keys():
		chunks[c].queue_free()
	chunks.clear()
	obstacles.clear()
	for k in settle_nodes.keys():
		settle_nodes[k].queue_free()
	settle_nodes.clear()
	extra_obs.clear()
	flickers.clear()
	queue.clear()
	jstage = -1
	if jroot != null:
		jroot.queue_free()
		jroot = null
	water.position = Vector3(road_x(RIVER_Z), river_lvl - 0.1, RIVER_Z)
	last_cc = Vector2i(99999, 99999)


# ---------- settlements ----------
func _settlements(pos: Vector3) -> void:
	for i in SZ.size():
		var dz: float = absf(pos.z - SZ[i])
		if dz < 260.0 and not settle_nodes.has(i):
			settle_nodes[i] = _build_settlement(i)
		elif dz > 420.0 and settle_nodes.has(i):
			settle_nodes[i].queue_free()
			settle_nodes.erase(i)
			extra_obs.erase(i)
			flickers = flickers.filter(func(f): return is_instance_valid(f[0]))


func _house(rng: RandomNumberGenerator) -> Node3D:
	var w: float = rng.randf_range(5.5, 8.0)
	var d: float = rng.randf_range(4.6, 6.5)
	var hg: float = rng.randf_range(2.8, 3.6)
	var rh: float = rng.randf_range(1.7, 2.4)
	var wall: Color = Color(0.5, 0.38, 0.24).lerp(Color(0.62, 0.56, 0.46), rng.randf())
	var roofc: Color = Color(0.38, 0.17, 0.12).lerp(Color(0.25, 0.22, 0.2), rng.randf() * 0.7)
	var st = M.new_st()
	M.box(st, Vector3(w, hg, d), _t(0, 0.3 + hg * 0.5, 0), wall)
	M.box(st, Vector3(w + 0.4, 2.6, d + 0.4), _t(0, -1.0, 0), Color(0.4, 0.38, 0.35))
	M.box(st, Vector3(1.0, 2.0, 0.12), _t(-w * 0.15, 1.3, d * 0.5 + 0.03), Color(0.16, 0.10, 0.06))
	M.box(st, Vector3(0.8, 2.4, 0.8), _t(w * 0.3, 0.3 + hg + rh * 0.8, -d * 0.22), Color(0.42, 0.4, 0.38))
	M.roof_into(st, _t(0, 0.3 + hg, 0), w, d, rh, 0.5, roofc, wall)
	var mesh: ArrayMesh = M.finish(st, Mats.vcol())
	var st2 = M.new_st()
	for sx in [0.22, 0.38]:
		M.box(st2, Vector3(0.8, 0.8, 0.1), _t(w * sx + 0.35, 0.3 + hg * 0.55, d * 0.5 + 0.03), Color(1, 1, 1))
	M.finish(st2, win_mat, mesh)
	var n = Node3D.new()
	var mi = MeshInstance3D.new()
	mi.mesh = mesh
	n.add_child(mi)
	n.set_meta("r", maxf(w, d) * 0.55)
	return n


func _lamp(parent: Node3D, pos: Vector3) -> void:
	var st = M.new_st()
	M.box(st, Vector3(0.14, 3.0, 0.14), _t(0, 1.5, 0), Color(0.12, 0.09, 0.07))
	var mi = MeshInstance3D.new()
	mi.mesh = M.finish(st, Mats.vcol())
	mi.position = pos
	parent.add_child(mi)
	var st2 = M.new_st()
	M.box(st2, Vector3(0.3, 0.3, 0.3), _t(0, 3.1, 0), Color(1, 1, 1))
	var gi = MeshInstance3D.new()
	gi.mesh = M.finish(st2, win_mat)
	gi.position = pos
	parent.add_child(gi)


func _fire(parent: Node3D, pos: Vector3) -> void:
	var f = Node3D.new()
	f.position = pos
	parent.add_child(f)
	var st = M.new_st()
	for i in 7:
		var a: float = float(i) / 7.0 * TAU
		M.ellipsoid(st, Vector3(cos(a) * 0.85, 0.1, sin(a) * 0.85), Vector3(0.28, 0.2, 0.24), 5, 3, 0.0, 1.0, 1, Color(0.4, 0.38, 0.35))
	for i in 3:
		var bs: Basis = Basis(Vector3.UP, float(i) / 3.0 * PI) * Basis(Vector3(0, 0, 1), deg_to_rad(90.0))
		M.limb(st, 0.09, 0.07, 1.0, 5, Transform3D(bs, Vector3(0.5, 0.25 + float(i) * 0.06, 0)), Color(0.18, 0.11, 0.07))
	var mi = MeshInstance3D.new()
	mi.mesh = M.finish(st, Mats.vcol())
	f.add_child(mi)
	var fp: CPUParticles3D = Mats.particles("fire")
	fp.position = Vector3(0, 0.35, 0)
	fp.emitting = true
	f.add_child(fp)
	var l = OmniLight3D.new()
	l.position = Vector3(0, 1.0, 0)
	l.omni_range = 20.0
	l.light_color = Color(1.0, 0.6, 0.28)
	l.light_energy = 2.2
	f.add_child(l)
	flickers.append([l, 2.2, randf() * 10.0])


func _build_settlement(i: int) -> Node3D:
	var root = Node3D.new()
	add_child(root)
	var zc: float = SZ[i]
	var rng = RandomNumberGenerator.new()
	rng.seed = 900 + i
	var obs: Array = []
	if i == 0 or i == 1:
		for k in 8:
			var side: float = 1.0 if k % 2 == 0 else -1.0
			var z: float = zc + float(k / 2 - 2) * 20.0 + rng.randf_range(-3.0, 3.0)
			var x: float = road_x(z) + side * rng.randf_range(15.0, 26.0)
			var hn: Node3D = _house(rng)
			hn.position = Vector3(x, height(x, z), z)
			hn.rotation.y = -side * PI * 0.5 + rng.randf_range(-0.12, 0.12)
			root.add_child(hn)
			obs.append(Vector3(x, z, hn.get_meta("r")))
		for k in 3:
			var zl: float = zc + float(k - 1) * 30.0 + 8.0
			var xl: float = road_x(zl) + (6.0 if k % 2 == 0 else -6.0)
			_lamp(root, Vector3(xl, height(xl, zl), zl))
		var sx: float = road_x(zc + 40.0) + 7.5
		var sg = Node3D.new()
		sg.position = Vector3(sx, height(sx, zc + 40.0), zc + 40.0)
		root.add_child(sg)
		var st = M.new_st()
		M.box(st, Vector3(3.4, 1.2, 0.12), _t(0, 3.0, 0), Color(0.42, 0.3, 0.18))
		M.box(st, Vector3(0.2, 3.6, 0.2), _t(-1.6, 1.8, 0), Color(0.3, 0.2, 0.12))
		M.box(st, Vector3(0.2, 3.6, 0.2), _t(1.6, 1.8, 0), Color(0.3, 0.2, 0.12))
		var smi = MeshInstance3D.new()
		smi.mesh = M.finish(st, Mats.vcol())
		sg.add_child(smi)
		var lb = Label3D.new()
		lb.text = names[i]
		lb.font_size = 80
		lb.pixel_size = 0.0075
		lb.outline_size = 8
		lb.modulate = Color(0.98, 0.9, 0.7)
		lb.position = Vector3(0, 3.0, 0.1)
		sg.add_child(lb)
	elif i == 2:
		var cp: Vector3 = camp_pos()
		_fire(root, cp)
		var st3 = M.new_st()
		for k in 6:
			var a: float = float(k) / 6.0 * TAU
			var bs: Basis = Basis(Vector3.UP, -a + PI * 0.5) * Basis(Vector3(0, 0, 1), deg_to_rad(90.0))
			M.limb(st3, 0.22, 0.2, 1.6, 6, Transform3D(bs, Vector3(cp.x + cos(a) * 3.0, cp.y + 0.25, cp.z + sin(a) * 3.0) + Vector3(0.8, 0, 0)), Color(0.2, 0.13, 0.08))
		for tk in 2:
			var tx: float = cp.x + (7.0 if tk == 0 else -2.0)
			var tz: float = cp.z + (-4.0 if tk == 0 else -9.0)
			M.roof_into(st3, Transform3D(Basis(Vector3.UP, 0.5 * float(tk)), Vector3(tx, height(tx, tz) + 0.05, tz)), 3.6, 4.4, 2.3, 0.0, Color(0.8, 0.74, 0.6), Color(0.7, 0.64, 0.5))
			obs.append(Vector3(tx, tz, 2.4))
		var cmi = MeshInstance3D.new()
		cmi.mesh = M.finish(st3, Mats.vcol2())
		root.add_child(cmi)
	else:
		_build_gate(root, rng, obs)
	extra_obs[i] = obs
	return root


func _build_gate(root: Node3D, rng: RandomNumberGenerator, obs: Array) -> void:
	var gp: Vector3 = gate_pos()
	var g = Node3D.new()
	g.position = gp
	root.add_child(g)
	var stone: Color = Color(0.46, 0.44, 0.40)
	var st = M.new_st()
	for sx in [-1.0, 1.0]:
		M.box(st, Vector3(60.0, 12.0, 3.6), _t(sx * 38.0, 4.0, 0.0), stone)
		obs.append(Vector3(gp.x + sx * 38.0, gp.z, 4.0))
		obs.append(Vector3(gp.x + sx * 55.0, gp.z, 4.0))
		obs.append(Vector3(gp.x + sx * 25.0, gp.z, 4.0))
		for k in 12:
			M.box(st, Vector3(1.6, 1.3, 1.2), _t(sx * 38.0 - 27.5 + float(k) * 5.0, 10.65, 0.0), stone)
		M.lathe(st, [Vector2(4.4, 18.0), Vector2(4.7, 16.4), Vector2(4.4, 0.0), Vector2(5.0, -3.0)], 10, _t(sx * 10.0, 0, 0), 0.0, 1.0, 1, stone, 0.3)
		M.lathe(st, [Vector2(0.0, 26.0), Vector2(5.6, 18.2), Vector2(0.0, 18.0)], 10, _t(sx * 10.0, 0, 0), 0.0, 1.0, 1, Color(0.2, 0.22, 0.34))
		M.box(st, Vector3(2.2, 6.0, 0.08), _t(sx * 10.0, 11.0, 4.6), Color(0.62, 0.1, 0.09))
		M.box(st, Vector3(5.2, 8.2, 0.4), Transform3D(Basis(Vector3.UP, sx * 1.2), Vector3(sx * 6.4, 4.1, -2.8)), Color(0.24, 0.16, 0.09))
		M.box(st, Vector3(0.2, 3.4, 0.2), _t(sx * 6.2, 1.7, 3.4), Color(0.15, 0.1, 0.07))
		var fp: CPUParticles3D = Mats.particles("fire")
		fp.position = Vector3(sx * 6.2, 3.5, 3.4)
		fp.emitting = true
		g.add_child(fp)
		var tl = OmniLight3D.new()
		tl.position = Vector3(sx * 6.2, 3.6, 3.4)
		tl.omni_range = 22.0
		tl.light_color = Color(1.0, 0.62, 0.3)
		tl.light_energy = 2.0
		g.add_child(tl)
		flickers.append([tl, 2.0, rng.randf() * 10.0])
	M.box(st, Vector3(24.0, 5.0, 4.6), _t(0, 10.5, 0), stone)
	var gmi = MeshInstance3D.new()
	gmi.mesh = M.finish(st, Mats.vcol())
	g.add_child(gmi)
	var lb = Label3D.new()
	lb.text = names[3]
	lb.font_size = 200
	lb.pixel_size = 0.012
	lb.outline_size = 20
	lb.modulate = Color(0.98, 0.9, 0.68)
	lb.outline_modulate = Color(0.1, 0.06, 0.03)
	lb.position = Vector3(0, 10.5, 2.4)
	g.add_child(lb)
	for k in 6:
		var side: float = 1.0 if k % 2 == 0 else -1.0
		var z: float = gp.z - 26.0 - float(k / 2) * 20.0
		var x: float = road_x(z) + side * rng.randf_range(14.0, 24.0)
		var hn: Node3D = _house(rng)
		hn.position = Vector3(x, height(x, z), z)
		hn.rotation.y = -side * PI * 0.5
		root.add_child(hn)
	var kst = M.new_st()
	M.lathe(kst, [Vector2(0.0, 52.0), Vector2(8.5, 44.0), Vector2(7.0, 42.0), Vector2(7.0, 0.0), Vector2(8.0, -3.0)], 10, Transform3D.IDENTITY, 0.0, 1.0, 1, stone, 0.3)
	var keep = MeshInstance3D.new()
	keep.mesh = M.finish(kst, Mats.vcol())
	var kx: float = road_x(gp.z - 150.0)
	keep.position = Vector3(kx, height(kx, gp.z - 150.0), gp.z - 150.0)
	root.add_child(keep)


# ---------- per-frame ----------
func _process(delta: float) -> void:
	storm = move_toward(storm, storm_target, delta * 0.25)
	cloud_rig.rotation.y += delta * 0.004
	if absf(hour - applied_hour) > 0.004 or absf(storm - applied_storm) > 0.01:
		_apply_time()
	flash = maxf(0.0, flash - delta * 2.2)
	env.background_energy_multiplier = 1.0 + flash * 1.5
	sun.light_energy = sun_energy + flash * 1.5
	var tm: float = Time.get_ticks_msec() * 0.001
	for f in flickers:
		if is_instance_valid(f[0]):
			f[0].light_energy = f[1] * (0.3 + 0.7 * night_amt) * (0.82 + 0.18 * sin(tm * 17.0 + f[2]))
