extends RefCounted
# Cheap materials: baked vertex colours, per-vertex lighting, no custom heavy shaders.

static var cache: Dictionary = {}

const SH_PUFF = """
shader_type spatial;
render_mode unshaded, blend_mix, depth_draw_never, cull_disabled;
void vertex() {
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
	MODELVIEW_MATRIX = MODELVIEW_MATRIX * mat4(vec4(length(MODEL_MATRIX[0].xyz), 0.0, 0.0, 0.0), vec4(0.0, length(MODEL_MATRIX[1].xyz), 0.0, 0.0), vec4(0.0, 0.0, length(MODEL_MATRIX[2].xyz), 0.0), vec4(0.0, 0.0, 0.0, 1.0));
}
void fragment() {
	float d = length(UV - vec2(0.5)) * 2.0;
	float a = smoothstep(1.0, 0.1, d);
	ALBEDO = COLOR.rgb;
	ALPHA = a * COLOR.a;
}
"""


static func vcol() -> StandardMaterial3D:
	if cache.has("vcol"):
		return cache["vcol"]
	var m = StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 1.0
	m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	cache["vcol"] = m
	return m


static func vcol2() -> StandardMaterial3D:
	if cache.has("vcol2"):
		return cache["vcol2"]
	var m = StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 1.0
	m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	cache["vcol2"] = m
	return m


static func water() -> StandardMaterial3D:
	if cache.has("water"):
		return cache["water"]
	var m = StandardMaterial3D.new()
	m.albedo_color = Color(0.07, 0.25, 0.30, 0.72)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.12
	cache["water"] = m
	return m


static func std(c: Color, rough: float = 0.8, metal: float = 0.0) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m


static func glow(c: Color, energy: float = 2.0) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	return m


static func puff(additive: bool) -> ShaderMaterial:
	var key: String = "puff_add" if additive else "puff_mix"
	if cache.has(key):
		return cache[key]
	var sh = Shader.new()
	sh.code = SH_PUFF.replace("blend_mix", "blend_add") if additive else SH_PUFF
	var m = ShaderMaterial.new()
	m.shader = sh
	cache[key] = m
	return m


static func _ramp(cols: Array, offs: Array) -> Gradient:
	var g = Gradient.new()
	g.colors = PackedColorArray(cols)
	g.offsets = PackedFloat32Array(offs)
	return g


static func particles(kind: String) -> CPUParticles3D:
	var p = CPUParticles3D.new()
	var qm = QuadMesh.new()
	qm.size = Vector2(1, 1)
	qm.material = puff(false)
	p.mesh = qm
	p.local_coords = false
	p.emitting = false
	match kind:
		"fire":
			qm.material = puff(true)
			p.amount = 12
			p.lifetime = 0.9
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
			p.emission_sphere_radius = 0.2
			p.direction = Vector3(0, 1, 0)
			p.spread = 14.0
			p.gravity = Vector3(0, 1.4, 0)
			p.initial_velocity_min = 0.5
			p.initial_velocity_max = 1.2
			p.scale_amount_min = 0.4
			p.scale_amount_max = 0.9
			p.color_ramp = _ramp([Color(1.0, 0.85, 0.45, 0.9), Color(1.0, 0.42, 0.08, 0.7), Color(0.4, 0.05, 0.0, 0.0)], [0.0, 0.45, 1.0])
		"dust":
			p.amount = 8
			p.lifetime = 1.2
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
			p.emission_sphere_radius = 0.5
			p.direction = Vector3(0, 0.5, 1)
			p.spread = 40.0
			p.gravity = Vector3(0, 0.25, 0)
			p.initial_velocity_min = 0.6
			p.initial_velocity_max = 1.8
			p.scale_amount_min = 1.0
			p.scale_amount_max = 2.2
			p.color_ramp = _ramp([Color(0.55, 0.45, 0.32, 0.0), Color(0.55, 0.45, 0.32, 0.3), Color(0.55, 0.45, 0.32, 0.0)], [0.0, 0.15, 1.0])
		"splash":
			p.amount = 12
			p.lifetime = 0.6
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
			p.emission_box_extents = Vector3(1.2, 0.1, 2.0)
			p.direction = Vector3(0, 1, 0)
			p.spread = 45.0
			p.gravity = Vector3(0, -9.0, 0)
			p.initial_velocity_min = 2.0
			p.initial_velocity_max = 3.5
			p.scale_amount_min = 0.2
			p.scale_amount_max = 0.45
			p.color_ramp = _ramp([Color(0.85, 0.95, 1.0, 0.7), Color(0.85, 0.95, 1.0, 0.0)], [0.0, 1.0])
		"hit":
			p.amount = 8
			p.lifetime = 0.5
			p.one_shot = true
			p.explosiveness = 1.0
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
			p.emission_sphere_radius = 0.2
			p.direction = Vector3(0, 1, 0)
			p.spread = 90.0
			p.gravity = Vector3(0, -8.0, 0)
			p.initial_velocity_min = 2.0
			p.initial_velocity_max = 4.5
			p.scale_amount_min = 0.25
			p.scale_amount_max = 0.5
			p.color_ramp = _ramp([Color(0.6, 0.5, 0.38, 0.8), Color(0.6, 0.5, 0.38, 0.0)], [0.0, 1.0])
		"rain":
			var bm = BoxMesh.new()
			bm.size = Vector3(0.012, 0.6, 0.012)
			var rm = StandardMaterial3D.new()
			rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			rm.albedo_color = Color(0.75, 0.82, 0.9, 0.4)
			bm.material = rm
			p.mesh = bm
			p.amount = 120
			p.lifetime = 0.8
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
			p.emission_box_extents = Vector3(18, 0.5, 18)
			p.direction = Vector3(0.12, -1, 0)
			p.spread = 0.0
			p.gravity = Vector3(0, 0, 0)
			p.initial_velocity_min = 30.0
			p.initial_velocity_max = 36.0
			p.scale_amount_min = 1.0
			p.scale_amount_max = 1.0
	return p
