extends RefCounted
# Every surface in the game is generated on the GPU by these shaders. No texture files.

static var cache: Dictionary = {}

const NOISE = """
float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = hash21(i);
	float b = hash21(i + vec2(1.0, 0.0));
	float c = hash21(i + vec2(0.0, 1.0));
	float d = hash21(i + vec2(1.0, 1.0));
	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm3(vec2 p) {
	float s = 0.0;
	float a = 0.5;
	for (int i = 0; i < 3; i++) {
		s += a * vnoise(p);
		p = p * 2.07 + vec2(11.3, 7.7);
		a *= 0.5;
	}
	return s;
}
"""

const ROAD = """
float road_f(float z) { return 34.0 * sin(z * 0.0045) + 20.0 * sin(z * 0.0118 + 1.3) + 6.0 * sin(z * 0.027 + 0.4); }
float road_x(float z) { return road_f(z) - road_f(0.0); }
"""

const SH_TERRAIN = """
shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;
//NOISE//
//ROAD//
uniform float wet = 0.0;
uniform float snow_line = 165.0;
varying vec3 wp;
varying vec3 wn;
void vertex() { wp = VERTEX; wn = NORMAL; }
void fragment() {
	vec2 p = wp.xz;
	float dcam = length(VERTEX);
	float fade = 1.0 - smoothstep(30.0, 150.0, dcam);
	float slope = 1.0 - clamp(wn.y, 0.0, 1.0);
	float big = fbm3(p * 0.010);
	float mid = fbm3(p * 0.085);
	float fine = mix(0.5, vnoise(p * 1.9), fade);
	vec3 grass = mix(vec3(0.12, 0.21, 0.045), vec3(0.26, 0.33, 0.085), mid);
	grass = mix(grass, vec3(0.40, 0.34, 0.15), smoothstep(0.50, 0.78, big) * 0.7);
	grass *= 0.82 + 0.36 * fine;
	vec3 rock = mix(vec3(0.27, 0.25, 0.23), vec3(0.50, 0.46, 0.40), fbm3(p * 0.35 + vec2(wp.y * 0.2)));
	float rw = smoothstep(0.20, 0.40, slope + (mid - 0.5) * 0.10);
	vec3 col = mix(grass, rock, rw);
	float sn = smoothstep(snow_line, snow_line + 45.0, wp.y + (mid - 0.5) * 30.0) * (1.0 - smoothstep(0.30, 0.60, slope));
	col = mix(col, vec3(0.90, 0.93, 0.98), sn);
	float cx = road_x(p.y);
	float dr = abs(p.x - cx);
	float wob = (vnoise(p * 0.22) - 0.5) * 1.8;
	float road = 1.0 - smoothstep(3.0 + wob, 4.3 + wob, dr);
	float rut = (1.0 - smoothstep(0.12, 0.5, abs(dr - 1.15))) * road;
	vec3 dirt = mix(vec3(0.30, 0.22, 0.14), vec3(0.46, 0.36, 0.23), fbm3(p * 0.6)) * (0.88 + 0.24 * fine);
	dirt *= 1.0 - 0.38 * rut;
	float verge = clamp((1.0 - smoothstep(3.5, 8.0, dr)) * 0.5 * (0.4 + fine), 0.0, 1.0);
	col = mix(col, dirt * vec3(0.95, 1.0, 0.85), verge * (1.0 - road));
	col = mix(col, dirt, road);
	col *= 1.0 - wet * 0.35;
	ALBEDO = col;
	ROUGHNESS = clamp(mix(0.95, 0.85, road * 0.5) - wet * 0.45, 0.2, 1.0);
	SPECULAR = 0.2 + wet * 0.3;
	float e = 0.35;
	float h0 = vnoise(p * 2.3) * 0.7 + vnoise(p * 6.1) * 0.3;
	vec2 px = p + vec2(e, 0.0);
	vec2 pz = p + vec2(0.0, e);
	float hx = vnoise(px * 2.3) * 0.7 + vnoise(px * 6.1) * 0.3;
	float hz = vnoise(pz * 2.3) * 0.7 + vnoise(pz * 6.1) * 0.3;
	float k = mix(0.5, 1.5, rw) * fade;
	vec3 nn = normalize(vec3(wn.x - (hx - h0) * k, wn.y, wn.z - (hz - h0) * k));
	NORMAL = normalize((VIEW_MATRIX * vec4(nn, 0.0)).xyz);
}
"""

const SH_WATER = """
shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, specular_schlick_ggx;
//NOISE//
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec2 p = wp.xz;
	float t = TIME;
	vec2 f1 = p * 0.35 + vec2(t * 0.45, t * 0.05);
	vec2 f2 = p * 0.9 + vec2(t * 0.9, -t * 0.1);
	float e = 0.08;
	float h = vnoise(f1) * 0.6 + vnoise(f2) * 0.4;
	float hx = vnoise(f1 + vec2(e, 0.0)) * 0.6 + vnoise(f2 + vec2(e, 0.0)) * 0.4;
	float hz = vnoise(f1 + vec2(0.0, e)) * 0.6 + vnoise(f2 + vec2(0.0, e)) * 0.4;
	vec3 n = normalize(vec3(-(hx - h) * 7.0, 1.0, -(hz - h) * 7.0));
	NORMAL = normalize((VIEW_MATRIX * vec4(n, 0.0)).xyz);
	float fres = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 3.0);
	ALBEDO = mix(vec3(0.10, 0.30, 0.30), vec3(0.02, 0.14, 0.18), 0.5 + 0.3 * h);
	ROUGHNESS = 0.05;
	SPECULAR = 0.9;
	ALPHA = clamp(0.66 + fres * 0.34, 0.0, 1.0);
}
"""

const SH_FOLIAGE = """
shader_type spatial;
render_mode cull_disabled, diffuse_burley;
//NOISE//
uniform vec3 c_dark : source_color = vec3(0.04, 0.12, 0.05);
uniform vec3 c_light : source_color = vec3(0.16, 0.30, 0.09);
uniform float hs = 10.0;
uniform float sway = 0.35;
uniform float wind = 1.0;
varying float vh;
varying float tint;
void vertex() {
	vec3 ip = MODEL_MATRIX[3].xyz;
	tint = hash21(ip.xz * 0.37);
	vh = clamp(VERTEX.y / hs, 0.0, 1.0);
	float ph = TIME * 1.4 + ip.x * 0.21 + ip.z * 0.17;
	float amt = sway * vh * vh * wind;
	VERTEX.x += sin(ph) * amt + sin(ph * 2.3 + VERTEX.y) * amt * 0.25;
	VERTEX.z += cos(ph * 0.8) * amt * 0.6;
}
void fragment() {
	float n = vnoise(UV * vec2(9.0, 13.0) + vec2(tint * 40.0));
	vec3 base = mix(c_dark, c_light, clamp(vh * 0.65 + n * 0.55, 0.0, 1.0));
	base *= 0.82 + 0.34 * tint;
	ALBEDO = base;
	ROUGHNESS = 0.85;
	BACKLIGHT = base * 0.30;
}
"""

const SH_BARK = """
shader_type spatial;
//NOISE//
uniform vec3 c1 : source_color = vec3(0.22, 0.15, 0.10);
uniform vec3 c2 : source_color = vec3(0.36, 0.26, 0.17);
uniform float spot = 0.0;
void fragment() {
	float s = vnoise(vec2(UV.x * 18.0, UV.y * 5.0));
	float r = vnoise(vec2(UV.x * 44.0, UV.y * 15.0));
	vec3 base = mix(c1, c2, s * 0.7 + r * 0.3);
	base = mix(base, vec3(0.04), spot * smoothstep(0.72, 0.80, r));
	ALBEDO = base;
	ROUGHNESS = 0.95;
}
"""

const SH_ROCK = """
shader_type spatial;
//NOISE//
varying vec3 wp;
varying vec3 wn;
void vertex() {
	wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wn = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}
void fragment() {
	float n = fbm3(wp.xz * 0.9 + vec2(wp.y * 0.8));
	vec3 col = mix(vec3(0.24, 0.23, 0.22), vec3(0.50, 0.47, 0.42), n);
	float moss = smoothstep(0.55, 0.95, wn.y) * smoothstep(0.35, 0.7, vnoise(wp.xz * 1.7));
	col = mix(col, vec3(0.13, 0.22, 0.07), moss * 0.8);
	ALBEDO = col;
	ROUGHNESS = 0.92;
}
"""

const SH_GRASS = """
shader_type spatial;
render_mode cull_disabled;
//NOISE//
uniform vec3 c_base : source_color = vec3(0.07, 0.15, 0.03);
uniform vec3 c_tip : source_color = vec3(0.40, 0.50, 0.14);
varying float vh;
varying float tint;
void vertex() {
	vec3 ip = MODEL_MATRIX[3].xyz;
	vh = UV.y;
	tint = hash21(ip.xz * 0.53);
	float d = length(ip - CAMERA_POSITION_WORLD);
	float sc = 1.0 - smoothstep(60.0, 95.0, d);
	VERTEX.y *= sc;
	float ph = TIME * 1.7 + ip.x * 0.5 + ip.z * 0.4;
	VERTEX.x += sin(ph) * 0.14 * vh * vh + sin(TIME * 3.1 + ip.z) * 0.04 * vh;
	VERTEX.z += cos(ph * 0.9) * 0.07 * vh * vh;
}
void fragment() {
	vec3 col = mix(c_base, c_tip, vh) * (0.8 + 0.4 * tint);
	ALBEDO = col;
	ROUGHNESS = 0.9;
	NORMAL = normalize((VIEW_MATRIX * vec4(0.0, 1.0, 0.0, 0.0)).xyz);
	BACKLIGHT = col * 0.25;
}
"""

const SH_PLANKS = """
shader_type spatial;
//NOISE//
varying vec3 op;
uniform vec3 c1 : source_color = vec3(0.42, 0.30, 0.18);
uniform vec3 c2 : source_color = vec3(0.28, 0.19, 0.11);
uniform float scale = 4.0;
void vertex() { op = VERTEX; }
void fragment() {
	float row = floor(op.y * scale);
	float run = op.x + op.z;
	float g = vnoise(vec2(run * 2.5 + row * 7.1, op.y * 38.0));
	float tone = hash21(vec2(row, floor(run * 0.5 + row)));
	vec3 col = mix(c1, c2, tone * 0.6 + g * 0.5);
	float f = fract(op.y * scale);
	float gap = smoothstep(0.0, 0.07, f) * smoothstep(1.0, 0.93, f);
	col *= mix(0.45, 1.0, gap);
	ALBEDO = col;
	ROUGHNESS = 0.88;
}
"""

const SH_SHINGLE = """
shader_type spatial;
render_mode cull_disabled;
//NOISE//
varying vec3 op;
uniform vec3 c1 : source_color = vec3(0.36, 0.17, 0.12);
uniform vec3 c2 : source_color = vec3(0.22, 0.12, 0.10);
void vertex() { op = VERTEX; }
void fragment() {
	float s = op.y * 1.7 + abs(op.x) * 0.8;
	float r = floor(s * 3.0);
	float cell = floor(op.z * 2.2 + r * 0.5);
	float tone = hash21(vec2(r, cell));
	float line = smoothstep(0.0, 0.14, fract(s * 3.0));
	ALBEDO = mix(c1, c2, tone) * (0.55 + 0.45 * line);
	ROUGHNESS = 0.9;
}
"""

const SH_STONE = """
shader_type spatial;
//NOISE//
varying vec3 wp;
varying vec3 wn;
uniform vec3 c1 : source_color = vec3(0.50, 0.48, 0.44);
uniform vec3 c2 : source_color = vec3(0.30, 0.29, 0.27);
void vertex() {
	wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wn = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}
void fragment() {
	vec2 uv = (abs(wn.y) > 0.7) ? wp.xz : ((abs(wn.x) > abs(wn.z)) ? wp.zy : wp.xy);
	uv *= vec2(0.9, 1.8);
	float row = floor(uv.y);
	uv.x += mod(row, 2.0) * 0.5;
	vec2 cell = floor(uv);
	vec2 f = fract(uv);
	float tone = hash21(cell);
	float edge = smoothstep(0.0, 0.07, f.x) * smoothstep(1.0, 0.93, f.x) * smoothstep(0.0, 0.10, f.y) * smoothstep(1.0, 0.90, f.y);
	vec3 col = mix(c1, c2, tone) * (0.55 + 0.45 * edge) * (0.85 + 0.3 * vnoise(wp.xz * 3.0 + vec2(wp.y * 3.0)));
	ALBEDO = col;
	ROUGHNESS = 0.93;
}
"""

const SH_CLOTH = """
shader_type spatial;
render_mode cull_disabled;
//NOISE//
varying vec3 op;
uniform vec3 c1 : source_color = vec3(0.86, 0.80, 0.66);
uniform vec3 c2 : source_color = vec3(0.60, 0.52, 0.38);
void vertex() { op = VERTEX; }
void fragment() {
	float weave = sin(op.x * 210.0) * sin((op.z + op.y) * 210.0);
	float stain = fbm3(vec2(op.x, op.z + op.y) * 1.4);
	vec3 col = mix(c1, c2, stain * 0.9) * (0.93 + 0.07 * weave);
	ALBEDO = col;
	ROUGHNESS = 0.95;
	BACKLIGHT = col * 0.35;
}
"""

const SH_FUR = """
shader_type spatial;
//NOISE//
varying vec3 op;
uniform vec3 coat : source_color = vec3(0.30, 0.18, 0.10);
void vertex() { op = VERTEX; }
void fragment() {
	float n = vnoise(op.xz * 9.0 + vec2(op.y * 6.0));
	vec3 col = coat * (0.80 + 0.40 * n);
	ALBEDO = col;
	ROUGHNESS = 0.62;
	RIM = 0.4;
	RIM_TINT = 0.5;
}
"""

const SH_SKY = """
shader_type sky;
//NOISE//
uniform vec3 top_col : source_color = vec3(0.16, 0.38, 0.80);
uniform vec3 hor_col : source_color = vec3(0.62, 0.76, 0.92);
uniform vec3 gnd_col : source_color = vec3(0.10, 0.11, 0.10);
uniform vec3 sun_dir = vec3(0.3, 0.6, -0.4);
uniform vec3 sun_col : source_color = vec3(1.0, 0.9, 0.7);
uniform vec3 cloud_lit : source_color = vec3(1.0, 1.0, 1.0);
uniform vec3 cloud_shade : source_color = vec3(0.55, 0.60, 0.70);
uniform float cloud_cover = 0.45;
uniform float cloud_t = 0.0;
uniform float star_vis = 0.0;
uniform float sun_vis = 1.0;
void sky() {
	vec3 d = normalize(EYEDIR);
	float h = d.y;
	vec3 sdir = normalize(sun_dir);
	float sd = max(dot(d, sdir), 0.0);
	vec3 col = mix(hor_col, top_col, pow(clamp(h, 0.0, 1.0), 0.55));
	col += sun_col * pow(sd, 5.0) * 0.30 * (1.0 - clamp(h * 1.5, 0.0, 1.0)) * sun_vis;
	if (h < 0.0) {
		col = mix(hor_col * 0.9, gnd_col, smoothstep(0.0, -0.25, h));
	}
	float disc = pow(sd, 1200.0) * 12.0 + pow(sd, 18.0) * 0.5;
	col += sun_col * disc * sun_vis * step(-0.02, h);
	float cm = 0.0;
	if (h > 0.0) {
		vec2 cp = d.xz / (h + 0.25) * 1.1 + vec2(cloud_t, cloud_t * 0.35);
		float c = fbm3(cp * 1.3);
		cm = smoothstep(1.0 - cloud_cover, 1.0 - cloud_cover + 0.22, c) * smoothstep(0.0, 0.10, h);
		vec3 ccol = mix(cloud_shade, cloud_lit, smoothstep(0.3, 0.8, c));
		ccol *= 0.35 + 0.65 * clamp(sdir.y * 2.0 + 0.3, 0.0, 1.0);
		ccol += sun_col * pow(sd, 8.0) * 0.5 * sun_vis;
		col = mix(col, ccol, cm * 0.9);
	}
	if (star_vis > 0.01 && h > 0.0) {
		vec2 su = vec2(atan(d.x, d.z) * 90.0, asin(clamp(h, -1.0, 1.0)) * 180.0);
		vec2 cell = floor(su);
		float r = hash21(cell);
		float tw = 0.6 + 0.4 * sin(r * 80.0 + cloud_t * 400.0);
		float s = step(0.985, r) * smoothstep(0.40, 0.05, length(fract(su) - 0.5)) * tw;
		col += vec3(0.85, 0.9, 1.0) * s * star_vis * (1.0 - cm);
	}
	COLOR = col;
}
"""

const SH_PUFF = """
shader_type spatial;
render_mode unshaded, blend_mix, depth_draw_never, cull_disabled;
void vertex() {
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
	MODELVIEW_MATRIX = MODELVIEW_MATRIX * mat4(vec4(length(MODEL_MATRIX[0].xyz), 0.0, 0.0, 0.0), vec4(0.0, length(MODEL_MATRIX[1].xyz), 0.0, 0.0), vec4(0.0, 0.0, length(MODEL_MATRIX[2].xyz), 0.0), vec4(0.0, 0.0, 0.0, 1.0));
}
void fragment() {
	float d = length(UV - vec2(0.5)) * 2.0;
	float a = smoothstep(1.0, 0.1, d);
	ALBEDO = COLOR.rgb;
	ALPHA = a * COLOR.a;
}
"""


static func get_mat(key: String) -> ShaderMaterial:
	if cache.has(key):
		return cache[key]
	var code: String = ""
	match key:
		"terrain": code = SH_TERRAIN
		"water": code = SH_WATER
		"foliage": code = SH_FOLIAGE
		"bark": code = SH_BARK
		"rock": code = SH_ROCK
		"grass": code = SH_GRASS
		"planks": code = SH_PLANKS
		"shingle": code = SH_SHINGLE
		"stone": code = SH_STONE
		"cloth": code = SH_CLOTH
		"fur": code = SH_FUR
		"sky": code = SH_SKY
		"puff_mix": code = SH_PUFF
		"puff_add": code = SH_PUFF.replace("blend_mix", "blend_add")
	var sh = Shader.new()
	sh.code = code.replace("//NOISE//", NOISE).replace("//ROAD//", ROAD)
	var m = ShaderMaterial.new()
	m.shader = sh
	cache[key] = m
	return m


static func variant(key: String, params: Dictionary) -> ShaderMaterial:
	var m: ShaderMaterial = get_mat(key).duplicate()
	for k in params.keys():
		m.set_shader_parameter(k, params[k])
	return m


static func std(c: Color, rough: float = 0.8, metal: float = 0.0) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m


static func glow(c: Color, energy: float = 2.0) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	return m


static func _ramp(cols: Array, offs: Array) -> Gradient:
	var g = Gradient.new()
	g.colors = PackedColorArray(cols)
	g.offsets = PackedFloat32Array(offs)
	return g


static func particles(kind: String) -> CPUParticles3D:
	var p = CPUParticles3D.new()
	var qm = QuadMesh.new()
	qm.size = Vector2(1, 1)
	qm.material = get_mat("puff_mix")
	p.mesh = qm
	p.local_coords = false
	p.emitting = false
	match kind:
		"fire":
			qm.material = get_mat("puff_add")
			p.amount = 36
			p.lifetime = 0.9
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
			p.emission_sphere_radius = 0.22
			p.direction = Vector3(0, 1, 0)
			p.spread = 14.0
			p.gravity = Vector3(0, 1.4, 0)
			p.initial_velocity_min = 0.5
			p.initial_velocity_max = 1.3
			p.scale_amount_min = 0.35
			p.scale_amount_max = 0.8
			p.color_ramp = _ramp([Color(1.0, 0.85, 0.45, 0.9), Color(1.0, 0.42, 0.08, 0.7), Color(0.4, 0.05, 0.0, 0.0)], [0.0, 0.45, 1.0])
		"smoke":
			p.amount = 14
			p.lifetime = 3.6
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
			p.emission_sphere_radius = 0.2
			p.direction = Vector3(0, 1, 0)
			p.spread = 10.0
			p.gravity = Vector3(0.3, 0.5, 0)
			p.initial_velocity_min = 0.4
			p.initial_velocity_max = 0.9
			p.scale_amount_min = 1.0
			p.scale_amount_max = 2.6
			p.color_ramp = _ramp([Color(0.3, 0.3, 0.3, 0.0), Color(0.3, 0.3, 0.3, 0.32), Color(0.35, 0.35, 0.35, 0.0)], [0.0, 0.2, 1.0])
		"dust":
			p.amount = 26
			p.lifetime = 1.4
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
			p.emission_sphere_radius = 0.5
			p.direction = Vector3(0, 0.5, 1)
			p.spread = 40.0
			p.gravity = Vector3(0, 0.25, 0)
			p.initial_velocity_min = 0.6
			p.initial_velocity_max = 2.0
			p.scale_amount_min = 0.8
			p.scale_amount_max = 2.2
			p.color_ramp = _ramp([Color(0.55, 0.45, 0.32, 0.0), Color(0.55, 0.45, 0.32, 0.34), Color(0.55, 0.45, 0.32, 0.0)], [0.0, 0.15, 1.0])
		"splash":
			p.amount = 36
			p.lifetime = 0.7
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
			p.emission_box_extents = Vector3(1.2, 0.1, 2.0)
			p.direction = Vector3(0, 1, 0)
			p.spread = 45.0
			p.gravity = Vector3(0, -9.0, 0)
			p.initial_velocity_min = 2.0
			p.initial_velocity_max = 4.0
			p.scale_amount_min = 0.15
			p.scale_amount_max = 0.4
			p.color_ramp = _ramp([Color(0.85, 0.95, 1.0, 0.7), Color(0.85, 0.95, 1.0, 0.0)], [0.0, 1.0])
		"hit":
			p.amount = 14
			p.lifetime = 0.55
			p.one_shot = true
			p.explosiveness = 1.0
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
			p.emission_sphere_radius = 0.2
			p.direction = Vector3(0, 1, 0)
			p.spread = 90.0
			p.gravity = Vector3(0, -8.0, 0)
			p.initial_velocity_min = 2.0
			p.initial_velocity_max = 5.0
			p.scale_amount_min = 0.2
			p.scale_amount_max = 0.5
			p.color_ramp = _ramp([Color(0.6, 0.5, 0.38, 0.8), Color(0.6, 0.5, 0.38, 0.0)], [0.0, 1.0])
		"rain":
			var bm = BoxMesh.new()
			bm.size = Vector3(0.012, 0.6, 0.012)
			var rm = StandardMaterial3D.new()
			rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			rm.albedo_color = Color(0.75, 0.82, 0.9, 0.45)
			bm.material = rm
			p.mesh = bm
			p.amount = 420
			p.lifetime = 0.8
			p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
			p.emission_box_extents = Vector3(22, 0.5, 22)
			p.direction = Vector3(0.12, -1, 0)
			p.spread = 0.0
			p.gravity = Vector3(0, 0, 0)
			p.initial_velocity_min = 30.0
			p.initial_velocity_max = 36.0
			p.scale_amount_min = 1.0
			p.scale_amount_max = 1.0
	return p
