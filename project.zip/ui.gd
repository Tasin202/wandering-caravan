extends CanvasLayer
# Fresh dark-glass UI: drawn HUD, floating touch controls (multi-touch) and card style event panels.

const AMBER = Color(0.96, 0.72, 0.34)
const CREAM = Color(0.97, 0.93, 0.85)

var G
var root: Control
var hud: Control
var panel: Control = null
var th: Theme
var sb_panel: StyleBoxFlat
var sb_chip: StyleBoxFlat

var stick_id: int = -1
var stick_origin: Vector2 = Vector2.ZERO
var stick: Vector2 = Vector2.ZERO
var whip_id: int = -1
var brake_id: int = -1
var cam_id: int = -1
var cam_delta: Vector2 = Vector2.ZERO
var cam_start: Vector2 = Vector2.ZERO
var cam_moved: bool = false
var cam_t0: float = 0.0
var whip_down: bool = false
var brake_down: bool = false

var barks: Array = []
var banner_text: String = ""
var banner_sub: String = ""
var banner_t: float = 0.0
var pops: Array = []
var fade: float = 1.0
var red: float = 0.0
var loading_text: String = ""
var loading_p: float = 0.0
var title_big: String = ""
var title_sub: String = ""
var title_a: float = 0.0


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	th = _make_theme()
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = th
	add_child(root)
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.draw.connect(_draw_hud)
	root.add_child(hud)
	sb_panel = _sb(Color(0.05, 0.06, 0.08, 0.62), Color(0.85, 0.62, 0.3, 0.55), 22, 2)
	sb_chip = _sb(Color(0.05, 0.06, 0.08, 0.55), Color(1, 1, 1, 0.0), 14, 0)


func _sb(bg: Color, border: Color, radius: int, bw: int) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(18)
	return s


func _make_theme() -> Theme:
	var t = Theme.new()
	t.default_font_size = 28
	t.set_color("font_color", "Label", CREAM)
	t.set_color("font_color", "Button", CREAM)
	t.set_color("font_hover_color", "Button", Color(1, 1, 1))
	t.set_color("font_pressed_color", "Button", Color(0.1, 0.07, 0.03))
	t.set_color("font_disabled_color", "Button", Color(0.5, 0.5, 0.5))
	t.set_stylebox("normal", "Button", _sb(Color(0.13, 0.14, 0.18, 0.96), Color(0.62, 0.47, 0.25, 0.85), 16, 2))
	t.set_stylebox("hover", "Button", _sb(Color(0.20, 0.19, 0.20, 0.98), AMBER, 16, 2))
	t.set_stylebox("pressed", "Button", _sb(AMBER, AMBER, 16, 2))
	t.set_stylebox("disabled", "Button", _sb(Color(0.09, 0.09, 0.1, 0.9), Color(0.3, 0.3, 0.3, 0.6), 16, 2))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_stylebox("panel", "PanelContainer", _sb(Color(0.04, 0.05, 0.07, 0.94), Color(0.86, 0.62, 0.3, 0.95), 24, 3))
	return t


func vsize() -> Vector2:
	return get_viewport().get_visible_rect().size


# ---------- input ----------
func steer() -> float:
	if stick_id != -1:
		return stick.x
	return Input.get_axis("ui_left", "ui_right")


func throttle() -> float:
	if stick_id != -1:
		return clampf(-stick.y, 0.0, 1.0)
	return clampf(-Input.get_axis("ui_up", "ui_down"), 0.0, 1.0)


func is_whip() -> bool:
	return whip_down or Input.is_key_pressed(KEY_SPACE)


func is_brake() -> bool:
	if stick_id != -1 and stick.y > 0.6:
		return true
	return brake_down or Input.is_key_pressed(KEY_SHIFT) or Input.get_axis("ui_up", "ui_down") > 0.5


func whip_c(sz: Vector2) -> Vector2:
	return Vector2(sz.x - 190.0, sz.y - 240.0)


func brake_c(sz: Vector2) -> Vector2:
	return Vector2(sz.x - 440.0, sz.y - 150.0)


func ctx_c(sz: Vector2) -> Vector2:
	return Vector2(sz.x - 190.0, sz.y - 440.0)


func reset_touch() -> void:
	stick_id = -1
	whip_id = -1
	brake_id = -1
	cam_id = -1
	stick = Vector2.ZERO
	whip_down = false
	brake_down = false


func _input(event: InputEvent) -> void:
	if G == null or panel != null or not G.controls_on():
		return
	var sz: Vector2 = vsize()
	if event is InputEventScreenTouch:
		var p: Vector2 = event.position
		if event.pressed:
			if p.distance_to(Vector2(sz.x - 70.0, 70.0)) < 62.0:
				G.pause_menu()
				return
			if p.distance_to(whip_c(sz)) < 125.0 and whip_id == -1:
				whip_id = event.index
				whip_down = true
				return
			if G.ctx_label != "" and p.distance_to(ctx_c(sz)) < 95.0:
				G.on_ctx()
				return
			if p.distance_to(brake_c(sz)) < 100.0 and brake_id == -1:
				brake_id = event.index
				brake_down = true
				return
			if p.x < sz.x * 0.42 and p.y > sz.y * 0.22 and stick_id == -1 and G.st != "raid":
				stick_id = event.index
				stick_origin = p
				stick = Vector2.ZERO
			elif cam_id == -1:
				cam_id = event.index
				cam_start = p
				cam_moved = false
				cam_t0 = Time.get_ticks_msec() * 0.001
		else:
			if event.index == stick_id:
				stick_id = -1
				stick = Vector2.ZERO
			elif event.index == whip_id:
				whip_id = -1
				whip_down = false
			elif event.index == brake_id:
				brake_id = -1
				brake_down = false
			elif event.index == cam_id:
				var held: float = Time.get_ticks_msec() * 0.001 - cam_t0
				if not cam_moved and held < 0.45 and G.combat:
					G.on_tap(cam_start)
				cam_id = -1
	elif event is InputEventScreenDrag:
		if event.index == stick_id:
			stick = ((event.position - stick_origin) / 110.0).limit_length(1.0)
		elif event.index == cam_id:
			cam_delta += event.relative
			if event.position.distance_to(cam_start) > 18.0:
				cam_moved = true


# ---------- feedback ----------
func bark(who: String, text: String, col: Color = AMBER) -> void:
	barks.append({"who": who, "text": text, "t": 5.5, "col": col})
	if barks.size() > 3:
		barks.pop_front()


func banner(text: String, sub: String = "", secs: float = 3.0) -> void:
	banner_text = text
	banner_sub = sub
	banner_t = secs


func pop(text: String, pos: Vector2, col: Color = Color(1, 1, 1)) -> void:
	pops.append({"text": text, "pos": pos, "t": 1.1, "col": col})


func hurt(amount: float = 0.5) -> void:
	red = minf(1.0, red + amount)


func fade_to(a: float, secs: float) -> void:
	var tw = create_tween()
	tw.tween_property(self, "fade", a, secs)


func _process(delta: float) -> void:
	for b in barks:
		b["t"] -= delta
	while barks.size() > 0 and barks[0]["t"] <= 0.0:
		barks.pop_front()
	banner_t = maxf(0.0, banner_t - delta)
	for p in pops:
		p["t"] -= delta
		p["pos"] = p["pos"] + Vector2(0, -60.0 * delta)
	pops = pops.filter(func(p): return p["t"] > 0.0)
	red = maxf(0.0, red - delta * 1.4)
	hud.queue_redraw()


# ---------- panels ----------
func is_open() -> bool:
	return panel != null


func close_panel() -> void:
	if panel != null:
		panel.queue_free()
		panel = null


# items: [{"t": text, "s": subtext, "f": Callable, "d": disabled, "keep": bool}]
func show_panel(title: String, body: String, items: Array, cols: int = 1) -> void:
	close_panel()
	reset_touch()
	var sz: Vector2 = vsize()
	var pw: float = minf(1500.0, sz.x * 0.84)
	var pc = PanelContainer.new()
	pc.custom_minimum_size = Vector2(pw, 0)
	pc.set_anchors_preset(Control.PRESET_CENTER)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.grow_vertical = Control.GROW_DIRECTION_BOTH
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	pc.add_child(vb)
	var tl = Label.new()
	tl.text = title
	tl.add_theme_font_size_override("font_size", 54)
	tl.add_theme_color_override("font_color", AMBER)
	vb.add_child(tl)
	if body != "":
		var bl = Label.new()
		bl.text = body
		bl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		bl.custom_minimum_size = Vector2(pw - 80.0, 0)
		bl.add_theme_font_size_override("font_size", 30)
		vb.add_child(bl)
	var grid = GridContainer.new()
	grid.columns = cols
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 12)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var rows: int = int(ceil(float(items.size()) / float(cols)))
	var est: float = 0.0
	for it in items:
		var b = Button.new()
		var sub: String = it.get("s", "")
		b.text = it["t"] + ("\n" + sub if sub != "" else "")
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.custom_minimum_size = Vector2(0, 108 if sub != "" else 76)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.disabled = it.get("d", false)
		b.pressed.connect(_pick.bind(it))
		grid.add_child(b)
	est = float(rows) * (120.0 if body == "" else 120.0)
	var maxh: float = sz.y * 0.9 - 260.0 - (0.0 if body == "" else 40.0 * ceil(float(body.length()) / 70.0))
	if est > maxh:
		var sc = ScrollContainer.new()
		sc.custom_minimum_size = Vector2(pw - 60.0, maxf(240.0, maxh))
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		sc.add_child(grid)
		vb.add_child(sc)
	else:
		vb.add_child(grid)
	root.add_child(pc)
	panel = pc
	pc.modulate.a = 0.0
	var tw = create_tween()
	tw.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tw.tween_property(pc, "modulate:a", 1.0, 0.18)


func _pick(it: Dictionary) -> void:
	if not it.get("keep", false):
		close_panel()
	var f: Callable = it["f"]
	f.call()


# ---------- HUD drawing ----------
func _t(s: String, p: Vector2, size: int, col: Color) -> void:
	var f: Font = ThemeDB.fallback_font
	hud.draw_string(f, p + Vector2(2, 2), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0, 0, 0, 0.7))
	hud.draw_string(f, p, s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


func _tc(s: String, c: Vector2, size: int, col: Color) -> void:
	var f: Font = ThemeDB.fallback_font
	var w: float = f.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	_t(s, Vector2(c.x - w * 0.5, c.y + size * 0.35), size, col)


func _bar(p: Vector2, w: float, h: float, frac: float, col: Color) -> void:
	hud.draw_rect(Rect2(p, Vector2(w, h)), Color(0, 0, 0, 0.55), true)
	hud.draw_rect(Rect2(p + Vector2(2, 2), Vector2(maxf(0.0, (w - 4.0) * clampf(frac, 0.0, 1.0)), h - 4.0)), col, true)


func _icon(kind: String, c: Vector2, s: float, col: Color) -> void:
	match kind:
		"food":
			var pts = PackedVector2Array()
			for i in 18:
				var a: float = float(i) / 18.0 * TAU
				pts.append(c + Vector2(cos(a) * s * 0.75, sin(a) * s * 0.45))
			hud.draw_colored_polygon(pts, col)
			for k in 3:
				hud.draw_line(c + Vector2(-s * 0.3 + k * s * 0.3, -s * 0.3), c + Vector2(-s * 0.15 + k * s * 0.3, s * 0.2), Color(0, 0, 0, 0.35), 2.0)
		"water":
			hud.draw_circle(c + Vector2(0, s * 0.2), s * 0.45, col)
			hud.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -s * 0.75), c + Vector2(-s * 0.43, s * 0.1), c + Vector2(s * 0.43, s * 0.1)]), col)
		"feed":
			for k in 6:
				hud.draw_line(c + Vector2(-s * 0.5 + k * s * 0.2, s * 0.5), c + Vector2(-s * 0.6 + k * s * 0.24, -s * 0.5), col, 3.0)
			hud.draw_line(c + Vector2(-s * 0.6, 0), c + Vector2(s * 0.6, 0), Color(0.45, 0.3, 0.15), 4.0)
		"ammo":
			hud.draw_rect(Rect2(c.x - s * 0.22, c.y - s * 0.15, s * 0.44, s * 0.7), col, true)
			hud.draw_circle(c + Vector2(0, -s * 0.15), s * 0.22, col)
		"coin":
			hud.draw_circle(c, s * 0.55, col)
			hud.draw_arc(c, s * 0.34, 0.0, TAU, 20, Color(0.5, 0.35, 0.1), 2.5)
		"people":
			hud.draw_circle(c + Vector2(0, -s * 0.35), s * 0.24, col)
			hud.draw_circle(c + Vector2(0, s * 0.3), s * 0.45, col)


func _draw_hud() -> void:
	if G == null:
		return
	var sz: Vector2 = vsize()
	if G.st == "load":
		hud.draw_rect(Rect2(Vector2.ZERO, sz), Color(0.03, 0.03, 0.04, 1.0), true)
		_tc("WANDERING CARAVAN", Vector2(sz.x * 0.5, sz.y * 0.38), 84, AMBER)
		_tc(loading_text, Vector2(sz.x * 0.5, sz.y * 0.52), 34, CREAM)
		hud.draw_rect(Rect2(sz.x * 0.3, sz.y * 0.6, sz.x * 0.4, 12.0), Color(1, 1, 1, 0.12), true)
		hud.draw_rect(Rect2(sz.x * 0.3, sz.y * 0.6, sz.x * 0.4 * loading_p, 12.0), AMBER, true)
		return
	if G.show_hud():
		_draw_status(sz)
		_draw_journey(sz)
		_draw_markers(sz)
		if G.controls_on():
			_draw_controls(sz)
	# barks
	var by: float = sz.y - 60.0
	for i in range(barks.size() - 1, -1, -1):
		var b: Dictionary = barks[i]
		var a: float = clampf(b["t"], 0.0, 1.0)
		var line: String = b["who"] + ":  " + b["text"]
		var f: Font = ThemeDB.fallback_font
		var w: float = f.get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, 30).x
		var cx: float = sz.x * 0.5
		hud.draw_style_box(sb_chip, Rect2(cx - w * 0.5 - 24.0, by - 38.0, w + 48.0, 54.0))
		_t(b["who"] + ":", Vector2(cx - w * 0.5, by), 30, Color(b["col"].r, b["col"].g, b["col"].b, a))
		var wn: float = f.get_string_size(b["who"] + ":  ", HORIZONTAL_ALIGNMENT_LEFT, -1, 30).x
		_t(b["text"], Vector2(cx - w * 0.5 + wn, by), 30, Color(1, 1, 1, a))
		by -= 66.0
	# banner
	if banner_t > 0.0:
		var ba: float = clampf(banner_t, 0.0, 0.6) / 0.6
		_tc(banner_text, Vector2(sz.x * 0.5, 200.0), 72, Color(1.0, 0.86, 0.5, ba))
		if banner_sub != "":
			_tc(banner_sub, Vector2(sz.x * 0.5, 262.0), 34, Color(1, 1, 1, ba))
	for p in pops:
		_tc(p["text"], p["pos"], 40, Color(p["col"].r, p["col"].g, p["col"].b, clampf(p["t"] * 2.0, 0.0, 1.0)))
	if G.show_hud():
		_vignette(sz)
	if red > 0.0:
		hud.draw_rect(Rect2(Vector2.ZERO, sz), Color(0.7, 0.0, 0.0, red * 0.35), true)
	if title_a > 0.0:
		_tc(title_big, Vector2(sz.x * 0.5, sz.y * 0.42), 110, Color(1.0, 0.86, 0.5, title_a))
		_tc(title_sub, Vector2(sz.x * 0.5, sz.y * 0.56), 36, Color(1, 1, 1, title_a))
	if fade > 0.0:
		hud.draw_rect(Rect2(Vector2.ZERO, sz), Color(0, 0, 0, fade), true)


func _vignette(sz: Vector2) -> void:
	for i in 4:
		var al: float = 0.11 - float(i) * 0.027
		var t: float = 36.0 * float(i + 1)
		var c: Color = Color(0, 0, 0, al)
		hud.draw_rect(Rect2(0, 0, sz.x, t), c, true)
		hud.draw_rect(Rect2(0, sz.y - t, sz.x, t), c, true)
		hud.draw_rect(Rect2(0, 0, t, sz.y), c, true)
		hud.draw_rect(Rect2(sz.x - t, 0, t, sz.y), c, true)


func _draw_status(sz: Vector2) -> void:
	var p: Vector2 = Vector2(36, 30)
	hud.draw_style_box(sb_panel, Rect2(p, Vector2(560, 222)))
	var chips: Array = [["food", G.food, Color(0.9, 0.7, 0.4)], ["water", G.water, Color(0.4, 0.7, 1.0)], ["feed", G.feed, Color(0.85, 0.8, 0.4)], ["ammo", G.ammo, Color(0.85, 0.85, 0.8)], ["coin", G.coin, Color(1.0, 0.82, 0.3)]]
	for i in 5:
		var cx: float = p.x + 44.0 + float(i) * 106.0
		var v: float = chips[i][1]
		var col: Color = chips[i][2]
		_icon(chips[i][0], Vector2(cx, p.y + 44.0), 24.0, col)
		var warn: bool = v < 8.0 and i < 4
		_t(str(int(v)), Vector2(cx + 22.0, p.y + 56.0), 32, Color(1, 0.45, 0.35) if warn else CREAM)
	_t("WAGON", Vector2(p.x + 24, p.y + 108), 22, CREAM)
	_bar(Vector2(p.x + 150, p.y + 90), 380, 20, G.wagon.hp / 100.0, Color(0.72, 0.5, 0.28))
	_t("HORSES", Vector2(p.x + 24, p.y + 146), 22, CREAM)
	_bar(Vector2(p.x + 150, p.y + 128), 380, 20, G.wagon.stamina / 100.0, Color(0.5, 0.78, 0.4))
	_t("MORALE", Vector2(p.x + 24, p.y + 184), 22, CREAM)
	_bar(Vector2(p.x + 150, p.y + 166), 380, 20, G.morale / 100.0, Color(0.45, 0.65, 0.95))
	_icon("people", Vector2(p.x + 44, p.y + 210), 14.0, CREAM)
	_t("%d" % G.people + ("   wounded %d" % G.wounded if G.wounded > 0 else ""), Vector2(p.x + 64, p.y + 218), 22, CREAM)
	var cy: float = p.y + 252.0
	for id in G.crew:
		var cd: Dictionary = G.CREW[id]
		hud.draw_circle(Vector2(p.x + 22, cy - 8), 8.0, cd["col"])
		_t(cd["name"] + "  ·  " + cd["role"], Vector2(p.x + 40, cy), 22, CREAM)
		cy += 30.0
	# clock + pause
	var hr: int = int(floor(G.hour)) % 24
	var mn: int = int((G.hour - floor(G.hour)) * 60.0)
	_t("%02d:%02d" % [hr, mn], Vector2(sz.x - 250, 82), 34, CREAM)
	_t("Trip %d" % G.trip, Vector2(sz.x - 250, 120), 24, CREAM)
	hud.draw_circle(Vector2(sz.x - 70, 70), 38.0, Color(0.05, 0.06, 0.08, 0.6))
	hud.draw_arc(Vector2(sz.x - 70, 70), 38.0, 0.0, TAU, 32, Color(0.86, 0.62, 0.3, 0.7), 2.0)
	hud.draw_rect(Rect2(sz.x - 82, 56, 8, 28), CREAM, true)
	hud.draw_rect(Rect2(sz.x - 66, 56, 8, 28), CREAM, true)


func _draw_journey(sz: Vector2) -> void:
	var w: float = 640.0
	var x0: float = sz.x * 0.5 - w * 0.5 + 60.0
	var y: float = 52.0
	var total: float = 3250.0
	hud.draw_line(Vector2(x0, y), Vector2(x0 + w, y), Color(1, 1, 1, 0.25), 6.0)
	var fr: float = clampf(G.dist / total, 0.0, 1.0)
	hud.draw_line(Vector2(x0, y), Vector2(x0 + w * fr, y), AMBER, 6.0)
	var marks: Array = [[0.0, G.start_name], [1400.0, G.mid_name], [2480.0, "Camp"], [3250.0, G.dest]]
	for m in marks:
		var mx: float = x0 + w * float(m[0]) / total
		hud.draw_circle(Vector2(mx, y), 10.0, Color(0.05, 0.06, 0.08, 0.9))
		hud.draw_arc(Vector2(mx, y), 10.0, 0.0, TAU, 16, AMBER, 2.5)
		_tc(m[1], Vector2(mx, y + 30.0), 20, Color(1, 1, 1, 0.8))
	var wx: float = x0 + w * fr
	hud.draw_colored_polygon(PackedVector2Array([Vector2(wx, y - 4), Vector2(wx - 11, y - 26), Vector2(wx + 11, y - 26)]), CREAM)
	_tc("%d m to %s" % [int(maxf(0.0, total - G.dist)), G.dest], Vector2(x0 + w * 0.5, y - 32.0), 24, CREAM)


func _draw_markers(sz: Vector2) -> void:
	if not G.combat and not G.show_markers():
		return
	var cam: Camera3D = G.cam
	for m in G.markers():
		var p3: Vector3 = m["pos"] + Vector3(0, 2.6, 0)
		var col: Color = m["col"]
		var onscreen: bool = not cam.is_position_behind(p3)
		var sp: Vector2 = cam.unproject_position(p3) if onscreen else Vector2(-999, -999)
		if onscreen and sp.x > 40.0 and sp.x < sz.x - 40.0 and sp.y > 40.0 and sp.y < sz.y - 40.0:
			hud.draw_arc(sp, 26.0, 0.0, TAU, 24, col, 3.0)
			hud.draw_colored_polygon(PackedVector2Array([sp + Vector2(0, 40), sp + Vector2(-12, 56), sp + Vector2(12, 56)]), col)
			for i in int(m["max"]):
				var pc: Color = col if float(i) < m["hp"] else Color(0, 0, 0, 0.5)
				hud.draw_circle(sp + Vector2((float(i) - (m["max"] - 1.0) * 0.5) * 16.0, -40.0), 5.0, pc)
			_tc("%dm" % int(m["d"]), sp + Vector2(0, 72), 22, Color(1, 1, 1, 0.85))
		else:
			var c: Vector2 = sz * 0.5
			var dir: Vector2 = Vector2(0, 1)
			if onscreen:
				dir = (sp - c).normalized()
			else:
				var loc: Vector3 = cam.global_transform.affine_inverse() * p3
				dir = Vector2(loc.x, 0.5 if loc.z > 0.0 else -loc.y)
				if dir.length() < 0.01:
					dir = Vector2(0, 1)
				dir = dir.normalized()
			var e: Vector2 = c + dir * minf(sz.x * 0.46 / maxf(absf(dir.x), 0.01), sz.y * 0.42 / maxf(absf(dir.y), 0.01))
			e.x = clampf(e.x, 60.0, sz.x - 60.0)
			e.y = clampf(e.y, 100.0, sz.y - 100.0)
			var nrm: Vector2 = Vector2(-dir.y, dir.x)
			hud.draw_colored_polygon(PackedVector2Array([e + dir * 26.0, e - dir * 12.0 + nrm * 20.0, e - dir * 12.0 - nrm * 20.0]), col)


func _draw_controls(sz: Vector2) -> void:
	var base: Vector2 = stick_origin if stick_id != -1 else Vector2(230, sz.y - 230.0)
	var a: float = 0.55 if stick_id != -1 else 0.22
	hud.draw_circle(base, 118.0, Color(0.05, 0.06, 0.08, a * 0.7))
	hud.draw_arc(base, 118.0, 0.0, TAU, 40, Color(1, 0.85, 0.55, a), 3.0)
	hud.draw_circle(base + stick * 100.0, 50.0, Color(0.96, 0.72, 0.34, a + 0.2))
	if stick_id == -1:
		_tc("DRIVE", base + Vector2(0, 170), 22, Color(1, 1, 1, 0.5))
	var wc: Vector2 = whip_c(sz)
	var wa: float = 0.9 if whip_down else 0.5
	hud.draw_circle(wc, 100.0, Color(0.05, 0.06, 0.08, wa * 0.7))
	hud.draw_arc(wc, 100.0, -PI * 0.5, -PI * 0.5 + TAU * (G.wagon.stamina / 100.0), 40, Color(0.5, 0.85, 0.4, 0.9), 8.0)
	_tc("WHIP", wc, 36, Color(1, 0.9, 0.7, 0.95))
	if G.ctx_label != "":
		var xc: Vector2 = ctx_c(sz)
		hud.draw_circle(xc, 80.0, Color(0.25, 0.08, 0.05, 0.75))
		hud.draw_arc(xc, 80.0, 0.0, TAU, 32, Color(1, 0.6, 0.4, 0.9), 4.0)
		_tc(G.ctx_label, xc, 24, Color(1, 0.92, 0.8, 1.0))
	var bc: Vector2 = brake_c(sz)
	hud.draw_circle(bc, 78.0, Color(0.05, 0.06, 0.08, (0.9 if brake_down else 0.5) * 0.7))
	hud.draw_arc(bc, 78.0, 0.0, TAU, 32, Color(1, 0.5, 0.4, 0.7), 3.0)
	_tc("BRAKE", bc, 28, Color(1, 0.9, 0.8, 0.9))
	if G.combat:
		var ac: Vector2 = Vector2(sz.x * 0.5, sz.y - 210.0)
		hud.draw_circle(ac, 46.0, Color(0.05, 0.06, 0.08, 0.6))
		var rf: float = 1.0 - clampf(G.reload / G.reload_time, 0.0, 1.0)
		hud.draw_arc(ac, 46.0, -PI * 0.5, -PI * 0.5 + TAU * rf, 28, AMBER if G.ammo > 0 else Color(1, 0.3, 0.3), 6.0)
		_tc(str(G.ammo), ac, 40, CREAM)
		_tc("TAP ENEMIES TO SHOOT", Vector2(sz.x * 0.5, sz.y - 285.0), 26, Color(1, 0.85, 0.6, 0.85))
