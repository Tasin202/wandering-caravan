extends Node3D
# The caravan wagon with two draft horses. Kinematic driving on the procedural terrain (no physics engine).

const M = preload("res://meshes.gd")
const Mats = preload("res://mats.gd")
const Actors = preload("res://actors.gd")

signal crashed(severity)

var world
var speed: float = 0.0
var yaw: float = 0.0
var hp: float = 100.0
var stamina: float = 100.0
var enabled: bool = false
var steer_in: float = 0.0
var throttle_in: float = 0.0
var whip: bool = false
var brake: bool = false
var cap: float = 1.0
var gust: float = 0.0
var ford_limit: float = 6.0
var in_water: bool = false
var whipping: bool = false
var assist: bool = true
var pitch_s: float = 0.0
var roll_s: float = 0.0
var phase: float = 0.0
var crash_cd: float = 0.0
var water_dmg: float = 0.0

var wheels: Array = []
var horses: Array = []
var body_node: Node3D
var lantern: OmniLight3D
var dust: CPUParticles3D
var splash: CPUParticles3D


func _ready() -> void:
	body_node = Node3D.new()
	add_child(body_node)
	_build()


func forward() -> Vector3:
	return Vector3(-sin(yaw), 0, -cos(yaw))


func right() -> Vector3:
	return Vector3(cos(yaw), 0, -sin(yaw))


func place(p: Vector3, y: float) -> void:
	position = p
	yaw = y
	rotation = Vector3(0, y, 0)
	speed = 0.0


func muzzle() -> Vector3:
	return global_position + Vector3(0, 2.3, 0) + forward() * -1.0


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var bm = BoxMesh.new()
	bm.size = size
	var mi = MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


func _build() -> void:
	var wood: ShaderMaterial = Mats.variant("planks", {"c1": Color(0.40, 0.27, 0.15), "c2": Color(0.26, 0.17, 0.10), "scale": 5.0})
	var dark_wood: ShaderMaterial = Mats.variant("planks", {"c1": Color(0.22, 0.14, 0.08), "c2": Color(0.14, 0.09, 0.05), "scale": 6.0})
	var iron: StandardMaterial3D = Mats.std(Color(0.12, 0.12, 0.13), 0.5, 0.8)
	var b: Node3D = body_node
	_box(b, Vector3(2.1, 0.14, 4.1), Vector3(0, 1.15, 0.25), dark_wood)
	_box(b, Vector3(0.09, 0.85, 4.1), Vector3(-1.02, 1.6, 0.25), wood)
	_box(b, Vector3(0.09, 0.85, 4.1), Vector3(1.02, 1.6, 0.25), wood)
	_box(b, Vector3(2.1, 0.7, 0.09), Vector3(0, 1.55, -1.78), wood)
	_box(b, Vector3(2.1, 0.5, 0.09), Vector3(0, 1.45, 2.3), wood)
	_box(b, Vector3(1.7, 0.12, 0.55), Vector3(0, 1.82, -1.45), dark_wood)
	_box(b, Vector3(1.7, 0.55, 0.08), Vector3(0, 2.1, -1.15), dark_wood)
	# canvas cover
	var canvas = MeshInstance3D.new()
	canvas.mesh = M.arch(1.08, 3.1, 14, Mats.get_mat("cloth"))
	canvas.position = Vector3(0, 1.95, 0.95)
	b.add_child(canvas)
	for z in [-0.4, 0.5, 1.4, 2.3]:
		var rib = MeshInstance3D.new()
		var tm = TorusMesh.new()
		tm.inner_radius = 1.07
		tm.outer_radius = 1.13
		rib.mesh = tm
		rib.material_override = dark_wood
		rib.rotation = Vector3(PI * 0.5, 0, 0)
		rib.position = Vector3(0, 1.95, z)
		rib.scale = Vector3(1.0, 1.0, 1.0)
		b.add_child(rib)
	# cargo
	for i in 3:
		var cm = CylinderMesh.new()
		cm.top_radius = 0.26
		cm.bottom_radius = 0.26
		cm.height = 0.72
		var barrel = MeshInstance3D.new()
		barrel.mesh = cm
		barrel.material_override = wood
		barrel.position = Vector3(-0.55 + i * 0.55, 1.58, 2.0)
		b.add_child(barrel)
	_box(b, Vector3(0.7, 0.5, 0.6), Vector3(-0.5, 1.5, 1.2), dark_wood, Vector3(0, 0.2, 0))
	_box(b, Vector3(0.6, 0.45, 0.6), Vector3(0.55, 1.47, 1.3), wood, Vector3(0, -0.3, 0))
	var sack = Node3D.new()
	sack.position = Vector3(0, 1.3, 0.3)
	b.add_child(sack)
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	M.ellipsoid(st, Vector3(0, 0.2, 0), Vector3(0.42, 0.3, 0.3), 9, 6, 0.1, 2.0, 21)
	M.ellipsoid(st, Vector3(0.5, 0.2, 0.3), Vector3(0.36, 0.28, 0.3), 9, 6, 0.1, 2.0, 22)
	var sm = MeshInstance3D.new()
	sm.mesh = M.finish(st, Mats.variant("cloth", {"c1": Color(0.62, 0.5, 0.33), "c2": Color(0.4, 0.31, 0.2)}))
	sack.add_child(sm)
	# axles + wheels
	var specs: Array = [[-1.1, 0.62], [1.6, 0.86]]
	for s in specs:
		var z: float = s[0]
		var r: float = s[1]
		_box(b, Vector3(2.5, 0.12, 0.12), Vector3(0, r, z), iron)
		for sx in [-1.0, 1.0]:
			var w = Node3D.new()
			w.position = Vector3(sx * 1.2, r, z)
			add_child(w)
			var rim = MeshInstance3D.new()
			var tm2 = TorusMesh.new()
			tm2.inner_radius = r - 0.07
			tm2.outer_radius = r
			tm2.rings = 24
			tm2.ring_segments = 8
			rim.mesh = tm2
			rim.material_override = dark_wood
			rim.rotation = Vector3(0, 0, PI * 0.5)
			w.add_child(rim)
			for k in 6:
				_box(w, Vector3(0.06, r * 2.0 - 0.1, 0.05), Vector3.ZERO, wood, Vector3(k * PI / 6.0, 0, 0))
			var hub = MeshInstance3D.new()
			var hm = CylinderMesh.new()
			hm.top_radius = 0.12
			hm.bottom_radius = 0.12
			hm.height = 0.32
			hub.mesh = hm
			hub.material_override = iron
			hub.rotation = Vector3(0, 0, PI * 0.5)
			w.add_child(hub)
			wheels.append({"node": w, "r": r})
	# pole and yoke
	_box(b, Vector3(0.14, 0.14, 3.3), Vector3(0, 0.95, -3.3), dark_wood)
	_box(b, Vector3(2.0, 0.12, 0.12), Vector3(0, 1.5, -4.9), dark_wood)
	# lantern
	lantern = OmniLight3D.new()
	lantern.position = Vector3(1.0, 2.1, 2.45)
	lantern.omni_range = 14.0
	lantern.light_color = Color(1.0, 0.72, 0.4)
	lantern.light_energy = 0.0
	b.add_child(lantern)
	var lm = MeshInstance3D.new()
	var lsm = SphereMesh.new()
	lsm.radius = 0.1
	lsm.height = 0.22
	lm.mesh = lsm
	lm.material_override = Mats.glow(Color(1.0, 0.7, 0.35), 3.0)
	lm.position = lantern.position
	b.add_child(lm)
	# driver
	var drv: Dictionary = Actors.human(Color(0.32, 0.28, 0.2), true, false, true)
	drv.node.position = Vector3(0.38, 1.62, -1.45)
	b.add_child(drv.node)
	# horses
	for sx in [-0.78, 0.78]:
		var h: Dictionary = Actors.horse(Color(0.34, 0.2, 0.11) if sx < 0 else Color(0.14, 0.1, 0.08), 1.0)
		h.node.position = Vector3(sx, 0, -6.0)
		add_child(h.node)
		horses.append(h)
	dust = Mats.particles("dust")
	dust.position = Vector3(0, 0.3, 2.2)
	add_child(dust)
	splash = Mats.particles("splash")
	splash.position = Vector3(0, 0.2, -1.5)
	add_child(splash)


func tick(delta: float) -> void:
	if world == null:
		return
	crash_cd = maxf(0.0, crash_cd - delta)
	var cx: float = world.road_x(position.z)
	var dr: float = absf(position.x - cx)
	var wd: float = world.depth_at(position.x, position.z)
	in_water = wd > 0.05
	whipping = whip and enabled and stamina > 3.0
	var tgt: float = 0.0
	if enabled:
		tgt = clampf(throttle_in, 0.0, 1.0) * 9.5
		if whipping:
			tgt = 14.5
	if brake:
		tgt = 0.0
	if dr > 9.0:
		tgt *= 0.6
	if in_water:
		tgt = minf(tgt, 11.0)
	if wd > 1.3:
		tgt = minf(tgt, 1.2)
	tgt *= cap
	tgt *= clampf(1.0 - sin(pitch_s) * 1.2, 0.55, 1.2)
	if stamina <= 3.0:
		tgt = minf(tgt, 6.0)
	if hp < 25.0:
		tgt *= 0.8
	if whipping:
		stamina = maxf(0.0, stamina - 14.0 * delta)
	else:
		stamina = minf(100.0, stamina + (7.0 if speed < 6.0 else 2.5) * delta)
	var acc: float = 3.2 if tgt > speed else (14.0 if brake else 5.5)
	speed = move_toward(speed, tgt, acc * delta)
	# steering with horse auto-follow on the road
	var sp_f: float = clampf(speed / 3.5, 0.0, 1.0)
	if absf(steer_in) < 0.12 and dr < 16.0 and assist and enabled:
		var target_yaw: float = atan2(world.road_dx(position.z), 1.0) + clampf((position.x - cx) * 0.035, -0.45, 0.45)
		var diff: float = wrapf(target_yaw - yaw, -PI, PI)
		yaw += clampf(diff, -1.0, 1.0) * 1.7 * delta * sp_f
	else:
		yaw -= steer_in * 0.7 * delta * sp_f
	yaw += gust * delta * sp_f
	var fwd: Vector3 = forward()
	position += fwd * speed * delta
	if in_water:
		position.x += 1.5 * delta
		if speed > ford_limit:
			water_dmg += delta
			hp = maxf(0.0, hp - 9.0 * delta)
		if wd > 1.3:
			hp = maxf(0.0, hp - 5.0 * delta)
	var push: Vector3 = world.collide(position, 1.5)
	if push.length() > 0.001:
		position += push
		if speed > 2.5 and crash_cd <= 0.0:
			crash_cd = 0.7
			crashed.emit(speed)
			hp = maxf(0.0, hp - speed * 0.55)
		speed *= 0.4
	var rt: Vector3 = right()
	var hc: float = world.height(position.x, position.z)
	var hf: float = world.height(position.x + fwd.x * 2.4, position.z + fwd.z * 2.4)
	var hb: float = world.height(position.x - fwd.x * 2.4, position.z - fwd.z * 2.4)
	var hr: float = world.height(position.x + rt.x * 1.1, position.z + rt.z * 1.1)
	var hl: float = world.height(position.x - rt.x * 1.1, position.z - rt.z * 1.1)
	position.y = lerpf(position.y, (hc * 2.0 + hf + hb) * 0.25, 1.0 - exp(-12.0 * delta))
	pitch_s = lerp_angle(pitch_s, atan2(hf - hb, 4.8), 1.0 - exp(-6.0 * delta))
	roll_s = lerp_angle(roll_s, atan2(hr - hl, 2.2), 1.0 - exp(-6.0 * delta))
	rotation = Vector3(pitch_s, yaw, roll_s)
	# animation
	for w in wheels:
		w.node.rotation.x -= speed * delta / w.r
	phase += delta * (1.5 + speed * 0.78)
	var amp: float = clampf(speed / 7.0, 0.08, 1.0) * 0.8
	for i in horses.size():
		Actors.gait(horses[i], phase + i * 0.6, amp)
		horses[i].node.position.y = 0.0
	body_node.position.y = sin(phase * 2.3) * 0.02 * clampf(speed / 8.0, 0.0, 1.0)
	body_node.rotation.z = sin(phase * 1.1) * 0.012 * clampf(speed / 8.0, 0.0, 1.0)
	dust.emitting = speed > 3.5 and not in_water
	splash.emitting = in_water and speed > 0.8
