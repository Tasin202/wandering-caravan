extends Node3D
# The caravan wagon with two draft horses. Kinematic driving on the procedural terrain (no physics engine).

const M = preload("res://meshes.gd")
const Mats = preload("res://mats.gd")
const Actors = preload("res://actors.gd")

signal crashed(severity)

var world
var speed: float = 0.0
var yaw: float = 0.0
var hp: float = 100.0
var stamina: float = 100.0
var enabled: bool = false
var steer_in: float = 0.0
var throttle_in: float = 0.0
var whip: bool = false
var brake: bool = false
var cap: float = 1.0
var gust: float = 0.0
var ford_limit: float = 6.0
var in_water: bool = false
var whipping: bool = false
var assist: bool = true
var pitch_s: float = 0.0
var roll_s: float = 0.0
var phase: float = 0.0
var crash_cd: float = 0.0
var water_dmg: float = 0.0
var armor: float = 1.0
var speed_mult: float = 1.0
var drain_mult: float = 1.0
var regen_mult: float = 1.0

var wheels: Array = []
var horses: Array = []
var body_node: Node3D
var lantern: OmniLight3D
var dust: CPUParticles3D
var splash: CPUParticles3D


func _ready() -> void:
	body_node = Node3D.new()
	add_child(body_node)
	_build()


func forward() -> Vector3:
	return Vector3(-sin(yaw), 0, -cos(yaw))


func right() -> Vector3:
	return Vector3(cos(yaw), 0, -sin(yaw))


func place(p: Vector3, y: float) -> void:
	position = p
	yaw = y
	rotation = Vector3(0, y, 0)
	speed = 0.0


func muzzle() -> Vector3:
	return global_position + Vector3(0, 2.3, 0) + forward() * -1.0


func _t(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis.IDENTITY, Vector3(x, y, z))


func _wheel_mesh(r: float) -> ArrayMesh:
	var st = M.new_st()
	var rim: Color = Color(0.20, 0.13, 0.08)
	var chord: float = 2.0 * r * sin(PI / 10.0) * 1.05
	for k in 10:
		var a: float = float(k) / 10.0 * TAU
		var c: Vector3 = Vector3(0, cos(a) * r, sin(a) * r)
		M.box(st, Vector3(0.14, 0.1, chord), Transform3D(Basis(Vector3.RIGHT, a), c), rim)
	for k in 4:
		M.box(st, Vector3(0.06, r * 2.0 - 0.1, 0.06), Transform3D(Basis(Vector3.RIGHT, float(k) * PI / 4.0), Vector3.ZERO), Color(0.36, 0.25, 0.14))
	M.box(st, Vector3(0.22, 0.22, 0.22), Transform3D.IDENTITY, Color(0.1, 0.1, 0.11))
	return M.finish(st, Mats.vcol())


func _build() -> void:
	var wood: Color = Color(0.38, 0.26, 0.15)
	var dark: Color = Color(0.22, 0.14, 0.08)
	var iron: Color = Color(0.12, 0.12, 0.13)
	var canvas: Color = Color(0.86, 0.80, 0.66)
	var st = M.new_st()
	M.box(st, Vector3(2.1, 0.14, 4.1), _t(0, 1.15, 0.25), dark)
	M.box(st, Vector3(0.09, 0.85, 4.1), _t(-1.02, 1.6, 0.25), wood)
	M.box(st, Vector3(0.09, 0.85, 4.1), _t(1.02, 1.6, 0.25), wood)
	M.box(st, Vector3(2.1, 0.7, 0.09), _t(0, 1.55, -1.78), wood)
	M.box(st, Vector3(2.1, 0.5, 0.09), _t(0, 1.45, 2.3), wood)
	M.box(st, Vector3(1.7, 0.12, 0.55), _t(0, 1.82, -1.45), dark)
	M.box(st, Vector3(1.7, 0.55, 0.08), _t(0, 2.1, -1.15), dark)
	M.arch_into(st, _t(0, 1.95, 0.95), 1.08, 3.1, 8, canvas)
	for i in 3:
		var bp: Array = [Vector2(0.0, 0.36), Vector2(0.24, 0.34), Vector2(0.28, 0.0), Vector2(0.24, -0.34), Vector2(0.0, -0.36)]
		M.lathe(st, bp, 8, _t(-0.55 + float(i) * 0.55, 1.58, 2.0), 0.0, 1.0, 1, wood)
	M.box(st, Vector3(0.7, 0.5, 0.6), Transform3D(Basis(Vector3.UP, 0.2), Vector3(-0.5, 1.5, 1.2)), dark)
	M.box(st, Vector3(0.6, 0.45, 0.6), Transform3D(Basis(Vector3.UP, -0.3), Vector3(0.55, 1.47, 1.3)), wood)
	M.ellipsoid(st, Vector3(0, 1.5, 0.3), Vector3(0.42, 0.3, 0.3), 7, 4, 0.0, 1.0, 21, Color(0.62, 0.5, 0.33))
	M.ellipsoid(st, Vector3(0.5, 1.5, 0.6), Vector3(0.36, 0.28, 0.3), 7, 4, 0.0, 1.0, 22, Color(0.55, 0.45, 0.3))
	M.box(st, Vector3(2.5, 0.12, 0.12), _t(0, 0.62, -1.1), iron)
	M.box(st, Vector3(2.5, 0.12, 0.12), _t(0, 0.86, 1.6), iron)
	M.box(st, Vector3(0.14, 0.14, 3.3), _t(0, 0.95, -3.3), dark)
	M.box(st, Vector3(2.0, 0.12, 0.12), _t(0, 1.5, -4.9), dark)
	var bm = MeshInstance3D.new()
	bm.mesh = M.finish(st, Mats.vcol2())
	body_node.add_child(bm)
	# wheels
	var fm: ArrayMesh = _wheel_mesh(0.62)
	var rm: ArrayMesh = _wheel_mesh(0.86)
	var specs: Array = [[-1.1, 0.62, fm], [1.6, 0.86, rm]]
	for s in specs:
		for sx in [-1.0, 1.0]:
			var w = Node3D.new()
			w.position = Vector3(sx * 1.2, s[1], s[0])
			add_child(w)
			var wi = MeshInstance3D.new()
			wi.mesh = s[2]
			w.add_child(wi)
			wheels.append({"node": w, "r": s[1]})
	# lantern
	lantern = OmniLight3D.new()
	lantern.position = Vector3(1.0, 2.1, 2.45)
	lantern.omni_range = 12.0
	lantern.light_color = Color(1.0, 0.72, 0.4)
	lantern.light_energy = 0.0
	body_node.add_child(lantern)
	var lm = MeshInstance3D.new()
	var lsm = SphereMesh.new()
	lsm.radius = 0.1
	lsm.height = 0.22
	lsm.radial_segments = 6
	lsm.rings = 3
	lm.mesh = lsm
	lm.material_override = Mats.glow(Color(1.0, 0.7, 0.35), 3.0)
	lm.position = lantern.position
	body_node.add_child(lm)
	# driver and horses
	var drv: Dictionary = Actors.human(Color(0.32, 0.28, 0.2), true, false, true)
	drv["node"].position = Vector3(0.38, 1.62, -1.45)
	body_node.add_child(drv["node"])
	for sx in [-0.78, 0.78]:
		var h: Dictionary = Actors.horse(Color(0.34, 0.2, 0.11) if sx < 0 else Color(0.14, 0.1, 0.08), 1.0)
		h["node"].position = Vector3(sx, 0, -6.0)
		add_child(h["node"])
		horses.append(h)
	var bl = MeshInstance3D.new()
	bl.mesh = M.blob()
	bl.scale = Vector3(1.9, 1.0, 3.4)
	bl.position = Vector3(0, 0.1, 0.4)
	bl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(bl)
	dust = Mats.particles("dust")
	dust.position = Vector3(0, 0.3, 2.2)
	add_child(dust)
	splash = Mats.particles("splash")
	splash.position = Vector3(0, 0.2, -1.5)
	add_child(splash)


func tick(delta: float) -> void:
	if world == null:
		return
	crash_cd = maxf(0.0, crash_cd - delta)
	var cx: float = world.road_x(position.z)
	var dr: float = absf(position.x - cx)
	var wd: float = world.depth_at(position.x, position.z)
	in_water = wd > 0.05
	whipping = whip and enabled and stamina > 3.0
	var tgt: float = 0.0
	if enabled:
		tgt = clampf(throttle_in, 0.0, 1.0) * 9.5
		if whipping:
			tgt = 14.5
	if brake:
		tgt = 0.0
	if dr > 9.0:
		tgt *= 0.6
	if in_water:
		tgt = minf(tgt, 11.0)
	if wd > 1.3:
		tgt = minf(tgt, 1.2)
	tgt *= cap * speed_mult
	tgt *= clampf(1.0 - sin(pitch_s) * 1.2, 0.55, 1.2)
	if stamina <= 3.0:
		tgt = minf(tgt, 6.0)
	if hp < 25.0:
		tgt *= 0.8
	if whipping:
		stamina = maxf(0.0, stamina - 14.0 * drain_mult * delta)
	else:
		stamina = minf(100.0, stamina + (7.0 if speed < 6.0 else 2.5) * regen_mult * delta)
	var acc: float = 3.2 if tgt > speed else (14.0 if brake else 5.5)
	speed = move_toward(speed, tgt, acc * delta)
	var sp_f: float = clampf(speed / 3.5, 0.0, 1.0)
	if absf(steer_in) < 0.12 and dr < 16.0 and assist and enabled:
		var target_yaw: float = atan2(world.road_dx(position.z), 1.0) + clampf((position.x - cx) * 0.035, -0.45, 0.45)
		var diff: float = wrapf(target_yaw - yaw, -PI, PI)
		yaw += clampf(diff, -1.0, 1.0) * 1.7 * delta * sp_f
	else:
		yaw -= steer_in * 0.7 * delta * sp_f
	yaw += gust * delta * sp_f
	var fwd: Vector3 = forward()
	position += fwd * speed * delta
	if in_water:
		position.x += 1.5 * delta
		if speed > ford_limit:
			water_dmg += delta
			hp = maxf(0.0, hp - 9.0 * armor * delta)
		if wd > 1.3:
			hp = maxf(0.0, hp - 5.0 * armor * delta)
	var push: Vector3 = world.collide(position, 1.5)
	if push.length() > 0.001:
		position += push
		if speed > 2.5 and crash_cd <= 0.0:
			crash_cd = 0.7
			crashed.emit(speed)
			hp = maxf(0.0, hp - speed * 0.55 * armor)
		speed *= 0.4
	var rt: Vector3 = right()
	var hc: float = world.height(position.x, position.z)
	var hf: float = world.height(position.x + fwd.x * 2.4, position.z + fwd.z * 2.4)
	var hb: float = world.height(position.x - fwd.x * 2.4, position.z - fwd.z * 2.4)
	var hr: float = world.height(position.x + rt.x * 1.1, position.z + rt.z * 1.1)
	var hl: float = world.height(position.x - rt.x * 1.1, position.z - rt.z * 1.1)
	position.y = lerpf(position.y, (hc * 2.0 + hf + hb) * 0.25, 1.0 - exp(-12.0 * delta))
	pitch_s = lerp_angle(pitch_s, atan2(hf - hb, 4.8), 1.0 - exp(-6.0 * delta))
	roll_s = lerp_angle(roll_s, atan2(hr - hl, 2.2), 1.0 - exp(-6.0 * delta))
	rotation = Vector3(pitch_s, yaw, roll_s)
	for w in wheels:
		w["node"].rotation.x -= speed * delta / w["r"]
	phase += delta * (1.5 + speed * 0.78)
	var amp: float = clampf(speed / 7.0, 0.08, 1.0) * 0.8
	for i in horses.size():
		Actors.gait(horses[i], phase + float(i) * 0.6, amp)
	body_node.position.y = sin(phase * 2.3) * 0.02 * clampf(speed / 8.0, 0.0, 1.0)
	dust.emitting = speed > 5.0 and not in_water
	splash.emitting = in_water and speed > 0.8
