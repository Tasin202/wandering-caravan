extends RefCounted
# Overwritten by the GitHub Actions build with the real build number and repository.
const BUILD = 0
const REPO = ""
const NAME = "dev build"
