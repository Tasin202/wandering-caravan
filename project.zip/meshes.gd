extends RefCounted
# Procedural geometry with baked vertex colours. One surface = one draw call.


static func new_st() -> SurfaceTool:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	return st


static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, ca: Color, cb: Color, cc: Color) -> void:
	st.set_color(ca)
	st.add_vertex(a)
	st.set_color(cb)
	st.add_vertex(b)
	st.set_color(cc)
	st.add_vertex(c)


# profile: Array of Vector2(radius, y), ordered from top to bottom.
static func lathe(st: SurfaceTool, profile: Array, seg: int, xf: Transform3D, jit: float = 0.0, jf: float = 1.0, sd: int = 1, col: Color = Color(1, 1, 1), shade: float = 0.0) -> void:
	var noise = null
	if jit > 0.0:
		noise = FastNoiseLite.new()
		noise.seed = sd
		noise.frequency = jf
	var n: int = profile.size()
	var rows: Array = []
	var cols: Array = []
	for i in n:
		var p: Vector2 = profile[i]
		cols.append(col.darkened(shade * float(i) / float(maxi(1, n - 1))))
		var row: Array = []
		for j in seg:
			var a: float = float(j) / float(seg) * TAU
			var pos: Vector3 = Vector3(cos(a) * p.x, p.y, sin(a) * p.x)
			if jit > 0.0 and p.x > 0.001:
				var k: float = 1.0 + jit * noise.get_noise_3d(pos.x, pos.y, pos.z)
				pos.x *= k
				pos.z *= k
			row.append(xf * pos)
		rows.append(row)
	for i in range(n - 1):
		for j in range(seg):
			var j1: int = (j + 1) % seg
			var a0: Vector3 = rows[i][j]
			var a1: Vector3 = rows[i][j1]
			var b0: Vector3 = rows[i + 1][j]
			var b1: Vector3 = rows[i + 1][j1]
			_tri(st, a0, b0, a1, cols[i], cols[i + 1], cols[i])
			_tri(st, a1, b0, b1, cols[i], cols[i + 1], cols[i + 1])


static func ellipsoid(st: SurfaceTool, c: Vector3, r: Vector3, seg: int, rings: int, jit: float, jf: float, sd: int, col: Color, rot: Basis = Basis.IDENTITY, shade: float = 0.0) -> void:
	var prof: Array = []
	for i in rings + 1:
		var t: float = float(i) / float(rings) * PI
		prof.append(Vector2(sin(t), cos(t)))
	lathe(st, prof, seg, Transform3D(rot * Basis.from_scale(r), c), jit, jf, sd, col, shade)


# Tapered limb hanging downward from the origin.
static func limb(st: SurfaceTool, r0: float, r1: float, length: float, seg: int, xf: Transform3D, col: Color) -> void:
	var prof: Array = [
		Vector2(0.0, r0 * 0.6),
		Vector2(r0, 0.0),
		Vector2(r1, -length),
		Vector2(0.0, -length - r1 * 0.7)]
	lathe(st, prof, seg, xf, 0.0, 1.0, 1, col)


# Flat shaded box (own smoothing group, so edges stay sharp).
static func box(st: SurfaceTool, size: Vector3, xf: Transform3D, col: Color) -> void:
	var h: Vector3 = size * 0.5
	var faces: Array = [
		[Vector3.RIGHT, Vector3.UP, Vector3.BACK],
		[Vector3.LEFT, Vector3.BACK, Vector3.UP],
		[Vector3.UP, Vector3.BACK, Vector3.RIGHT],
		[Vector3.DOWN, Vector3.RIGHT, Vector3.BACK],
		[Vector3.BACK, Vector3.RIGHT, Vector3.UP],
		[Vector3.FORWARD, Vector3.UP, Vector3.RIGHT]]
	st.set_smooth_group(-1)
	for f in faces:
		var nn: Vector3 = f[0]
		var u: Vector3 = f[1]
		var v: Vector3 = f[2]
		var hu: float = absf(u.dot(h))
		var hv: float = absf(v.dot(h))
		var hn: float = absf(nn.dot(h))
		var c: Vector3 = nn * hn
		var p0: Vector3 = xf * (c - u * hu - v * hv)
		var p1: Vector3 = xf * (c + u * hu - v * hv)
		var p2: Vector3 = xf * (c + u * hu + v * hv)
		var p3: Vector3 = xf * (c - u * hu + v * hv)
		_tri(st, p0, p2, p1, col, col, col)
		_tri(st, p0, p3, p2, col, col, col)
	st.set_smooth_group(0)


# a, b, c, d counter-clockwise as seen from outside.
static func fquad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color) -> void:
	st.set_smooth_group(-1)
	_tri(st, a, c, b, col, col, col)
	_tri(st, a, d, c, col, col, col)
	st.set_smooth_group(0)


static func ftri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, col: Color) -> void:
	st.set_smooth_group(-1)
	_tri(st, a, c, b, col, col, col)
	st.set_smooth_group(0)


# Gabled roof, ridge along Z. Slopes use col, gables use gcol.
static func roof_into(st: SurfaceTool, xf: Transform3D, w: float, d: float, h: float, o: float, col: Color, gcol: Color) -> void:
	var rw: float = w * 0.5 + o
	var rd: float = d * 0.5 + o
	fquad(st, xf * Vector3(-rw, 0, rd), xf * Vector3(0, h, rd), xf * Vector3(0, h, -rd), xf * Vector3(-rw, 0, -rd), col)
	fquad(st, xf * Vector3(rw, 0, -rd), xf * Vector3(0, h, -rd), xf * Vector3(0, h, rd), xf * Vector3(rw, 0, rd), col)
	var gh: float = h * (w * 0.5) / rw
	var zf: float = d * 0.5
	ftri(st, xf * Vector3(-w * 0.5, 0, zf), xf * Vector3(w * 0.5, 0, zf), xf * Vector3(0, gh, zf), gcol)
	ftri(st, xf * Vector3(w * 0.5, 0, -zf), xf * Vector3(-w * 0.5, 0, -zf), xf * Vector3(0, gh, -zf), gcol)


# Canvas half-cylinder along Z.
static func arch_into(st: SurfaceTool, xf: Transform3D, radius: float, length: float, steps: int, col: Color) -> void:
	var z: float = length * 0.5
	for i in steps:
		var a0: float = PI * float(i) / float(steps)
		var a1: float = PI * float(i + 1) / float(steps)
		var p0: Vector3 = Vector3(cos(a0) * radius, sin(a0) * radius * 0.95, 0)
		var p1: Vector3 = Vector3(cos(a1) * radius, sin(a1) * radius * 0.95, 0)
		var a: Vector3 = xf * (p0 + Vector3(0, 0, z))
		var b: Vector3 = xf * (p0 + Vector3(0, 0, -z))
		var c: Vector3 = xf * (p1 + Vector3(0, 0, -z))
		var d: Vector3 = xf * (p1 + Vector3(0, 0, z))
		_tri(st, a, c, b, col, col, col)
		_tri(st, a, d, c, col, col, col)


static func finish(st: SurfaceTool, mat: Material, mesh: ArrayMesh = null) -> ArrayMesh:
	st.generate_normals()
	var m: ArrayMesh = st.commit(mesh)
	if mat != null:
		m.surface_set_material(m.get_surface_count() - 1, mat)
	return m
