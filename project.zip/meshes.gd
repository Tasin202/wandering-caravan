extends RefCounted
# Procedural geometry. Everything is built from surfaces of revolution, with noise displacement for organic shapes.


static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, ua: Vector2, ub: Vector2, uc: Vector2) -> void:
	st.set_uv(ua)
	st.add_vertex(a)
	st.set_uv(ub)
	st.add_vertex(b)
	st.set_uv(uc)
	st.add_vertex(c)


# profile: Array of Vector2(radius, y), ordered from top to bottom.
static func lathe(st: SurfaceTool, profile: Array, seg: int, xf: Transform3D, jit: float = 0.0, jf: float = 1.0, sd: int = 1, uvs: Vector2 = Vector2(1, 1)) -> void:
	var noise = FastNoiseLite.new()
	noise.seed = sd
	noise.frequency = jf
	var n: int = profile.size()
	var rows: Array = []
	for i in n:
		var p: Vector2 = profile[i]
		var row: Array = []
		for j in seg + 1:
			var a: float = float(j % seg) / float(seg) * TAU
			var pos: Vector3 = Vector3(cos(a) * p.x, p.y, sin(a) * p.x)
			if jit > 0.0 and p.x > 0.001:
				var k: float = 1.0 + jit * noise.get_noise_3d(pos.x, pos.y, pos.z)
				pos.x *= k
				pos.z *= k
			row.append(xf * pos)
		rows.append(row)
	for i in range(n - 1):
		for j in range(seg):
			var a0: Vector3 = rows[i][j]
			var a1: Vector3 = rows[i][j + 1]
			var b0: Vector3 = rows[i + 1][j]
			var b1: Vector3 = rows[i + 1][j + 1]
			var u0: float = float(j) / float(seg) * uvs.x
			var u1: float = float(j + 1) / float(seg) * uvs.x
			var v0: float = float(i) / float(n - 1) * uvs.y
			var v1: float = float(i + 1) / float(n - 1) * uvs.y
			_tri(st, a0, b0, a1, Vector2(u0, v0), Vector2(u0, v1), Vector2(u1, v0))
			_tri(st, a1, b0, b1, Vector2(u1, v0), Vector2(u0, v1), Vector2(u1, v1))


static func ellipsoid(st: SurfaceTool, c: Vector3, r: Vector3, seg: int = 10, rings: int = 7, jit: float = 0.0, jf: float = 1.0, sd: int = 1, rot: Basis = Basis.IDENTITY) -> void:
	var prof: Array = []
	for i in rings + 1:
		var t: float = float(i) / float(rings) * PI
		prof.append(Vector2(sin(t), cos(t)))
	lathe(st, prof, seg, Transform3D(rot * Basis.from_scale(r), c), jit, jf, sd)


# Tapered limb that hangs downward from the origin (pivot at the top).
static func limb(st: SurfaceTool, r0: float, r1: float, length: float, seg: int = 8, xf: Transform3D = Transform3D.IDENTITY) -> void:
	var prof: Array = [
		Vector2(0.0, r0 * 0.6),
		Vector2(r0, 0.0),
		Vector2((r0 + r1) * 0.51, -length * 0.5),
		Vector2(r1, -length),
		Vector2(r1 * 0.55, -length - r1 * 0.6),
		Vector2(0.0, -length - r1 * 0.75)]
	lathe(st, prof, seg, xf)


static func finish(st: SurfaceTool, mat: Material, mesh: ArrayMesh = null) -> ArrayMesh:
	st.generate_normals()
	var m: ArrayMesh = st.commit(mesh)
	if mat != null:
		m.surface_set_material(m.get_surface_count() - 1, mat)
	return m


static func mesh_of(mesh_builder: Callable, mat: Material) -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	mesh_builder.call(st)
	return finish(st, mat)


# a, b, c, d are given counter-clockwise as seen from outside.
static func quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, uvs: Vector2 = Vector2(1, 1)) -> void:
	_tri(st, a, c, b, Vector2(0, 0), Vector2(uvs.x, uvs.y), Vector2(uvs.x, 0))
	_tri(st, a, d, c, Vector2(0, 0), Vector2(0, uvs.y), Vector2(uvs.x, uvs.y))


static func tri_out(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3) -> void:
	_tri(st, a, c, b, Vector2(0, 0), Vector2(1, 1), Vector2(1, 0))


# Gabled roof: ridge runs along Z. Returns mesh with surface 0 = shingles, surface 1 = gables.
static func roof(w: float, d: float, h: float, o: float, shingle: Material, gable: Material) -> ArrayMesh:
	var W: float = w * 0.5 + o
	var D: float = d * 0.5 + o
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	quad(st, Vector3(-W, 0, D), Vector3(0, h, D), Vector3(0, h, -D), Vector3(-W, 0, -D), Vector2(d, 2))
	quad(st, Vector3(W, 0, -D), Vector3(0, h, -D), Vector3(0, h, D), Vector3(W, 0, D), Vector2(d, 2))
	var m: ArrayMesh = finish(st, shingle)
	var st2 = SurfaceTool.new()
	st2.begin(Mesh.PRIMITIVE_TRIANGLES)
	var gh: float = h * (w * 0.5) / W
	var zf: float = d * 0.5
	tri_out(st2, Vector3(-w * 0.5, 0, zf), Vector3(w * 0.5, 0, zf), Vector3(0, gh, zf))
	tri_out(st2, Vector3(w * 0.5, 0, -zf), Vector3(-w * 0.5, 0, -zf), Vector3(0, gh, -zf))
	finish(st2, gable, m)
	return m


# Canvas cover: half-cylinder arch along Z.
static func arch(radius: float, length: float, steps: int, mat: Material) -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in steps:
		var a0: float = PI * float(i) / float(steps)
		var a1: float = PI * float(i + 1) / float(steps)
		var p0: Vector3 = Vector3(cos(a0) * radius, sin(a0) * radius * 0.95, 0)
		var p1: Vector3 = Vector3(cos(a1) * radius, sin(a1) * radius * 0.95, 0)
		var z: float = length * 0.5
		# outward-facing, counter-clockwise from outside
		quad(st, p0 + Vector3(0, 0, z), p0 + Vector3(0, 0, -z), p1 + Vector3(0, 0, -z), p1 + Vector3(0, 0, z))
	return finish(st, mat)


static func tuft(mat: Material) -> ArrayMesh:
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng = RandomNumberGenerator.new()
	rng.seed = 5
	for b in 8:
		var a: float = rng.randf() * TAU
		var dd: float = rng.randf() * 0.2
		var base: Vector3 = Vector3(cos(a) * dd, 0.0, sin(a) * dd)
		var ang: float = rng.randf() * PI
		var dir: Vector3 = Vector3(cos(ang), 0, sin(ang))
		var perp: Vector3 = Vector3(-dir.z, 0, dir.x)
		var hgt: float = rng.randf_range(0.5, 0.95)
		var wid: float = 0.05
		var lean: Vector3 = perp * rng.randf_range(-0.3, 0.3)
		var mid: Vector3 = base + lean * 0.5 + Vector3(0, hgt * 0.55, 0)
		var l0: Vector3 = base - dir * wid
		var r0: Vector3 = base + dir * wid
		var l1: Vector3 = mid - dir * wid * 0.7
		var r1: Vector3 = mid + dir * wid * 0.7
		var tip: Vector3 = base + lean + Vector3(0, hgt, 0)
		var pts: Array = [l0, r0, r1, l0, r1, l1, l1, r1, tip]
		var vs: Array = [0.0, 0.0, 0.55, 0.0, 0.55, 0.55, 0.55, 0.55, 1.0]
		for k in 9:
			st.set_normal(Vector3.UP)
			st.set_uv(Vector2(0.0, vs[k]))
			st.add_vertex(pts[k])
	var m: ArrayMesh = st.commit()
	m.surface_set_material(0, mat)
	return m
