extends RefCounted
# All audio is synthesised from noise and sine waves (low sample rate, short clips: cheap on old phones).

static var cache: Dictionary = {}


static func get_stream(kind: String) -> AudioStreamWAV:
	if cache.has(kind):
		return cache[kind]
	var rate: int = 11025
	var secs: float = 0.4
	var looped: bool = false
	match kind:
		"shot":
			secs = 0.4
		"thud":
			secs = 0.2
		"click":
			secs = 0.05
		"hoof":
			secs = 0.12
		"crash":
			secs = 0.35
		"thunder":
			secs = 1.8
		"wind":
			secs = 1.5
			looped = true
		"rain":
			secs = 1.0
			looped = true
		"fire":
			secs = 1.5
			looped = true
		"chime":
			secs = 0.5
	var n: int = int(float(rate) * secs)
	var buf = PackedByteArray()
	buf.resize(n * 2)
	var rng = RandomNumberGenerator.new()
	rng.seed = hash(kind)
	var lp: float = 0.0
	var lp2: float = 0.0
	for i in n:
		var t: float = float(i) / float(rate)
		var nz: float = rng.randf() * 2.0 - 1.0
		var v: float = 0.0
		match kind:
			"shot":
				lp += (nz - lp) * 0.5
				v = lp * exp(-t * 14.0) * 1.7 + sin(t * 150.0 * (1.0 - t)) * exp(-t * 16.0) * 0.8
			"thud":
				v = sin(t * 95.0 * (1.0 - t * 2.0)) * exp(-t * 20.0)
			"click":
				v = nz * exp(-t * 90.0) * 0.6
			"hoof":
				lp += (nz - lp) * 0.3
				v = sin(t * 170.0) * exp(-t * 38.0) * 0.8 + lp * exp(-t * 60.0) * 0.5
			"crash":
				lp += (nz - lp) * 0.35
				v = lp * exp(-t * 6.0) * 1.2 + sin(t * 70.0) * exp(-t * 9.0)
			"thunder":
				lp += (nz - lp) * 0.06
				lp2 += (lp - lp2) * 0.3
				v = lp2 * 12.0 * exp(-t * 1.1) * (0.55 + 0.45 * sin(t * 7.0))
			"wind":
				lp += (nz - lp) * 0.04
				v = lp * 4.0 * (0.65 + 0.35 * sin(t * TAU / 1.5))
			"rain":
				lp += (nz - lp) * 0.6
				v = lp * 0.4
			"fire":
				lp += (nz - lp) * 0.08
				var pop: float = 1.0 if rng.randf() > 0.998 else 0.0
				lp2 = lp2 * 0.97 + pop
				v = lp * 1.2 + lp2 * 0.25 * nz
			"chime":
				v = (sin(t * 1320.0) + 0.5 * sin(t * 1980.0)) * exp(-t * 4.0) * 0.4
		if looped:
			v *= minf(1.0, minf(t, secs - t) * 20.0)
		buf.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 28000.0))
	var w = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = buf
	if looped:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = n
	cache[kind] = w
	return w
