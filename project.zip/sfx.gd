extends RefCounted
# All audio is synthesised at startup from noise and sine waves. No audio files.

static var cache: Dictionary = {}


static func get_stream(kind: String) -> AudioStreamWAV:
	if cache.has(kind):
		return cache[kind]
	var rate: int = 22050
	var secs: float = 0.5
	var looped: bool = false
	match kind:
		"shot":
			secs = 0.8
		"thud":
			secs = 0.3
		"click":
			secs = 0.08
		"hoof":
			secs = 0.22
		"crash":
			secs = 0.6
		"thunder":
			secs = 4.0
		"wind":
			secs = 3.0
			looped = true
		"rain":
			secs = 2.0
			looped = true
		"fire":
			secs = 3.0
			looped = true
		"chime":
			secs = 0.9
	var n: int = int(float(rate) * secs)
	var buf = PackedByteArray()
	buf.resize(n * 2)
	var rng = RandomNumberGenerator.new()
	rng.seed = hash(kind)
	var lp: float = 0.0
	var lp2: float = 0.0
	for i in n:
		var t: float = float(i) / float(rate)
		var nz: float = rng.randf() * 2.0 - 1.0
		var v: float = 0.0
		match kind:
			"shot":
				lp += (nz - lp) * 0.4
				v = lp * exp(-t * 13.0) * 1.7 + sin(t * 150.0 * (1.0 - t)) * exp(-t * 16.0) * 0.8
			"thud":
				v = sin(t * 95.0 * (1.0 - t * 2.0)) * exp(-t * 20.0)
			"click":
				v = nz * exp(-t * 90.0) * 0.6
			"hoof":
				lp += (nz - lp) * 0.2
				v = sin(t * 170.0) * exp(-t * 38.0) * 0.8 + lp * exp(-t * 60.0) * 0.5
			"crash":
				lp += (nz - lp) * 0.25
				v = lp * exp(-t * 6.0) * 1.2 + sin(t * 70.0) * exp(-t * 9.0)
			"thunder":
				lp += (nz - lp) * 0.03
				lp2 += (lp - lp2) * 0.2
				v = lp2 * 14.0 * exp(-t * 0.8) * (0.55 + 0.45 * sin(t * 7.0))
			"wind":
				lp += (nz - lp) * 0.02
				v = lp * 5.0 * (0.65 + 0.35 * sin(t * TAU / 3.0 * 1.0))
			"rain":
				lp += (nz - lp) * 0.55
				v = lp * 0.45
			"fire":
				lp += (nz - lp) * 0.05
				var pop: float = 1.0 if rng.randf() > 0.9985 else 0.0
				lp2 = lp2 * 0.99 + pop
				v = lp * 1.4 + lp2 * 0.25 * nz
			"chime":
				v = (sin(t * 1320.0) + 0.5 * sin(t * 1980.0)) * exp(-t * 4.0) * 0.4
		if looped:
			var edge: float = minf(1.0, minf(t, secs - t) * 20.0)
			v *= edge
		buf.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 28000.0))
	var w = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = buf
	if looped:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = n
	cache[kind] = w
	return w
